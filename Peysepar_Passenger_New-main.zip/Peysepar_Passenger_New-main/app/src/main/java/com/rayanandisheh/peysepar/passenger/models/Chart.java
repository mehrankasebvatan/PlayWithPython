package com.rayanandisheh.peysepar.passenger.models;

import com.google.gson.annotations.SerializedName;

public class Chart {

    @SerializedName("strChart")
    private String strChart;

    @SerializedName("strComment")
    private String strComment;

    public Chart() {
    }

    public String getStrChart() {
        return strChart;
    }

    public void setStrChart(String strChart) {
        this.strChart = strChart;
    }

    public String getStrComment() {
        return strComment;
    }

    public void setStrComment(String strComment) {
        this.strComment = strComment;
    }
}
