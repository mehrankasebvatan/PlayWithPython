package com.rayanandisheh.peysepar.passenger.view.Activity;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;

import com.rayanandisheh.peysepar.passenger.BuildConfig;
import com.rayanandisheh.peysepar.passenger.R;
import com.rayanandisheh.peysepar.passenger.customes.mAppCompatActivity;

public class AboutActivity extends mAppCompatActivity {

    Context context;

    ImageView ivIcon;
    TextView tvCoName,tvCoUrl;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);
        context = this;

        bindView();

        activityLoaded();
        //getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        tvCoUrl.setOnClickListener(v -> tvCoUrlPressed());

    }

    private void bindView() {
        ivIcon=findViewById(R.id.ivIcon);
        tvCoName=findViewById(R.id.tvCoName);
        tvCoUrl=findViewById(R.id.tvCoUrl);
    }

    public void showAppVersion(String appVersion) {
//        ((TextView)findViewById(R.id.tvAppVersion)).setText(appVersion);
    }

    public void activityLoaded() {
        showAppVersion(context.getString(R.string.version) + " " + getAppVersion());
    }

    public void tvCoUrlPressed() {
        context.startActivity(new Intent(Intent.ACTION_VIEW,
                Uri.parse("http://www.rayanandisheh.com")));
    }

    public String getAppVersion() {
        return BuildConfig.VERSION_NAME;
    }
}