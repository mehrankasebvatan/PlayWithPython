package com.rayanandisheh.peysepar.passenger.models;

import com.google.gson.annotations.SerializedName;

public class MobileDomain {
    @SerializedName("iMobileDomain")
    public int iMobileDomain;

    @SerializedName("strComment")
    public String strComment;

    public int getiMobileDomain() {
        return iMobileDomain;
    }

    public void setiMobileDomain(int iMobileDomain) {
        this.iMobileDomain = iMobileDomain;
    }

    public String getStrComment() {
        return strComment;
    }

    public void setStrComment(String strComment) {
        this.strComment = strComment;
    }
}
