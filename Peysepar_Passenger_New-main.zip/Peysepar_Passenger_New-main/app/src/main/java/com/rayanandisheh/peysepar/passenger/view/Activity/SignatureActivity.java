package com.rayanandisheh.peysepar.passenger.view.Activity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Base64;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.RatingBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.Toolbar;
import androidx.core.widget.NestedScrollView;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import com.bumptech.glide.Glide;
//import com.crashlytics.android.answers.Answers;
//import com.crashlytics.android.answers.ContentViewEvent;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.rayanandisheh.peysepar.passenger.R;
import com.rayanandisheh.peysepar.passenger.helpers.App;
import com.rayanandisheh.peysepar.passenger.helpers.Converter;
import com.rayanandisheh.peysepar.passenger.helpers.DrawView;
import com.rayanandisheh.peysepar.passenger.helpers.PersianAppcompatActivity;
import com.rayanandisheh.peysepar.passenger.helpers.Toaster;
import com.rayanandisheh.peysepar.passenger.models.EndTrip;
import com.rayanandisheh.peysepar.passenger.models.Trip;
import com.rayanandisheh.peysepar.passenger.services.APIClient;
import com.rayanandisheh.peysepar.passenger.services.APIService;
import com.rayanandisheh.peysepar.passenger.view.dialog.DialogSignature;

import de.hdodenhof.circleimageview.CircleImageView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SignatureActivity extends PersianAppcompatActivity {

    private static final String TAG = "SignatureActivity";
    Trip model;
    private CheckBox chb_signature_question_1, chb_signature_question_2, chb_signature_question_3, chb_signature_question_4;
    Context context;
    CircleImageView imgView;
    TextView txtDriverName, txtOriginAddress, txtDestinationAddress, row_startpoint_TripCode2;
    EditText edt_SignatureComment;
    Button btnRegister;
    ProgressBar pbSignature;
    RatingBar ratingBar;
    Integer iOfficialTrip;
    String strComment = "";
    Toolbar toolbar;
    String bitmapSign;
    private NestedScrollView nestedScrollView;
    private float question_1 = 0f;
    private float question_2 = 0f;
    private float question_3 = 0f;
    private float question_4 = 0f;
    private float star = 0f;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signature1);

        context = this;
        bindView();
        //getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        if (App.notifModel != null) {
            iOfficialTrip = App.notifModel.getiOfficialTrip();
            txtDriverName.setText(App.notifModel.getStrDriverName());
            txtOriginAddress.setText(App.notifModel.getOriginAddress());
            txtDestinationAddress.setText(App.notifModel.getDestinationAddress());
            row_startpoint_TripCode2.setText(String.valueOf(iOfficialTrip));
        } else {
            Bundle nbundle = getIntent().getExtras();
            if (nbundle != null) {
                model = nbundle.getParcelable("signature");
                iOfficialTrip = model.getiOfficialTrip();
                assert model != null;
                txtDriverName.setText(model.getStrDriverName());
                txtOriginAddress.setText(model.getStrOriginAddress());
                txtDestinationAddress.setText(model.getStrDestinationAddress());
                row_startpoint_TripCode2.setText(String.valueOf(iOfficialTrip));
                if (model.getImageDriver() != null && !model.getImageDriver().equals("")) {
                    byte[] decodedString = Base64.decode(model.getImageDriver(), Base64.DEFAULT);
                    Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
                    Glide.with(context).load(decodedByte).into(imgView);
                }
            }
        }

//        try {
//            Picasso.get()
//                    .load(App.userInfo.getImgLink())
//                    .placeholder(R.drawable.ic_account3)// Place holder image from drawable folder
//                    .error(R.drawable.ic_account3)
//                    .memoryPolicy(MemoryPolicy.NO_CACHE, MemoryPolicy.NO_STORE)
//                    .networkPolicy(NetworkPolicy.NO_CACHE)
//                    .resize(110, 110)
//                    .centerCrop()
//                    .into(imgView);
//        } catch (Exception ignored) {
//        }
//        }

        btnRegister.setOnClickListener(v -> {
            showCarDialog(ratingBar.getRating(), iOfficialTrip, edt_SignatureComment.getText().toString());
        });

        chb_signature_question_1.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                question_1 = 1.25f;
                star = question_1 + question_2 + question_3 + question_4;
                ratingBar.setRating(star);
            } else {
                question_1 = 0f;
                star = question_1 + question_2 + question_3 + question_4;
                ratingBar.setRating(star);
            }
        });
        chb_signature_question_2.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                question_2 = 1.25f;
                star = question_1 + question_2 + question_3 + question_4;
                ratingBar.setRating(star);
            } else {
                question_2 = 0f;
                star = question_1 + question_2 + question_3 + question_4;
                ratingBar.setRating(star);
            }
        });
        chb_signature_question_3.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                question_3 = 1.25f;
                star = question_1 + question_2 + question_3 + question_4;
                ratingBar.setRating(star);
            } else {
                question_3 = 0f;
                star = question_1 + question_2 + question_3 + question_4;
                ratingBar.setRating(star);
            }
        });
        chb_signature_question_4.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                question_4 = 1.25f;
                star = question_1 + question_2 + question_3 + question_4;
                ratingBar.setRating(star);
            } else {
                question_4 = 0f;
                star = question_1 + question_2 + question_3 + question_4;
                ratingBar.setRating(star);
            }
        });

//        btnRegister.setOnClickListener(v -> presenter.btnRegisterPressed(ratingBar.getRating(), model.getiOfficialTrip()));
    }

    public void showCarDialog(float rating, int iOfficialTrip, String strComment) {
        FragmentManager manager = getSupportFragmentManager();
        Fragment frag = manager.findFragmentByTag("dialog_Fragment_Signature");
        if (frag != null) {
            manager.beginTransaction().remove(frag).commit();
        }
        DialogSignature dialogFinalOrderRegistration = new
                DialogSignature(SignatureActivity.this, (bitmap) -> {
            sendData(bitmap, rating, iOfficialTrip, strComment);
        });
        dialogFinalOrderRegistration.show(manager, "dialog_Fragment_Signature");
    }

    @SuppressLint("ClickableViewAccessibility")
    private void bindView() {
        imgView = findViewById(R.id.ivSignature);
        txtDriverName = findViewById(R.id.txtDriverName);
        txtOriginAddress = findViewById(R.id.txtOrigin);
        txtDestinationAddress = findViewById(R.id.txtDestination);
        chb_signature_question_1 = findViewById(R.id.chb_signature_question_1);
        chb_signature_question_2 = findViewById(R.id.chb_signature_question_2);
        chb_signature_question_3 = findViewById(R.id.chb_signature_question_3);
        chb_signature_question_4 = findViewById(R.id.chb_signature_question_4);
        edt_SignatureComment = findViewById(R.id.edt_SignatureComment);
        nestedScrollView = findViewById(R.id.nestedScrollView);
        btnRegister = findViewById(R.id.btnSignature);
        pbSignature = findViewById(R.id.pbSiggnature);
        ratingBar = findViewById(R.id.rateSignature);
        toolbar = findViewById(R.id.toolbar_signature);
        row_startpoint_TripCode2 = findViewById(R.id.row_startpoint_TripCode2);
        setSupportActionBar(toolbar);

//        edt_SignatureComment.setOnFocusChangeListener((v, hasFocus) -> nestedScrollView.fullScroll(View.FOCUS_DOWN));

        edt_SignatureComment.setOnTouchListener((v, event) -> {
            nestedScrollView.fullScroll(View.FOCUS_DOWN);
            return false;
        });

        getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        setTitle("امتیاز سفر");
    }

    public void endTripResult(int result) {
        if (result == 1) {
            Toaster.shorter("سفر شما به اتمام رسید");
            finish();
            onBackPressed();
        } else if (result == -1)
            Toaster.shorter(context.getString(R.string.connectionFaield));
        else if (result == -2)
            Toaster.shorter(context.getString(R.string.serverFaield));
        else if (result == 100) {
            Intent intent=new Intent(SignatureActivity.this,LoginActivity.class);
            startActivity(intent);
        }
    }

    public void sendData(Bitmap bitmap, float rating, int iOfficialTrip, String strComment) {
        saveAndFinish(bitmap, rating, iOfficialTrip, strComment);
    }

    public void saveAndFinish(Bitmap bitmap, float rating, int iOfficialTrip, String strcomment) {
        if (bitmap != null) {
            bitmapSign = Converter.bitmapToString(bitmap);
            request(bitmapSign, rating, iOfficialTrip, strcomment);
        }
    }

    private void request(String bitmapSign, float rating, int iOfficialTrip, String strComment) {

        EndTrip endTrip = new EndTrip();

        endTrip.setfScore(rating);
        endTrip.setImg(bitmapSign);
        endTrip.setStrCommentEndTrip(strComment);

        int code = iOfficialTrip;
//        Integer code = App.notifModel.getiOfficialTrip();
        // make this clause ,by clicking on a trip with status code 7 on cartable trip
        if (code == 0) {
            endTrip.setiOfficialTrip(iOfficialTrip);
        } else {
            endTrip.setiOfficialTrip(code);
        }

        try {
            APIService apiService = APIClient.getClient().create(APIService.class);
            Call<Integer> call = apiService.endTrip(endTrip,App.Session);
            call.enqueue(new Callback<Integer>() {
                @Override
                public void onResponse(@NonNull Call<Integer> call, @NonNull Response<Integer> response) {
                    if (response.code() == 200 && response.body() != null) {
                        endTripResult(response.body());
                    } else {
                        endTripResult(-2);
                    }
                }

                @Override
                public void onFailure(@NonNull Call<Integer> call, @NonNull Throwable t) {
                    endTripResult(-1);
                }
            });
        } catch (Exception e) {
            Log.e(TAG, "request: " + e.toString());
        }
    }

    @Override
    public void onBackPressed() {
        startActivity(new Intent(getApplicationContext(), MainActivity.class));
    }

    @SuppressLint("ObsoleteSdkInt")
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.ECLAIR
                && (keyCode == KeyEvent.KEYCODE_BACK || keyCode == KeyEvent.KEYCODE_HOME)
                && event.getRepeatCount() == 0) {
            onBackPressed();
        }
        return super.onKeyDown(keyCode, event);
    }
}
