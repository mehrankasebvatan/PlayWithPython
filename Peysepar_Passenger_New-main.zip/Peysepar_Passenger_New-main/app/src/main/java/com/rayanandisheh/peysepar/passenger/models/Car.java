package com.rayanandisheh.peysepar.passenger.models;

import com.google.gson.annotations.SerializedName;

public class Car {

    @SerializedName("strUnitId")
    private String strUnitId;
    @SerializedName("tiMobileType")
    private int tiMobileType;
    @SerializedName("fLat")
    private double fLat;
    @SerializedName("fLon")
    private double fLon;
    @SerializedName("siAngle")
    private int siAngle;
    @SerializedName("iSpeed")
    private int iSpeed;
    @SerializedName("strTime")
    private String strTime;
    @SerializedName("strDate")
    private String strDate;

    public String getStrUnitId() {
        return strUnitId;
    }

    public void setStrUnitId(String strUnitId) {
        this.strUnitId = strUnitId;
    }

    public int getTiMobileType() {
        return tiMobileType;
    }

    public void setTiMobileType(int tiMobileType) {
        this.tiMobileType = tiMobileType;
    }

    public double getfLat() {
        return fLat;
    }

    public void setfLat(double fLat) {
        this.fLat = fLat;
    }

    public double getfLon() {
        return fLon;
    }

    public void setfLon(double fLon) {
        this.fLon = fLon;
    }

    public int getSiAngle() {
        return siAngle;
    }

    public void setSiAngle(int siAngle) {
        this.siAngle = siAngle;
    }

    public int getiSpeed() {
        return iSpeed;
    }

    public void setiSpeed(int iSpeed) {
        this.iSpeed = iSpeed;
    }

    public String getStrTime() {
        return strTime;
    }

    public void setStrTime(String strTime) {
        this.strTime = strTime;
    }

    public String getStrDate() {
        return strDate;
    }

    public void setStrDate(String strDate) {
        this.strDate = strDate;
    }
}