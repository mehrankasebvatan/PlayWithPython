package com.rayanandisheh.peysepar.passenger.helpers;

import android.content.Intent;
import android.os.AsyncTask;

import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.LatLng;

import java.util.HashMap;

public class GetDistanceDataDestination extends AsyncTask<Object, String, String> {

    private String googleDirectionsData;

    @Override
    protected String doInBackground(Object... objects) {
        String url = (String) objects[1];
        DownloadUrl downloadUrl = new DownloadUrl();
        try {
            googleDirectionsData = downloadUrl.readUrl(url);
        } catch (Exception ignored) {
        }
        return googleDirectionsData;
    }

    @Override
    protected void onPostExecute(String s) {
        HashMap<String, String> addressList = new DataParser().parseAddress(s);
        String start_address = addressList.get("start_address");
        String end_address = addressList.get("end_address");

        App.context.sendBroadcast(new Intent()
                .putExtra("start_address", start_address)
                .putExtra("end_address", end_address)
                .setAction("android.intent.action.map_result_ok"));
    }

    private static String getDirectionUrl(LatLng origin, LatLng destination) {
        return "https://maps.googleapis.com/maps/api/directions/json?" + "origin=" + origin.latitude + "," + origin.longitude +
                "&destination=" + destination.latitude + "," + destination.longitude +
                "&key=" + App.googleDistanceApiKey + "&language=fa&region=ir";
    }

    public static void callDistance(LatLng origin, LatLng destination, GoogleMap googleMap) {
        Object dataTransfer[] = new Object[2];
        String url = getDirectionUrl(origin, destination);
        GetDistanceData getDistanceData = new GetDistanceData();
        dataTransfer[0] = googleMap;
        dataTransfer[1] = url;
        getDistanceData.execute(dataTransfer);
    }

}
