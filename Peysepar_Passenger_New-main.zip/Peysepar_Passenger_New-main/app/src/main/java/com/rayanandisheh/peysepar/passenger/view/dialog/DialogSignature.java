package com.rayanandisheh.peysepar.passenger.view.dialog;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.rayanandisheh.peysepar.passenger.R;
import com.rayanandisheh.peysepar.passenger.helpers.DrawView;
import com.rayanandisheh.peysepar.passenger.helpers.Toaster;

public class DialogSignature extends DialogFragment implements View.OnClickListener {

    private static final String TAG = "DialogFinalOrderRegistration";
    private View view;
    private RelativeLayout rlDrawing;
    private Activity activity;
    private OnClickDialog onClickDialog;
    private DrawView drawView;
    private ProgressBar progressBar;
    private Button btn_SendData;

    public DialogSignature(Activity activity, OnClickDialog onClickDialog) {
        this.activity = activity;
        this.onClickDialog = onClickDialog;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container
            , @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.dialog_signature, container, false);
        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        setCancelable(true);
        getViews();
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        drawView = new DrawView(rlDrawing.getContext());
        rlDrawing.setDrawingCacheEnabled(true);
        rlDrawing.addView(drawView);
    }

    public void onResume() {
        getDialog().getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        getDialog().getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);

        Window window = getDialog().getWindow();
        WindowManager.LayoutParams wlp = window.getAttributes();
        wlp.gravity = Gravity.CENTER;
        wlp.flags = WindowManager.LayoutParams.FLAG_DIM_BEHIND;
        window.setAttributes(wlp);
        super.onResume();
    }

    @SuppressLint("ClickableViewAccessibility")
    private void getViews() {
        rlDrawing = view.findViewById(R.id.rlDrawing);
        progressBar = view.findViewById(R.id.progressBar);
        FloatingActionButton fabSignature = view.findViewById(R.id.fabSignature);
        btn_SendData = view.findViewById(R.id.btn_SendData);

        fabSignature.setOnClickListener(this);
        btn_SendData.setOnClickListener(this);
    }

    public void showProgressBar() {
        progressBar.setVisibility(View.VISIBLE);
        btn_SendData.setVisibility(View.GONE);
    }

    public void hideProgressbar() {
        progressBar.setVisibility(View.GONE);
        btn_SendData.setVisibility(View.VISIBLE);
    }

    public interface OnClickDialog {
        void onClick(Bitmap bitmap);
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.btn_SendData) {
            if (!drawView.isDrawed()) {
                hideProgressbar();
                Toaster.shorter("لطفا امضای خود را وارد کنید");
            } else {
                showProgressBar();
                drawView.setDrawingCacheEnabled(true);
                drawView.buildDrawingCache(true);
                Bitmap bitmap = Bitmap.createBitmap(drawView.getDrawingCache());
                onClickDialog.onClick(bitmap);
            }
        }
        if (v.getId() == R.id.fabSignature) {
            drawView.clear();
        }
    }

}

