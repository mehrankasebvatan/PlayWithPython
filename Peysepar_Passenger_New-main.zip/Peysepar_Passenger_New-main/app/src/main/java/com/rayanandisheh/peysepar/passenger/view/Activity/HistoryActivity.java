package com.rayanandisheh.peysepar.passenger.view.Activity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.mohamadamin.persianmaterialdatetimepicker.date.DatePickerDialog;
import com.rayanandisheh.peysepar.passenger.R;
import com.rayanandisheh.peysepar.passenger.helpers.App;
import com.rayanandisheh.peysepar.passenger.helpers.Cache;
import com.rayanandisheh.peysepar.passenger.helpers.PersianAppcompatActivity;
import com.rayanandisheh.peysepar.passenger.helpers.Time;
import com.rayanandisheh.peysepar.passenger.helpers.Toaster;
import com.rayanandisheh.peysepar.passenger.models.Trip;
import com.rayanandisheh.peysepar.passenger.services.APIClient;
import com.rayanandisheh.peysepar.passenger.services.APIService;
import com.rayanandisheh.peysepar.passenger.view.Adapter.HistoryAdapter;

import java.util.List;

import ir.hamsaa.persiandatepicker.Listener;
import ir.hamsaa.persiandatepicker.PersianDatePickerDialog;
import ir.hamsaa.persiandatepicker.util.PersianCalendar;
import jp.wasabeef.recyclerview.adapters.AlphaInAnimationAdapter;
import jp.wasabeef.recyclerview.adapters.ScaleInAnimationAdapter;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import saman.zamani.persiandate.PersianDate;
import saman.zamani.persiandate.PersianDateFormat;

public class HistoryActivity extends PersianAppcompatActivity {

    RecyclerView recyclerView;
    SwipeRefreshLayout swpHistory;
    HistoryAdapter adapter;
    ImageView imgNoItem, imgSearch_history;
    EditText edtDateFrom_history, edtDateTo_history;
    ProgressBar progressBar;
    //    List<ModelCurrentTrip> modelCurrentTrip =new ArrayList<>();
    private PersianDatePickerDialog picker;
    RelativeLayout rl_search_history;
    String date;
    Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);
        //getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        context = this;
        bindViews();

        edtDateFrom_history.setText(getNowPersianDate());
        edtDateTo_history.setText(Time.getNowPersianDate());

        viewLoaded(edtDateFrom_history.getText().toString(),
                edtDateTo_history.getText().toString());

        edtDateFrom_history.setOnClickListener(v -> edtDatePressed(true));
        edtDateTo_history.setOnClickListener(v -> edtDatePressed(false));

        swpHistory.setOnRefreshListener(() -> swipRefreshPressed(edtDateFrom_history.getText().toString(),
                edtDateTo_history.getText().toString()));

        rl_search_history.setOnClickListener(v -> swipRefreshPressed(edtDateFrom_history.getText().toString(),
                edtDateTo_history.getText().toString()));

    }

    public static String getNowPersianDate() {
        PersianDate pDate = new PersianDate();
        new PersianDateFormat("yyyy/mm/dd").format(pDate);
//        return pDate.getShYear() + "/" + pDate.getShMonth() + "/" + pDate.getShDay();
        return (String.valueOf(pDate.getShYear()).length() < 2 ? "0" + pDate.getShYear() : String.valueOf(pDate.getShYear())) + "/" +
                (String.valueOf(pDate.getShMonth()).length() < 2 ? "0" + pDate.getShMonth() : String.valueOf(pDate.getShMonth())) + "/" +
                (String.valueOf(pDate.getShDay()).length() < 2 ? "0" + pDate.getShDay() : String.valueOf(pDate.getShDay()));

    }

    private void bindViews() {
        recyclerView = findViewById(R.id.rv_history);
        swpHistory = findViewById(R.id.swpHistory);
        imgNoItem = findViewById(R.id.img_noIconTripHistory);
        imgSearch_history = findViewById(R.id.img_search_history);
        edtDateFrom_history = findViewById(R.id.edtDateFrom_history);
        edtDateTo_history = findViewById(R.id.edtDateTo_history);

        rl_search_history = findViewById(R.id.rl_serach_history);
        progressBar = findViewById(R.id.progressBarHistory);

        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(context);
        recyclerView.setLayoutManager(layoutManager);

    }

    public void viewLoaded(String dateFrom, String dateTo) {
        if (App.historyTripSuccess) {
            loadHistoryTripList(dateFrom, dateTo);
        } else if (App.listHistoryTrip.size() > 0) {
            setAdapter();
            hideImg_noItem();
        } else if (App.listHistoryTrip.size() == 0) {
            showImg_noItem();
        }
    }

    public void showPregressbar() {
        showProgressLoading();
    }

    public void swipRefreshPressed(String dateFrom, String dateTo) {
        loadHistoryTripList(dateFrom, dateTo);
        showSwipeRefresh();
    }

    public void loadHistoryTripList(String dateFrom, String dateTo) {

        showPregressbar();

        App.userInfo.setDateFrom(dateFrom);
        App.userInfo.setDateTo(dateTo);
        App.userInfo.setType(1);
        App.userInfo.setStrMobile(Cache.getString("mobileNumber"));

        APIService apiService = APIClient.getClient().create(APIService.class);
        Call<List<Trip>> call = apiService.TripListHistory(App.userInfo,App.Session);
        call.enqueue(new Callback<List<Trip>>() {
            @Override
            public void onResponse(@NonNull Call<List<Trip>> call, @NonNull Response<List<Trip>> response) {
                if (response.code() == 200) {

                    App.historySuccess = false;

                    App.listHistoryTrip = response.body();
                    if (App.listHistoryTrip != null) {
                        loadDataResult(1);
                    } else {
                        loadDataResult(0);
                    }
//                     Presenter.loadData(response.body().getResult);
                } else {
                    loadDataResult(-4);
                }
            }

            @Override
            public void onFailure(@NonNull Call<List<Trip>> call, @NonNull Throwable t) {
                loadDataResult(-5);
            }
        });
    }

    public void loadDataResult(int result) {
        stopProgressLoading();
        hideSwipeRefresh();
        if (result == -4)
            Toaster.shorter(context.getString(R.string.serverFaield));
        else if (result == -5)
            Toaster.shorter(context.getString(R.string.connectionFaield));
        else if (result == 0)
            showImg_noItem();
        else if (result == 1) {
            setAdapter();
            if (App.listHistoryTrip.size() > 0)
                hideImg_noItem();
            else
                showImg_noItem();
        }
    }

    public void edtDatePressed(boolean isFrom) {
//        date(isFrom);
        calendar(isFrom);
    }

    private void date(boolean isFrom) {
//        PersianCalendar initDate = new PersianCalendar();
//        initDate.setPersianDate(1370, 3, 13);

        picker = new PersianDatePickerDialog(context)
                .setPositiveButtonString("تایید")
                .setNegativeButton("انصراف")
                .setTodayButton("امروز")
                .setTodayButtonVisible(true)
                .setMinYear(1300)
                .setMaxYear(PersianDatePickerDialog.THIS_YEAR)
                .setActionTextColor(Color.GRAY)
//                .setTypeFace(typeface)

                //write again it if it has error
                .setListener(new Listener() {
                    @Override
                    public void onDateSelected(PersianCalendar persianCalendar) {
//                        Toast.makeText(context, persianCalendar.getPersianYear() + "/" +
//                                persianCalendar.getPersianMonth() + "/" + persianCalendar.getPersianDay(), Toast.LENGTH_SHORT).show();
                        date = persianCalendar.getPersianYear() + "/" +
                                (String.valueOf(persianCalendar.getPersianMonth()).length() == 2 ?
                                        persianCalendar.getPersianMonth() : "0" + persianCalendar.getPersianMonth()) + "/" +
                                (String.valueOf(persianCalendar.getPersianDay()).length() == 2 ?
                                        persianCalendar.getPersianDay() : "0" + persianCalendar.getPersianDay());
                        if (isFrom)
                            setFromDate(date);
                        else
                            setToDate(date);
                    }

                    @Override
                    public void onDismissed() {

                    }
                });

        picker.show();
    }

    private void calendar(boolean isFrom) {
        PersianCalendar persianCalendar = new PersianCalendar();
        @SuppressLint("SetTextI18n") DatePickerDialog datePickerDialog = DatePickerDialog.newInstance(
                (view, year, monthOfYear, dayOfMonth) -> {

                    if ((monthOfYear + 1) < 10 && dayOfMonth < 10) {
                        date = year + "/0" + (monthOfYear + 1) + "/0" + dayOfMonth;
                    } else if ((monthOfYear + 1) < 10) {
                        date = year + "/0" + (monthOfYear + 1) + "/" + dayOfMonth;
                    } else if (dayOfMonth < 10) {
                        date = year + "/" + (monthOfYear + 1) + "/0" + dayOfMonth;
                    } else {
                        date = year + "/" + (monthOfYear + 1) + "/" + dayOfMonth;
                    }

                    if (isFrom)
                        setFromDate(date);
                    else
                        setToDate(date);

                    swipRefreshPressed(edtDateFrom_history.getText().toString(),
                            edtDateTo_history.getText().toString());
                },
                persianCalendar.getPersianYear(),
                persianCalendar.getPersianMonth() - 1,
                persianCalendar.getPersianDay()
        );
        datePickerDialog.show(getFragmentManager(), "Datepickerdialog");
    }

    public void showImg_noItem() {
        imgNoItem.setVisibility(View.VISIBLE);
    }

    public void hideImg_noItem() {
        imgNoItem.setVisibility(View.GONE);
    }

    public void setFromDate(String date) {
        edtDateFrom_history.setText(date);
        Cache.setString("DateFrom", date);
    }

    public void setToDate(String date) {
        edtDateTo_history.setText(date);
        Cache.setString("DateTO", date);
    }

    public void setAdapter() {

//        adapter.clear();
        adapter = new HistoryAdapter(App.listHistoryTrip, context);
        AlphaInAnimationAdapter alphaAdapter = new AlphaInAnimationAdapter(adapter);
        recyclerView.setAdapter(new ScaleInAnimationAdapter(alphaAdapter));
    }

    public void showProgressLoading() {
        swpHistory.setRefreshing(true);
//       progressBar.setVisibility(View.VISIBLE);
    }

    public void showSwipeRefresh() {
        swpHistory.setRefreshing(true);
    }

    public void hideSwipeRefresh() {
        swpHistory.setRefreshing(false);
        progressBar.setVisibility(View.GONE);
    }

    public void showImageEmpety() {
        swpHistory.setRefreshing(false);
        imgNoItem.setVisibility(View.VISIBLE);
    }

    public void stopProgressLoading() {
        swpHistory.setRefreshing(false);
        progressBar.setVisibility(View.GONE);
    }

    @Override
    protected void onResume() {
        super.onResume();
//        swipRefreshPressed(edtDateFrom_history.getText().toString(),
//                edtDateTo_history.getText().toString());
    }
}
