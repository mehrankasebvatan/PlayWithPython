package com.rayanandisheh.peysepar.passenger.view.Activity;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Point;
import android.location.Location;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.text.Editable;
import android.text.Html;
import android.text.Spanned;
import android.text.TextWatcher;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.Interpolator;
import android.view.animation.LinearInterpolator;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.NumberPicker;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatDelegate;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.Projection;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.MapStyleOptions;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.mohamadamin.persianmaterialdatetimepicker.date.DatePickerDialog;
import com.rayanandisheh.peysepar.passenger.R;
import com.rayanandisheh.peysepar.passenger.helpers.EnumTypeTrip;
import com.rayanandisheh.peysepar.passenger.view.Adapter.AddTripAdapter;
import com.rayanandisheh.peysepar.passenger.helpers.App;
import com.rayanandisheh.peysepar.passenger.helpers.Cache;
import com.rayanandisheh.peysepar.passenger.helpers.Converter;
import com.rayanandisheh.peysepar.passenger.helpers.PersianAppcompatActivity;
import com.rayanandisheh.peysepar.passenger.helpers.Time;
import com.rayanandisheh.peysepar.passenger.helpers.Toaster;
import com.rayanandisheh.peysepar.passenger.models.TripInsert;
import com.rayanandisheh.peysepar.passenger.models.TripSAD;
import com.rayanandisheh.peysepar.passenger.services.APIClient;
import com.rayanandisheh.peysepar.passenger.services.APIService;
import com.rayanandisheh.peysepar.passenger.services.LocationService;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import ir.hamsaa.persiandatepicker.Listener;
import ir.hamsaa.persiandatepicker.PersianDatePickerDialog;
import ir.hamsaa.persiandatepicker.util.PersianCalendar;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.rayanandisheh.peysepar.passenger.view.Activity.MapsForAddTripActivity.counter;
import static com.rayanandisheh.peysepar.passenger.view.Activity.MapsForAddTripActivity.destinationLatLon;
import static com.rayanandisheh.peysepar.passenger.view.Activity.MapsForAddTripActivity.destintionSelectLocation;
import static com.rayanandisheh.peysepar.passenger.view.Activity.MapsForAddTripActivity.originLatLon;
import static com.rayanandisheh.peysepar.passenger.view.Activity.MapsForAddTripActivity.originSelectLocation;
import static com.rayanandisheh.peysepar.passenger.helpers.App.modeOfInsert;

public class AddTripWithMapActivity extends PersianAppcompatActivity implements OnMapReadyCallback
        , AddTripAdapter.OnItemClickListener {
    private static final String TAG = "AddTripWithMapActivity";
    Context context;
    TextView txtTimePicker;
    Spinner spnReason, spnImportance, spnCarType;
    Button btnRegisterTrip;
    ProgressBar pbRegisterTrip;
    Toolbar toolbar;
    LinearLayout rlACtextDes;
    LinearLayout rlTextDes;
    AutoCompleteTextView autoCompleteTxtOrigin, autoCompleteTxtDes;
    EditText edtDate, edtEnterNamePassenges, edtCommentAddTrip, edtOriginAddress, edtDestinationAddress;
    ImageView imgAddPassengers;
    RecyclerView rvAddPassenges;
    LinearLayoutManager linearLayoutManager;
    AddTripAdapter myRecyclerViewAdapter1;
    LinearLayout cvMap;
    LinearLayout LinearPredefined;
    FloatingActionButton fabResetMap;
    ImageView ivWarningTripCaption, ivWarningTripOrigin, ivWarningTripdestination;
    private String start_address = "";
    private String end_Address = "";
    //    @BindView(R.id.timePickerAddTrip)
//    TimePicker picker;

    private RadioGroup rg_typeTrip;
    private RadioButton radioTypeButton;
    private RadioButton rb_oneWay;
    private RadioButton rb_roundAndRound;
    private RadioButton rb_available;

    private int iTripS_SAD = -1;
    private int iTripD_SAD = -1;

    //    CheckBox chkBoxInService;
    ImageView ivWarningOrigin;
    ImageView ivWarningDes;
    ImageView ivWarningTripReason;
    ImageView ivWarningTripImportance;
    //    CheckBox chkBxReturn;
    CheckBox chkBxMissionary;

    NumberPicker npHour, npMin;
    Calendar calander;
    String numberPickerTime, dateNow;
    private FloatingActionButton fb_mapShow_origin;
    private FloatingActionButton fb_mapShow_destinatiion;
    private String typeLocation;
    private boolean bTripS_SAD = false;
    private boolean bTripD_SAD = false;

    private EnumTypeTrip enumTypeTrip = EnumTypeTrip.ONE_WAY;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_trip_with_map1);

        context = this;

        bindView();
        //getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        viewLoaded();

        dateNow = Time.getNowPersianDate();

        initializeRecyclerViewAddPassengers();

        if (App.userInfo.getiSAndDBaseCurrentLoc() == 0) {
            cvMap.setVisibility(View.GONE);
            LinearPredefined.setVisibility(View.VISIBLE);

        } else if (App.userInfo.getiSAndDBaseCurrentLoc() == 1) {
            cvMap.setVisibility(View.VISIBLE);
            LinearPredefined.setVisibility(View.INVISIBLE);

            startService(new Intent(context, LocationService.class));

            SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.FRAGMENT_MAP);
            if (mapFragment != null)
                mapFragment.getMapAsync(this);
        } else if (App.userInfo.getiSAndDBaseCurrentLoc() == 2) {
            SupportMapFragment mapFragment;
            switch (modeOfInsert) {
                case "Normal":
                    cvMap.setVisibility(View.GONE);
                    LinearPredefined.setVisibility(View.VISIBLE);
                    fb_mapShow_origin.setVisibility(View.GONE);
                    fb_mapShow_destinatiion.setVisibility(View.GONE);
                    break;
                case "Map":
                    cvMap.setVisibility(View.VISIBLE);
                    LinearPredefined.setVisibility(View.INVISIBLE);
                    fb_mapShow_origin.setVisibility(View.GONE);
                    fb_mapShow_destinatiion.setVisibility(View.GONE);

                    startService(new Intent(context, LocationService.class));

                    mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.FRAGMENT_MAP);
                    if (mapFragment != null)
                        mapFragment.getMapAsync(this);
                    break;

            }
        } else if (App.userInfo.getiSAndDBaseCurrentLoc() == 3) {
            cvMap.setVisibility(View.GONE);
            LinearPredefined.setVisibility(View.VISIBLE);
            fb_mapShow_origin.setVisibility(View.VISIBLE);
            fb_mapShow_destinatiion.setVisibility(View.VISIBLE);
        }

        rb_oneWay.setOnCheckedChangeListener((buttonView, isChecked) -> { // یک طرفه
            if (isChecked) {
                rlACtextDes.setVisibility(View.VISIBLE);
                rlTextDes.setVisibility(View.VISIBLE);
                enumTypeTrip = EnumTypeTrip.ONE_WAY;
            }
        });

        rb_roundAndRound.setOnCheckedChangeListener((buttonView, isChecked) -> { // رفت و برگشت
            if (isChecked) {
                rlACtextDes.setVisibility(View.VISIBLE);
                rlTextDes.setVisibility(View.VISIBLE);
                enumTypeTrip = EnumTypeTrip.ROUND_AND_ROUND;
            }
        });

        rb_available.setOnCheckedChangeListener((buttonView, isChecked) -> { // در اختیار
            if (isChecked) {
                rlACtextDes.setVisibility(View.GONE);
                rlTextDes.setVisibility(View.GONE);
                enumTypeTrip = EnumTypeTrip.AVAILABLE;
            }
        });

        edtDate.setOnClickListener(v -> calendar(edtDate));

        fb_mapShow_origin.setOnClickListener(v -> {
            Log.d("RunAndTestFromSalar", "Hello");
            Intent intent = new Intent(getApplicationContext(), ActivityMapGetOriginOrDestination.class);
            typeLocation = "origin";
            intent.putExtra("typeLocation", "origin");
            App.address = autoCompleteTxtOrigin.getText().toString();
            startActivity(intent);
        });

        fb_mapShow_destinatiion.setOnClickListener(v -> {
            Log.d("RunAndTestFromSalar", "Hello");
            Intent intent = new Intent(getApplicationContext(), ActivityMapGetOriginOrDestination.class);
            typeLocation = "destination";
            intent.putExtra("typeLocation", "destination");
            App.address = autoCompleteTxtDes.getText().toString();
            startActivity(intent);
        });

        btnRegisterTrip.setOnClickListener(v -> getSelectedTime());

        spinnerTripReasonPressed(spnReason);

        spinnerTripImportancePressed(spnImportance);

        edtOriginAddress.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.length() == 0)
                    ivWarningTripOrigin.setVisibility(View.VISIBLE);
                else
                    ivWarningTripOrigin.setVisibility(View.GONE);
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        edtDestinationAddress.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.length() == 0)
                    ivWarningTripdestination.setVisibility(View.VISIBLE);
                else
                    ivWarningTripdestination.setVisibility(View.GONE);
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        autoCompleteTxtDes.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.length() == 0)
                    ivWarningDes.setVisibility(View.VISIBLE);
                else
                    ivWarningDes.setVisibility(View.GONE);
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        autoCompleteTxtOrigin.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.length() == 0)
                    ivWarningOrigin.setVisibility(View.VISIBLE);
                else
                    ivWarningOrigin.setVisibility(View.GONE);
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        edtCommentAddTrip.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
//                if (s.length() == 0)
//                    ivWarningTripCaption.setVisibility(View.VISIBLE);
//                else
//                    ivWarningTripCaption.setVisibility(View.GONE);
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        fabResetMap.setOnClickListener(v -> {
            originLatLon = null;
            destinationLatLon = null;
            MapsForAddTripActivity.originSelectLocation = null;
            MapsForAddTripActivity.destintionSelectLocation = null;
            counter = 0;
            backToMap();
        });
    }

    private void getSelectedTime() {
        String time = edtDate.getText().toString();

        int selectedId = rg_typeTrip.getCheckedRadioButtonId();
        radioTypeButton = findViewById(selectedId);

        Log.i(TAG, "radioTypeButton: " + radioTypeButton.getText() + " _ " + radioTypeButton.getTag());
        Log.i(TAG, "radioTypeButton: chkBxMissionary " + " _ " + chkBxMissionary.isChecked());

        if (App.modeOfInsert.equals("Map") && !edtOriginAddress.getText().toString().trim().isEmpty()
                && !(time.compareTo(dateNow) < 0)
                && originLatLon != null && destinationLatLon != null &&
                !edtDestinationAddress.getText().toString().trim().isEmpty()) {

            numberPickerTime = (String.format("%s:%s", String.valueOf(npHour.getValue()).length() < 2 ? "0" + npHour.getValue() : npHour.getValue(),
                    String.valueOf(npMin.getValue()).length() < 2 ? "0" + npMin.getValue() : npMin.getValue()));
            btnPressed(spnReason.getSelectedItemPosition(), spnImportance.getSelectedItemPosition(),
                    spnCarType.getSelectedItemPosition(),
                    autoCompleteTxtOrigin.getText().toString(), autoCompleteTxtDes.getText().toString(),
                    edtDate.getText().toString(), numberPickerTime, enumTypeTrip,
                    chkBxMissionary.isChecked(), myRecyclerViewAdapter1.getList()
                    , edtCommentAddTrip.getText().toString(), edtOriginAddress.getText().toString(),
                    edtDestinationAddress.getText().toString());

        } else if (App.modeOfInsert.equals("Normal") && !autoCompleteTxtOrigin.getText().toString().isEmpty()
                && (!autoCompleteTxtDes.getText().toString().isEmpty())
                && !(time.compareTo(dateNow) < 0)) {

            numberPickerTime = (String.format("%s:%s", String.valueOf(npHour.getValue()).length() < 2 ? "0" + npHour.getValue() : npHour.getValue(),
                    String.valueOf(npMin.getValue()).length() < 2 ? "0" + npMin.getValue() : npMin.getValue()));

            btnPressed(spnReason.getSelectedItemPosition(), spnImportance.getSelectedItemPosition(),
                    spnCarType.getSelectedItemPosition(),
                    autoCompleteTxtOrigin.getText().toString(), autoCompleteTxtDes.getText().toString(),
                    edtDate.getText().toString(), numberPickerTime, enumTypeTrip,
                    chkBxMissionary.isChecked(), myRecyclerViewAdapter1.getList()
                    , edtCommentAddTrip.getText().toString(), edtOriginAddress.getText().toString()
                    , edtDestinationAddress.getText().toString());

        } else if (App.modeOfInsert.equals("hybrid") && enumTypeTrip != EnumTypeTrip.AVAILABLE &&
                !autoCompleteTxtOrigin.getText().toString().isEmpty()
                && (!autoCompleteTxtDes.getText().toString().isEmpty()) && !(time.compareTo(dateNow) < 0)) {

            numberPickerTime = (String.format("%s:%s", String.valueOf(npHour.getValue()).length() < 2
                            ? "0" + npHour.getValue() : npHour.getValue(),
                    String.valueOf(npMin.getValue()).length() < 2 ? "0" + npMin.getValue() : npMin.getValue()));

            btnPressed(spnReason.getSelectedItemPosition(), spnImportance.getSelectedItemPosition(),
                    spnCarType.getSelectedItemPosition(),
                    autoCompleteTxtOrigin.getText().toString(), autoCompleteTxtDes.getText().toString(),
                    edtDate.getText().toString(), numberPickerTime, enumTypeTrip,
                    chkBxMissionary.isChecked(), myRecyclerViewAdapter1.getList(), edtCommentAddTrip.getText().toString()
                    , edtOriginAddress.getText().toString(), edtDestinationAddress.getText().toString());

        } else if (App.modeOfInsert.equals("hybrid") && enumTypeTrip == EnumTypeTrip.AVAILABLE &&
                !autoCompleteTxtOrigin.getText().toString().isEmpty() && !(time.compareTo(dateNow) < 0)) {

            numberPickerTime = (String.format("%s:%s", String.valueOf(npHour.getValue()).length() < 2
                            ? "0" + npHour.getValue() : npHour.getValue(),
                    String.valueOf(npMin.getValue()).length() < 2 ? "0" + npMin.getValue() : npMin.getValue()));

            btnPressed(spnReason.getSelectedItemPosition(), spnImportance.getSelectedItemPosition(),
                    spnCarType.getSelectedItemPosition(),
                    autoCompleteTxtOrigin.getText().toString(), autoCompleteTxtDes.getText().toString(),
                    edtDate.getText().toString(), numberPickerTime, enumTypeTrip,
                    chkBxMissionary.isChecked(), myRecyclerViewAdapter1.getList(), edtCommentAddTrip.getText().toString()
                    , edtOriginAddress.getText().toString(), edtDestinationAddress.getText().toString());

        } else {
            if (time.compareTo(dateNow) < 0)
                Toast.makeText(context, "امکان ثبت سفر برای تاریخ قبل از امروز وجود ندارد", Toast.LENGTH_SHORT).show();
            else if (edtOriginAddress.getText().toString().isEmpty() && App.modeOfInsert.equals("Map"))
                Toast.makeText(context, "پرکردن فیلد مبدا اجباریست", Toast.LENGTH_SHORT).show();
            else if (edtDestinationAddress.getText().toString().isEmpty() && App.modeOfInsert.equals("Map"))
                Toast.makeText(context, "پرکردن فیلد مقصد اجباریست", Toast.LENGTH_SHORT).show();
            else if (autoCompleteTxtOrigin.getText().toString().isEmpty() && App.modeOfInsert.equals("hybrid"))
                Toast.makeText(context, "پرکردن فیلد مبدا اجباریست", Toast.LENGTH_SHORT).show();
            else if (autoCompleteTxtDes.getText().toString().isEmpty() && App.modeOfInsert.equals("hybrid"))
                Toast.makeText(context, "پرکردن فیلد مقصد اجباریست", Toast.LENGTH_SHORT).show();

//            else if (edtCommentAddTrip.getText().toString().isEmpty())
//                Toast.makeText(context, "پرکردن فیلد توضیحات سفر الزامی می باشد", Toast.LENGTH_SHORT).show();
            else
                Toast.makeText(context, "آدرس می بایست مشخص گردد", Toast.LENGTH_SHORT).show();
        }
    }

    private void bindView() {
//        chkBoxInService = findViewById(R.id.chkBxAvailable1);
        ivWarningOrigin = findViewById(R.id.ivWarningOrigin1);
        ivWarningDes = findViewById(R.id.ivWarningDes1);
        ivWarningTripReason = findViewById(R.id.ivWarningTripReason1);
        ivWarningTripImportance = findViewById(R.id.ivWarningTripImportance1);
//        chkBxReturn = findViewById(R.id.chkBxReturn);
        chkBxMissionary = findViewById(R.id.chkBxMissionary);
        fb_mapShow_destinatiion = findViewById(R.id.fb_mapShow_destinatiion);
        fb_mapShow_origin = findViewById(R.id.fb_mapShow_origin);

        toolbar = findViewById(R.id.toolbar_add_trip1);
        cvMap = findViewById(R.id.cvMap2);
        LinearPredefined = findViewById(R.id.LinearPredefined);
        ivWarningTripCaption = findViewById(R.id.ivWarningTripCaption);
        ivWarningTripOrigin = findViewById(R.id.ivWarningTripOrigin);
        ivWarningTripdestination = findViewById(R.id.ivWarningTripdestination);
        rg_typeTrip = findViewById(R.id.rg_typeTrip);
        rb_roundAndRound = findViewById(R.id.rb_roundAndRound);
        rb_oneWay = findViewById(R.id.rb_oneWay);
        rb_available = findViewById(R.id.rb_available);

        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        setTitle("افزودن سفر");

//        txtApplicantName = findViewById(R.id.txtapplicantNameRegisterTrip);
        edtDate = findViewById(R.id.edtDateRegisterTrip1);
        edtDate.setText(Time.getNowPersianDate());

//        txtMobile = findViewById(R.id.txtMobileRegisterTrip);
        spnReason = findViewById(R.id.spinnerReason1);
        spnImportance = findViewById(R.id.spinnerImportance1);
        pbRegisterTrip = findViewById(R.id.pbRegisterTrip1);
        btnRegisterTrip = findViewById(R.id.btnRegisterTrip1);

        rlTextDes = findViewById(R.id.rlTextDes1);
        rlACtextDes = findViewById(R.id.rlACtextDes1);

        autoCompleteTxtOrigin = findViewById(R.id.autoCompleteTxtOrigin1);
        autoCompleteTxtDes = findViewById(R.id.autoCompleteTxtDes1);

        edtEnterNamePassenges = findViewById(R.id.edtEnterNamePassenges1);
        imgAddPassengers = findViewById(R.id.imgAdd1);
        rvAddPassenges = findViewById(R.id.recyclerViewAddPassengers1);

        edtDestinationAddress = findViewById(R.id.edtDestinationAddress);
        edtOriginAddress = findViewById(R.id.edtOriginAddress);

        fabResetMap = findViewById(R.id.fabResetMap);

        npHour = findViewById(R.id.npHour1);
        npMin = findViewById(R.id.npMin1);
        calander = Calendar.getInstance();
        npHour.setMinValue(0);
        npHour.setMaxValue(23);
        npHour.setFormatter(new NumberPicker.Formatter() {
            @Override
            public String format(int i) {
                return String.format("%02d", i);
            }
        });
        npHour.setValue(calander.get(Calendar.HOUR_OF_DAY));


        npMin.setMinValue(0);
        npMin.setMaxValue(59);
        npMin.setFormatter(new NumberPicker.Formatter() {
            @Override
            public String format(int i) {
                return String.format("%02d", i);
            }
        });
        npMin.setValue(calander.get(Calendar.MINUTE));


        spnCarType = findViewById(R.id.spinnerCarType1);

        edtCommentAddTrip = findViewById(R.id.edtCommentAddTrip);
//        txtApplicantName.setText(String.format("%s %s", App.userInfo.getStrName(), App.userInfo.getStrFamily()));
//        txtMobile.setText(Cache.getString("mobileNumber"));
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public void setSpnReasonData(List<String> spnReasonData) {
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(context, android.R.layout.simple_spinner_item, spnReasonData);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spnReason.setAdapter(dataAdapter);
    }

    public void setSpnImportanceData(List<String> importanceData) {
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(context, android.R.layout.simple_spinner_item, importanceData);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spnImportance.setAdapter(dataAdapter);
    }

    public void setSpnCarType(List<String> spnTypeCar) {
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(context, android.R.layout.simple_spinner_item, spnTypeCar);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spnCarType.setAdapter(dataAdapter);
    }

    public void finishActivity() {
        finish();
    }

    public void setZoom(GoogleMap googleMap) {

    }

    public void showOriginText(Spanned fromHtml, TextView.BufferType spannable) {
        if (App.mapMode == 3) {
            if (typeLocation.equals("origin")) {
                bTripS_SAD = true; // ااگر از نقشه مبدا را انتخاب کند
                autoCompleteTxtOrigin.setText(fromHtml, spannable);
            }
        } else
            edtOriginAddress.setText(fromHtml, spannable);
    }

    public void showDestinationText(Spanned fromHtml, TextView.BufferType spannable) {
        if (App.mapMode == 3) {
            if (typeLocation.equals("destination")) {
                bTripD_SAD = true; // ااگر از نقشه مقصد را انتخاب کند
                autoCompleteTxtDes.setText(fromHtml, spannable);
            }
        } else {
            edtDestinationAddress.setText(fromHtml, spannable);
        }

    }

    public void showIvWarningOrigin() {
        ivWarningOrigin.setVisibility(View.VISIBLE);
    }

    public void hideIvWarningOrigin() {
        ivWarningOrigin.setVisibility(View.GONE);
    }

    public void showIvWarningDes() {
        ivWarningDes.setVisibility(View.VISIBLE);
    }

    public void hideIvWarningDes() {
        ivWarningDes.setVisibility(View.GONE);
    }

    public void showIvWarningReason() {
        ivWarningTripReason.setVisibility(View.VISIBLE);
    }

    public void hideIvWarningReason() {
        ivWarningTripReason.setVisibility(View.GONE);
    }

    public void showIvWarningImportance() {
        ivWarningTripImportance.setVisibility(View.VISIBLE);
    }

    public void hideIvWarningImportance() {
        ivWarningTripImportance.setVisibility(View.GONE);
    }

    public void getOriginDes(ArrayAdapter<String> adapter) {
        autoCompleteTxtOrigin.setThreshold(1);
        autoCompleteTxtOrigin.setAdapter(adapter);

        autoCompleteTxtDes.setThreshold(1);
        autoCompleteTxtDes.setAdapter(adapter);
    }

    public void setOriginDes(List<String> originDes) {
        ArrayAdapter<String> adapter = new ArrayAdapter<>(context, R.layout.select_dialog_item_custom, originDes);
        autoCompleteTxtOrigin.setThreshold(1);
        autoCompleteTxtOrigin.setAdapter(adapter);
        autoCompleteTxtDes.setThreshold(1);
        autoCompleteTxtDes.setAdapter(adapter);
    }

    public void HideDestination() {

        rlACtextDes.setVisibility(View.GONE);
        rlTextDes.setVisibility(View.GONE);
    }

    public void showDestination() {
        rlACtextDes.setVisibility(View.VISIBLE);
        rlTextDes.setVisibility(View.VISIBLE);
    }

    public void showProgressBar() {
        pbRegisterTrip.setVisibility(View.VISIBLE);
        btnRegisterTrip.setVisibility(View.GONE);
    }

    public void hidePreogressBar() {
        pbRegisterTrip.setVisibility(View.GONE);
        btnRegisterTrip.setVisibility(View.VISIBLE);
        stopService(new Intent(context, LocationService.class));
    }

    private void initializeRecyclerViewAddPassengers() {
        linearLayoutManager = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);
        myRecyclerViewAdapter1 = new AddTripAdapter(this);
        myRecyclerViewAdapter1.setOnItemClickListener(this);
        rvAddPassenges.setAdapter(myRecyclerViewAdapter1);
        rvAddPassenges.setLayoutManager(linearLayoutManager);

        imgAddPassengers.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                String newName = edtEnterNamePassenges.getText().toString();
                if (!newName.equals("")) {
                    if (myRecyclerViewAdapter1.getItemCount() > 1) {
                        myRecyclerViewAdapter1.add(0, newName);
                        edtEnterNamePassenges.setText("");
                    } else {
                        myRecyclerViewAdapter1.add(0, newName);
                        edtEnterNamePassenges.setText("");
                    }
                }
            }
        });
    }

    @Override
    public void onItemClick(AddTripAdapter.ItemHolder item, int position) { // لیست پرسنل
        myRecyclerViewAdapter1.remove(position);
    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }

    @Override
    public void onMapReady(GoogleMap googleMap) {

        GoogleMap mMap = googleMap;
        googleMap.getUiSettings().setScrollGesturesEnabled(true);
        googleMap.getUiSettings().setZoomGesturesEnabled(true);
        googleMap.getUiSettings().setMapToolbarEnabled(false);

        googleMap.getUiSettings().setZoomControlsEnabled(true);
        googleMap.getUiSettings().setZoomGesturesEnabled(true);
        googleMap.getUiSettings().isTiltGesturesEnabled();

        if (AppCompatDelegate.getDefaultNightMode() == AppCompatDelegate.MODE_NIGHT_YES)
            googleMap.setMapStyle(new MapStyleOptions(getResources().getString(R.string.style_json)));

        mapIsReady(googleMap);
    }

    public List<String> getSpnReasonData() {
        List<String> reasons = new ArrayList<>();
        for (int i = 0; i < App.userInfo.getTripReason().size(); i++)
            reasons.add(App.userInfo.getTripReason().get(i).getStrComment());
        return reasons;
    }

    public List<String> getSpnTypeCar() {
        List<String> cartype = new ArrayList<>();
        for (int i = 0; i < App.userInfo.getMobileType().size(); i++) {
            cartype.add(App.userInfo.getMobileType().get(i).getStrComment());
        }
        return cartype;
    }

    public void setOriginAddress(String start_Address) {
        this.start_address = start_Address;
    }

    public void setDestinaionAddress(String end_Adrdress) {
        this.end_Address = end_Adrdress;
    }

    public List<String> getImportanceData() {
        List<String> importance = new ArrayList<>();
        for (int i = 0; i < App.userInfo.getTripImportance().size(); i++)
            importance.add(App.userInfo.getTripImportance().get(i).getStrComment());
        return importance;
    }

    public List<String> getOriginDes() {
        List<String> originDes = new ArrayList<>();
        for (int i = 0; i < App.userInfo.getTripSAD().size(); i++) {
            originDes.add(App.userInfo.getTripSAD().get(i).getStrName());
        }
        return originDes;
    }

    public void requestAddTrip(int spnReason, int spnImportance, int spnCarType
            , String autoCompleteTxtOrigin, String autoCompleteTxtDes, String edtDate
            , String numberPickerTime, EnumTypeTrip typeTrip, boolean chkBxMissionary, String list
            , String strComment, String strOriginAddress, String strDestintionAddress) {

        TripInsert tripInsert = new TripInsert();
        tripInsert.setTiTripReason((short) App.userInfo.getTripReason().get(spnReason).getTiTripReason());
        tripInsert.setTiTripImportance((short) App.userInfo.getTripImportance().get(spnImportance).getTiTripImportance());
        tripInsert.setMobileType((short) App.userInfo.getMobileType().get(spnCarType).getTiMobileType());

        switch (App.modeOfInsert) {
            case "Normal":
                tripInsert.setbSAndDBaseCurrentLoc(false);
                break;
            case "Map":
                tripInsert.setbSAndDBaseCurrentLoc(true);
                tripInsert.setFsLat(App.originLat);
                tripInsert.setFsLon(App.originLon);
                tripInsert.setfDLat(App.destinationLat);
                tripInsert.setfDLon(App.destinationLon);
                tripInsert.setStrSourceAddress(strOriginAddress);
                tripInsert.setStrDestinationAddress(strDestintionAddress);
                break;
            case "hybrid":
                tripInsert.setbSAndDBaseCurrentLoc(true);
                tripInsert.setFsLat(App.originLat);
                tripInsert.setFsLon(App.originLon);
                tripInsert.setfDLat(App.destinationLat);
                tripInsert.setfDLon(App.destinationLon);
                tripInsert.setStrSourceAddress(autoCompleteTxtOrigin);
                tripInsert.setStrDestinationAddress(autoCompleteTxtDes);
                break;
        }

        tripInsert.setStrComment(strComment);

        tripInsert.setStrTripDate(edtDate);
        tripInsert.setStrTripTime(numberPickerTime);

//        tripInsert.setbHaveReturn(chkBxReturn);
//        tripInsert.setbExclusive(chkBoxInService);
        tripInsert.setbMissionary(chkBxMissionary);

        tripInsert.setStrApplicantMobile(Cache.getString("mobileNumber"));
        tripInsert.setStrPassengersName(list);

        for (TripSAD tripSAD : App.userInfo.getTripSAD()) {
            if (autoCompleteTxtOrigin.equals(tripSAD.getStrName())) {
                tripInsert.setiTripSADSource(tripSAD.getiTripSad());
                if (!bTripS_SAD) {
                    iTripS_SAD = tripSAD.getiTripSad();
                }
            }
        }

        for (TripSAD tripSAD : App.userInfo.getTripSAD()) {
            if (autoCompleteTxtDes.equals(tripSAD.getStrName())) {
                tripInsert.setiTripSADDestination(tripSAD.getiTripSad());
                if (!bTripD_SAD) {
                    iTripD_SAD = tripSAD.getiTripSad();
                }
            }
        }

        if (App.modeOfInsert.equals("Normal")) {
            if (tripInsert.getiTripSADSource() == -1) {
                noValidOrigin();
                return;
            }
        }

        if (App.modeOfInsert.equals("Normal")) {
            if (tripInsert.getiTripSADDestination() == -1) {
                noValidDes();
                return;
            }
        }
        if (App.modeOfInsert.equals("Normal")) {
            if (tripInsert.getiTripSADSource() == tripInsert.getiTripSADDestination()) {
                ErrorEqualOriginDestination();
                return;
            }
        }
        if (App.modeOfInsert.equals("Map")) {
            if (tripInsert.getStrSourceAddress().equals(tripInsert.getStrDestinationAddress())) {
                ErrorEqualOriginDestination();
                return;
            }
        }

        if (enumTypeTrip == EnumTypeTrip.ONE_WAY) {

        } else if (enumTypeTrip == EnumTypeTrip.ROUND_AND_ROUND) {
            tripInsert.setbHaveReturn(true);
        } else if (enumTypeTrip == EnumTypeTrip.AVAILABLE) {
            tripInsert.setbExclusive(true);
        }

        APIService apiService = APIClient.getClient().create(APIService.class);
        Call<Integer> call = apiService.InsertTrip(tripInsert, iTripS_SAD, iTripD_SAD, App.Session);
        call.enqueue(new Callback<Integer>() {
            @Override
            public void onResponse(@NotNull Call<Integer> call, @NotNull Response<Integer> response) {
                if (response.code() == 200 && response.body() != null) {
                    tripInsertResult(response.body());
                    App.pursuitCode = response.body();
                } else {
                    tripInsertResult(-4);
                }
            }

            @Override
            public void onFailure(@NotNull Call<Integer> call, @NotNull Throwable t) {
                Log.i(TAG, "onFailure: " + t.toString());
                tripInsertResult(-1);
            }
        });
    }

    private Marker selectLocation;
    private Double mLat = 33.0;
    private Double mLong = 53.0;
    private GoogleMap gMap;

    private String date;
    private PersianDatePickerDialog picker;

    private BroadcastReceiver mBroadcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            receivedBroadcast(intent);
        }
    };

    private void receivedBroadcast(Intent intent) {
        if (intent.getAction().matches("android.intent.action.map_result_ok") ||
                intent.getAction().matches("android.intent.action.map_result_fail")) {
            getExtras(intent.getStringExtra("start_address"),
                    intent.getStringExtra("end_address"));
        }
    }

    private void getExtras(String start_address, String end_address) {
        try {
            setOriginAddress(Converter.valueChecked(start_address));
            setDestinaionAddress(Converter.valueChecked(end_address));
        } catch (Exception ignored) {
        }

        String textOrigin = "";
        String textDestination = "";
        try {

            if (!start_address.isEmpty() && !end_address.isEmpty()) {
                textOrigin = "<font color='" + ContextCompat.getColor(App.context, R.color.colorBlack) +
                        "'>" + start_address + "</font>";
                textDestination = "<font color='" + ContextCompat.getColor(App.context, R.color.colorBlack) +
                        "'>" + end_address + "</font>";
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                showOriginText(Html.fromHtml(textOrigin, Html.FROM_HTML_MODE_LEGACY), TextView.BufferType.SPANNABLE);
                showDestinationText(Html.fromHtml(textDestination, Html.FROM_HTML_MODE_LEGACY), TextView.BufferType.SPANNABLE);
            } else {
                showOriginText(Html.fromHtml(textOrigin), TextView.BufferType.SPANNABLE);
                showDestinationText(Html.fromHtml(textDestination), TextView.BufferType.SPANNABLE);
            }

        } catch (Exception ignored) {
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d("RunAndTestFromSalar", "Hello" + typeLocation);
        getExtras(App.GlobalStartAddress, App.GlobalEndAddress);
        if (typeLocation != null && App.Geo != null) {
            switch (typeLocation) {
                case "origin":
                    autoCompleteTxtOrigin.setText(App.Geo.getStrAddress());
                    break;
                case "destination":
                    autoCompleteTxtDes.setText(App.Geo.getStrAddress());
                    break;
            }
        }

    }

    private void calendar(EditText edtDate) {
        PersianCalendar persianCalendar = new PersianCalendar();
        @SuppressLint("SetTextI18n") DatePickerDialog datePickerDialog = DatePickerDialog.newInstance(
                (view, year, monthOfYear, dayOfMonth) -> {

                    if ((monthOfYear + 1) < 10 && dayOfMonth < 10) {
                        date = year + "/0" + (monthOfYear + 1) + "/0" + dayOfMonth;
                    } else if ((monthOfYear + 1) < 10) {
                        date = year + "/0" + (monthOfYear + 1) + "/" + dayOfMonth;
                    } else if (dayOfMonth < 10) {
                        date = year + "/" + (monthOfYear + 1) + "/0" + dayOfMonth;
                    } else {
                        date = year + "/" + (monthOfYear + 1) + "/" + dayOfMonth;
                    }

                    edtDate.setText(date);
                },
                persianCalendar.getPersianYear(),
                persianCalendar.getPersianMonth() - 1,
                persianCalendar.getPersianDay()
        );
        datePickerDialog.show(getFragmentManager(), "Datepickerdialog");
    }

    public void cvCalandarPressed(EditText edtDate) {
        final InputMethodManager imm = (InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.showSoftInput(edtDate, InputMethodManager.SHOW_IMPLICIT);

//        PersianCalendar initDate = new PersianCalendar();
//        initDate.setPersianDate(1370, 3, 13);

        picker = new PersianDatePickerDialog(context)
                .setPositiveButtonString("تایید")
                .setNegativeButton("انصراف")
                .setTodayButton("امروز")
                .setTodayButtonVisible(true)
                .setMinYear(1300)
                .setMaxYear(1450)
//                .setMaxYear(PersianDatePickerDialog.THIS_YEAR)
//                .setInitDate(initDate)
                .setActionTextColor(Color.GRAY)
//                .setTypeFace(typeface)
                .setListener(new Listener() {
                    @Override
                    public void onDateSelected(ir.hamsaa.persiandatepicker.util.PersianCalendar persianCalendar) {

//                        date = persianCalendar.getPersianYear() + "/"
//                                + persianCalendar.getPersianMonth() + "/"
//                                + persianCalendar.getPersianDay();

                        date = persianCalendar.getPersianYear() + "/" +
                                (String.valueOf(persianCalendar.getPersianMonth()).length() < 2 ? "0" + persianCalendar.getPersianMonth() : persianCalendar.getPersianMonth()) + "/" +
                                (String.valueOf(persianCalendar.getPersianDay()).length() < 2 ? "0" + persianCalendar.getPersianDay() : persianCalendar.getPersianDay());


//                             Toast.makeText(context, date, Toast.LENGTH_SHORT).show();
                        edtDate.setText(date);
                    }

                    @Override
                    public void onDismissed() {
                    }
                });
        picker.show();

    }

    public void spinnerTripReasonPressed(Spinner spnReason) {

        spnReason.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View v, int position, long id) {
                String item = parent.getItemAtPosition(position).toString();
                if (item.equals("انتخاب کنید")) {
                    showIvWarningReason();
                } else {
                    hideIvWarningReason();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

    }

    public void spinnerTripImportancePressed(Spinner spnImportance) {

        spnImportance.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View v, int position, long id) {
                String item = parent.getItemAtPosition(position).toString();
                if (item.equals("انتخاب کنید")) {
                    showIvWarningImportance();
                } else {
                    hideIvWarningImportance();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
    }

    public void viewLoaded() {
        IntentFilter iff = new IntentFilter();
        iff.addAction("android.intent.action.map_result_ok");
        iff.addAction("android.intent.action.map_result_fail");
        try {
            context.registerReceiver(mBroadcastReceiver, iff);
        } catch (IllegalArgumentException ignore) {
        }

        setSpnReasonData(getSpnReasonData());
        setSpnImportanceData(getImportanceData());

        setOriginDes(getOriginDes());

        setSpnCarType(getSpnTypeCar());
    }

    public void chkInServiceChecked(boolean chkInServiceisChecked) {
        if (chkInServiceisChecked)
            HideDestination();
        else
            showDestination();
    }

    public void btnPressed(int spnReason, int spnImportance, int spnCarType, String autoCompleteTxtOrigin,
                           String autoCompleteTxtDes, String edtDate, String numberPickerTime, EnumTypeTrip enumTypeTrip
            , boolean chkBxMissionary, String list, String strComment
            , String strOriginaddress, String strDestinationAddress) {
        showProgressBar();
        requestAddTrip(spnReason, spnImportance, spnCarType, autoCompleteTxtOrigin, autoCompleteTxtDes
                , edtDate, numberPickerTime, enumTypeTrip, chkBxMissionary, list
                , strComment, strOriginaddress, strDestinationAddress);
    }

    public void tripInsertResult(Integer result) {
        Log.i(TAG, "tripInsertResult: " + result);
        hidePreogressBar();
        if (result == -4) {
            Toaster.shorter(context.getString(R.string.serverFaield));
        } else if (result == -1) {
            Toaster.shorter(context.getString(R.string.connectionFaield));
        } else if (result == 0) {
            Toaster.shorter("سفر شما قبلا ثبت شده است");
        } else if (result == 100) {
            Intent intent = new Intent(AddTripWithMapActivity.this, LoginActivity.class);
            startActivity(intent);

        } else if (result == -2) {
            Toaster.shorter("بازه ی زمانی درخواست شما به پایان رسیده است،لطفا در بازه مجاز اقدام به ثبت درخواست نمایید");
        } else {
//            Toast.makeText(context, "کد رهگیری شما" + result, Toast.LENGTH_SHORT).show();
            Toaster.shorter("سفر شما با موفقیت ثبت شد");

            context.startActivity(new Intent(context, MainActivity.class));
            ((Activity) context).finish();
        }
    }

    public void noValidDes() {
        Toaster.shorter("آدرس مقصد می بایست از موارد پیشنهادی انتخاب گردد");
        hidePreogressBar();
    }

    public void noValidOrigin() {
        Toaster.shorter("آدرس مبدا می بایست از موارد پیشنهادی انتخاب گردد");
        hidePreogressBar();
    }

    public void ErrorEqualOriginDestination() {
        Toaster.shorter("مبدا و مقصد نباید یکسان انتخاب گردند");
        hidePreogressBar();
    }

    public void mapIsReady(GoogleMap googleMap) {

//        callDistance(originLatLon, destinationLatLon, googleMap);
        googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(originLatLon, 12));
        googleMap.addMarker(new MarkerOptions().position(originLatLon).icon(Converter.
                drawableToBitmap(context.getResources().getDrawable(R.drawable.new_ic_map))));
        originSelectLocation.showInfoWindow();

        googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(destinationLatLon, 12));
        googleMap.addMarker(new MarkerOptions().position(destinationLatLon).icon(Converter.
                drawableToBitmap(context.getResources().getDrawable(R.drawable.new_dic_map))));
        destintionSelectLocation.showInfoWindow();

        //zoom automatically in center of 2 markers
        Marker markers[] = {originSelectLocation, destintionSelectLocation};

        int width = context.getResources().getDisplayMetrics().widthPixels;
        int height = context.getResources().getDisplayMetrics().heightPixels;
        LatLngBounds.Builder builder = new LatLngBounds.Builder();
        for (Marker marker : markers) {
            builder.include(marker.getPosition());
        }
        LatLngBounds bounds = builder.build();
        int padding = 0; // offset from edges of the map in pixels
        CameraUpdate cu = CameraUpdateFactory.newLatLngBounds(bounds, 120);
        try {
            googleMap.moveCamera(cu);
        } catch (Exception ignored) {
        }


    }

    public void setClickOnOrigin(GoogleMap googleMap) {
        LatLng point = new LatLng(mLat, mLong);

        try {
            googleMap.clear();
            if (selectLocation != null)
                selectLocation.remove();

            if (ActivityCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED)
                googleMap.setMyLocationEnabled(true);
            else
                googleMap.setMyLocationEnabled(false);

            float mZoom = googleMap.getCameraPosition().zoom;
            if (mZoom < 16)
                mZoom = 15;
            mLat = point.latitude;
            mLong = point.longitude;

            CameraPosition newCamPos = new CameraPosition(new LatLng(mLat, mLong),
                    mZoom,
                    googleMap.getCameraPosition().tilt, //use old tilt
                    googleMap.getCameraPosition().bearing); //use old bearing
            googleMap.animateCamera(CameraUpdateFactory.newCameraPosition(newCamPos), 1500, null);

            selectLocation = googleMap.addMarker(new MarkerOptions()
                    .position(point)
                    .icon(BitmapDescriptorFactory.fromResource(R.drawable.ic_origin_marker))
                    .title(""));
        } catch (Exception ignored) {
        }
    }

    public void backToMap() {
        context.startActivity(new Intent(context, MapsForAddTripActivity.class));
        finishActivity();
    }

    public void setLocation(GoogleMap googleMap) {
        try {
            Location location = googleMap.getMyLocation();
            mLat = location.getLatitude();
            mLong = location.getLongitude();

            float mZoom = googleMap.getCameraPosition().zoom;
            if (mZoom < 16)
                mZoom = 15;

            CameraPosition newCamPos = new CameraPosition(new LatLng(mLat, mLong),
                    mZoom,
                    googleMap.getCameraPosition().tilt, //use old tilt
                    googleMap.getCameraPosition().bearing); //use old bearing
            googleMap.animateCamera(CameraUpdateFactory.newCameraPosition(newCamPos), 1500, null);

            selectLocation = googleMap.addMarker(new MarkerOptions()
                    .position(new LatLng(mLat, mLong))
                    .icon(BitmapDescriptorFactory.fromResource(R.drawable.ic_origin_marker))
                    .title(""));
        } catch (Exception ignored) {
        }
    }

    private void animateMarker(final Marker marker, final LatLng toPosition,
                               final boolean hideMarker) {
        final Handler handler = new Handler();
        final long start = SystemClock.uptimeMillis();
        Projection proj = gMap.getProjection();
        Point startPoint = proj.toScreenLocation(marker.getPosition());
        final LatLng startLatLng = proj.fromScreenLocation(startPoint);
        final long duration = 500;

        final Interpolator interpolator = new LinearInterpolator();

        handler.post(new Runnable() {
            @Override
            public void run() {
                long elapsed = SystemClock.uptimeMillis() - start;
                float t = interpolator.getInterpolation((float) elapsed
                        / duration);
                double lng = t * toPosition.longitude + (1 - t)
                        * startLatLng.longitude;
                double lat = t * toPosition.latitude + (1 - t)
                        * startLatLng.latitude;
                marker.setPosition(new LatLng(lat, lng));

                if (t < 1.0) {
                    // Post again 16ms later.
                    handler.postDelayed(this, 16);
                } else {
                    if (hideMarker) {
                        marker.setVisible(false);
                    } else {
                        marker.setVisible(true);
                    }
                }
            }
        });
    }
}
