package com.rayanandisheh.peysepar.passenger.view.Adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.rayanandisheh.peysepar.passenger.R;
import com.rayanandisheh.peysepar.passenger.models.News;
import com.rayanandisheh.peysepar.passenger.view.Activity.NewsDetailActivity;

import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class NewsAdapter extends RecyclerView.Adapter<NewsAdapter.ViewHolder> {

    private List<News> modelNews;
    private Context context;

    public NewsAdapter(List<News> modelNews, Context context) {
        this.modelNews = modelNews;
        this.context = context;
    }

    public void clear() {
        modelNews.clear();
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public NewsAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int i) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_news1, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull NewsAdapter.ViewHolder holder, int position) {

        News model = modelNews.get(position);
        holder.row_news_description.setText(model.getStrDateTime());
        holder.row_news_title.setText(model.getStrTitle());
        //todo add counter
//        holder.row_news_iCountView.setText(model.getICount); //

//        Picasso.get()
//                .load(model.getUrl())
//                .placeholder(R.drawable.picture_loading)
//                .error(R.drawable.picture_loading)
//                .resize(150, 150)
//                .into(holder.img);

        Glide.with(context).load(model.getUrl()).into(holder.img);

        if (model.isbVisit())
            holder.row_news_viewer.setVisibility(View.VISIBLE);
        else
            holder.row_news_viewer.setVisibility(View.INVISIBLE);


        holder.itemView.setOnClickListener(v -> {
            NewsDetailActivity.model = model;
            context.startActivity(new Intent(context, NewsDetailActivity.class)
                    .setFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        });
    }

    @Override
    public int getItemCount() {
        return modelNews.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        CircleImageView img;
        TextView row_news_viewer, row_news_iCountView, row_news_description, row_news_title;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            row_news_viewer = itemView.findViewById(R.id.row_news_viewer);
            row_news_iCountView = itemView.findViewById(R.id.row_news_iCountView);
            row_news_description = itemView.findViewById(R.id.row_news_description);
            row_news_title = itemView.findViewById(R.id.row_news_title);
            img = itemView.findViewById(R.id.img_row_news);
        }
    }
}
