package com.rayanandisheh.peysepar.passenger.helpers;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;

import java.io.ByteArrayOutputStream;

public class Base64Util {

    private static final int IMG_WIDTH = 640;
    private static final int IMG_HEIGHT = 480;

    //encode image(from image path) to base64 string
    public static String encodeBitmap(String pathOfYourImage) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        Bitmap bitmap = BitmapFactory.decodeFile(pathOfYourImage);
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);
        byte[] imageBytes = baos.toByteArray();
        return Base64.encodeToString(imageBytes, Base64.DEFAULT);
    }

    //decode base64 string to image
    public static Bitmap decodebitmap(String imageString) {
        byte[] imageBytes = Base64.decode(imageString, Base64.DEFAULT);
        return BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.length);
    }


    //encode image(image from drawable) to base64 string
//    public String encodeDrawable(int res, int id){
//        ByteArrayOutputStream baos = new ByteArrayOutputStream();
//        Bitmap bitmap = BitmapFactory.decodeResource(res, id);
//        bitmap.compress(Bitmap.CompressFormat.JPEG,100,baos);
//        byte[] imageBytes = baos.toByteArray();
//        return Base64.encodeToString(imageBytes, Base64.DEFAULT);
//    }


//    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
//    Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
//    Bitmap bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.image);
// decodedByte.compress(Bitmap.CompressFormat.PNG, 100, byteArrayOutputStream);
//    byte[] imageBytes = byteArrayOutputStream.toByteArray();
//    String imageString = Base64.encodeToString(imageBytes, Base64.DEFAULT);
//    imageBytes = Base64.decode(imageString, Base64.DEFAULT);
//    Bitmap decodedImage = BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.length);


    public static Bitmap convertStringToBitmap(String base64String) {
        return convertString64ToImage(resizeBase64Image(base64String));
    }

    private static Bitmap convertString64ToImage(String base64String) {
        byte[] decodedString = Base64.decode(base64String, Base64.DEFAULT);
        return BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
    }

    private static String resizeBase64Image(String base64image) {
        byte[] encodeByte = Base64.decode(base64image.getBytes(), Base64.DEFAULT);
        BitmapFactory.Options options = new BitmapFactory.Options();
        Bitmap image = BitmapFactory.decodeByteArray(encodeByte, 0, encodeByte.length, options);

        if (image.getHeight() == 400 && image.getWidth() == 400) {
            return base64image;
        }
        image = Bitmap.createScaledBitmap(image, IMG_WIDTH, IMG_HEIGHT, false);

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        image.compress(Bitmap.CompressFormat.PNG, 100, baos);

        byte[] b = baos.toByteArray();
        System.gc();
        return Base64.encodeToString(b, Base64.NO_WRAP);
    }
}
