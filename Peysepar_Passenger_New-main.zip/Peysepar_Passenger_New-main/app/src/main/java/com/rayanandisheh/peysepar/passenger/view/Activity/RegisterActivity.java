package com.rayanandisheh.peysepar.passenger.view.Activity;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.rayanandisheh.peysepar.passenger.R;
import com.rayanandisheh.peysepar.passenger.customes.mAppCompatActivity;
import com.rayanandisheh.peysepar.passenger.helpers.App;
import com.rayanandisheh.peysepar.passenger.helpers.Cache;
import com.rayanandisheh.peysepar.passenger.helpers.Toaster;
import com.rayanandisheh.peysepar.passenger.models.Chart;
import com.rayanandisheh.peysepar.passenger.models.MobileDomain;
import com.rayanandisheh.peysepar.passenger.models.Register;
import com.rayanandisheh.peysepar.passenger.services.APIClient;
import com.rayanandisheh.peysepar.passenger.services.APIService;
import com.toptoche.searchablespinnerlibrary.SearchableSpinner;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class RegisterActivity extends mAppCompatActivity {
    Context context = this;
    EditText etFirstName, etLastName, etNCode, etPassword, etRepeatPassword;

    Button btRegister;
    ProgressBar pbRegister;
    RadioGroup radioGroup;
    RadioButton radioButton;
    TextView txtRayan, txtMobileNumber, txtMapAddress;
    EditText edtAddress;
    String strAddress = "";
    SearchableSpinner spnSituation, spnDomain;
    List<String> situationList = new ArrayList<>();
    ImageView ivWarningNameRegister, ivWarningFamilyRegister, ivWarningMobilePhoneRegister, ivWarningSituationRegister;

    List<MobileDomain> domains = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        bindViews();
        //getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        GetChart();
        GetDomains();
        txtMobileNumber.setText(App.mobileFirstRunning);
        txtMapAddress.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gotoMap(context);
            }
        });

        spinnerSituationPressed(spnSituation);

        etFirstName.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.length() < 2)
                    ivWarningNameRegister.setVisibility(View.VISIBLE);
                else
                    ivWarningNameRegister.setVisibility(View.GONE);

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        etLastName.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.length() < 2)
                    ivWarningFamilyRegister.setVisibility(View.VISIBLE);
                else
                    ivWarningFamilyRegister.setVisibility(View.GONE);
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

//        etMobileNumber.addTextChangedListener(new TextWatcher() {
//            @Override
//            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
//            }
//
//            @Override
//            public void onTextChanged(CharSequence s, int start, int before, int count) {
//                if (s.length() == 11)
//                    ivWarningMobilePhoneRegister.setVisibility(View.GONE);
//                else
//                    ivWarningMobilePhoneRegister.setVisibility(View.VISIBLE);
//            }
//
//            @Override
//            public void afterTextChanged(Editable s) {
//            }
//        });

        btRegister.setOnClickListener(v -> btnClicked());
    }

    private void GetDomains() {
        APIClient.getClient().create(APIService.class).MobileDomain().enqueue(new Callback<List<MobileDomain>>() {
            @Override
            public void onResponse(@NonNull Call<List<MobileDomain>> call, @NonNull Response<List<MobileDomain>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    domains.addAll(response.body());
                    setDomainSpinner(response.body());
                }
            }

            @Override
            public void onFailure(@NonNull Call<List<MobileDomain>> call, @NonNull Throwable t) {
                Log.d("mobileDomain", "onFailure: " + t.getLocalizedMessage());
            }
        });
    }

    private void setDomainSpinner(List<MobileDomain> data) {
        List<String> domains = new ArrayList<>();
        for (MobileDomain domain :
                data) {
            domains.add(domain.getStrComment());
        }
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, R.layout.item_spinner, domains);
        spnDomain.setAdapter(adapter);
        spnDomain.setTitle("");
        spnDomain.setPositiveButton("تایید");
    }

    private void bindViews() {

        etFirstName = findViewById(R.id.etFirstName);
        etLastName = findViewById(R.id.etLastName);
        radioGroup = findViewById(R.id.radioGroupRegister);
        spnSituation = findViewById(R.id.spinnerSituation);
        spnDomain = findViewById(R.id.spinnerDomain);
        txtMapAddress = findViewById(R.id.txtMapAddress);
        edtAddress = findViewById(R.id.edtAddress);
//        String selectedText = ((RadioButton)findViewById(radioGroup.getCheckedRadioButtonId())).getText().toString();
        radioButton = findViewById(radioGroup.getCheckedRadioButtonId());

//        etNCode = findViewById(R.id.etNCode);

        txtMobileNumber = findViewById(R.id.txtMobileNumber);
//        etPassword = findViewById(R.id.etPassword);
//        etRepeatPassword = findViewById(R.id.etRepeatPassword);
        btRegister = findViewById(R.id.btRegister);
        pbRegister = findViewById(R.id.pbRegister);

//        tvGoBack.setOnClickListener(v -> onBackPressed());

        ivWarningNameRegister = findViewById(R.id.ivWarningNameRegister);
        ivWarningFamilyRegister = findViewById(R.id.ivWarningFamilyRegister);
        ivWarningMobilePhoneRegister = findViewById(R.id.ivWarningMobilePhoneRegister);
        ivWarningSituationRegister = findViewById(R.id.ivWarningSituationRegister);
    }

    public void showIvWarningReason() {
        ivWarningSituationRegister.setVisibility(View.VISIBLE);
    }

    public void hideIvWarningReason() {
        ivWarningSituationRegister.setVisibility(View.GONE);
    }

    private void btnClicked() {

//        int selectedId=radioGroup.getCheckedRadioButtonId();
//        radioButton=findViewById(selectedId);

//        String selectedText = ((RadioButton)findViewById(radioGroup.getCheckedRadioButtonId())).getText().toString();

        String sexualityType = radioButton.getText().toString();

//        presenter.btRegisterPressed(
//                etFirstName.getText().toString(),
//                etLastName.getText().toString(),
//                txtMobileNumber.getText().toString(),
//                sexualityType);

        String strChart = "";
        String situation = spnSituation.getSelectedItem().toString();
        for (int i = 0; App.chartList.size() > i; i++) {
            if (App.chartList.get(i).getStrComment().equals(situation))
                strChart = App.chartList.get(i).getStrChart();
        }

        if (strAddress == null)
            strAddress = edtAddress.getText().toString();
        btRegisterPressed(strAddress,
                strChart,
                etFirstName.getText().toString(),
                etLastName.getText().toString(),
                txtMobileNumber.getText().toString(),
                sexualityType);

    }

    public void startLoading() {
        btRegister.setVisibility(View.GONE);
        pbRegister.setVisibility(View.VISIBLE);
    }

    public void stopLoading() {
        pbRegister.setVisibility(View.GONE);
        btRegister.setVisibility(View.VISIBLE);
    }

    public void showFirstNameError(String string) {
        etFirstName.setError(string);
        etFirstName.requestFocus();
    }

    public void showLastNameError(String string) {
        etLastName.setError(string);
        etLastName.requestFocus();
    }

    public void showNationalCodeError(String string) {
        etNCode.setError(string);
        etNCode.requestFocus();
    }

    public void showMobileNumberError(String string) {

//            etMobileNumber.setError(string);
//            etMobileNumber.requestFocus();
//        }else if(!etMobileNumber.startsWith("09")){
//            etMobileNumber.setError("شماره موبایل می بایست با 09 شروع شود");
//            etMobileNumber.requestFocus();
//        }else if(string.length()!=11 && string.length()!=0){
//            etMobileNumber.setError("شماره موبایل می بایست 11 رقم باشد");
//            etMobileNumber.requestFocus();
//        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        setaddress(context);
    }

    public void showPasswordError(String string) {
        etPassword.setError(string);
        etPassword.requestFocus();
    }

    public void showRepeatPasswordError(String string) {
        etRepeatPassword.setError(string);
        etRepeatPassword.requestFocus();
    }

    public void showErrorZeroFirstName() {
        etFirstName.setError("وارد کردن نام الزامیست");
//        ivWarningNameRegister.setVisibility(View.VISIBLE);
    }

    public void showErrorChart() {
        Toaster.shorter("انتخاب جایگاه سازمانی الزامی می باشد.");
    }

    public void setAddressText(String start_address) {
        edtAddress.setText(start_address);
        strAddress = start_address;
    }

    public void showErrorNotCorrectFirstName() {
        etFirstName.setError("نام وارد شده صحیح نمی باشد");
//        ivWarningNameRegister.setVisibility(View.VISIBLE);
    }

    public void showErrorZeroLastName() {
        etLastName.setError("وارد کردن نام خانوادگی الزامیست");
//        ivWarningFamilyRegister.setVisibility(View.VISIBLE);
    }

    public void showErrorNotCorrectLastName() {
        etLastName.setError("نام خانوادگی وارد شده صحیح نمی باشد");
//        ivWarningFamilyRegister.setVisibility(View.VISIBLE);
    }

    public void setSpinnerData(List<Chart> chartList) {
        for (int i = 0; chartList.size() > i; i++) {
            String s = chartList.get(i).getStrComment();
            situationList.add(s);

        }
//        ArrayAdapter<String> situationAdapter = new ArrayAdapter<String>(context, android.R.layout.simple_spinner_item, situationList);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(getApplicationContext(),
                R.layout.item_spinner, situationList);
        spnSituation.setAdapter(adapter);
        adapter.notifyDataSetChanged();
//        TextView tv = findViewById(R.id.tvSpinner);
//        Typeface tf = Typeface.createFromAsset(getAssets(), "IRANSansMobile.ttf");
//        tv.setTypeface(tf);
        spnSituation.setTitle("");
        spnSituation.setPositiveButton("تایید");
//        situationAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
//        spnSituation.setAdapter(situationAdapter);
//        spnSituation.setSelection(situationList.indexOf(0));
    }

    public void showErrorZeroMobileNumber() {
//        etMobileNumber.setError("وارد کردن شماره موبایل الزامیست");
//        ivWarningMobilePhoneRegister.setVisibility(View.VISIBLE);
    }

    public void showError09MobileNumber() {
//        etMobileNumber.setError("شماره موبایل می بایست با 09 شروع گردد");
//        ivWarningMobilePhoneRegister.setVisibility(View.VISIBLE);
    }

    public void showErrorNotCorrectMobilePhone() {
//        etMobileNumber.setError("شماره موبایل وارد شده صحیح نمی باشد");
//        ivWarningMobilePhoneRegister.setVisibility(View.VISIBLE);
    }

    private BroadcastReceiver mBroadcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            receivedBroadcast(intent);
        }
    };

    private void receivedBroadcast(Intent intent) {
        if (intent.getAction().matches("android.intent.action.map_result_ok") ||
                intent.getAction().matches("android.intent.action.map_result_fail")) {
            getExtras(intent.getStringExtra("start_address"),
                    intent.getStringExtra("end_address"));
        }
    }

    private void getExtras(String start_address, String end_address) {
        try {
            setAddressText(start_address);
        } catch (Exception ignored) {
        }
    }

    public void btRegisterPressed(String strAddress, String strChart, String firstName, String lastName
            , String mobileNumber, String sexuality) {

        if (firstName.isEmpty())
            showErrorZeroFirstName();
        else if (strChart.isEmpty())
            showErrorChart();
        else if (firstName.length() < 2)
            showErrorNotCorrectFirstName();
        else if (lastName.isEmpty())
            showErrorZeroLastName();
        else if (lastName.length() < 2)
            showErrorNotCorrectLastName();
        else if (mobileNumber.isEmpty())
            showErrorZeroMobileNumber();
        else if (mobileNumber.length() != 11)
            showErrorNotCorrectMobilePhone();
        else if (!mobileNumber.startsWith("09"))
            showError09MobileNumber();
        else {
            startLoading();
            register(strAddress, strChart, firstName, lastName, mobileNumber, sexuality);
        }
    }

    public void spinnerSituationPressed(Spinner spnSituation) {
        spnSituation.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View v, int position, long id) {
                String item = parent.getItemAtPosition(position).toString();
                if (item.equals("انتخاب کنید")) {
                    showIvWarningReason();
                } else {
                    hideIvWarningReason();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
    }

    public void viewLoaded() {
        setSpinnerData(App.chartList);
    }

    public void setSpnSituationData(List<Chart> chartList) {
        setSpinnerData(chartList);
    }

    public void setToast(int i) {
        if (i == -4)
            Toaster.shorter("خطا در اطلاعات دریافتی");
        else if (i == -5)
            Toaster.shorter("خطا در برقراری ارتباط با سرور");
    }

    public void gotoMap(Context context) {
        context.startActivity(new Intent(context, MapsChooseOriginActivity.class));
    }

    public void setaddress(Context context) {
        IntentFilter iff = new IntentFilter();
        iff.addAction("android.intent.action.map_result_ok");
        iff.addAction("android.intent.action.map_result_fail");
        try {
            context.registerReceiver(mBroadcastReceiver, iff);
        } catch (IllegalArgumentException ignore) {
        }
    }

    public void registerResult(int result) {
        stopLoading();

        if (result == -4) {
            Toaster.shorter(context.getString(R.string.connectionFaield));
        } else if (result == -1)
            Toaster.shorter(context.getString(R.string.serverFaield));
        else if (result == -2) {
            Toaster.shorter("شما قبلا ثبت نام کرده اید.");
        } else if (result == 1) {
            context.startActivity(new Intent(context, ActivationActivity.class));
            ((Activity) context).finish();

//        switch (result) {
//            case -1:
//                Toaster.shorter(context.getString(R.string.connectionFaield));
//                break;
//            case -4:
//                Toaster.shorter(context.getString(R.string.serverFaield));
//                break;
//            case 1:
//                context.startActivity(new Intent(context, ActivationActivity.class));
//                Toaster.longer(context.getString(R.string.validateYourNumber));
//                break;
//            default:
//                break;
//        }
//    }
        }
    }

    public void register(String strAddress, String strChart, String firstName, String lastName
            , String mobileNumber, String sexuality) {

        Register register = new Register();
        register.setStrName(firstName);
        register.setStrFamily(lastName);
        register.setStrMobile(mobileNumber);
        register.setStrChart(strChart);
        if (strAddress == null)
            strAddress = "";
        register.setStrAddress(strAddress);
        register.setLat(App.selectedPosition.latitude);
        register.setLon(App.selectedPosition.longitude);
        /*register.setLat(Cache.getLat("selectedPositionLat", 0));
        register.setLon(Cache.getLng("selectedPositionLon", 0));*/

//        // : 12/22/2018 delete below saving. phone must be save after request
//        Cache.setString("mobileNumber", mobileNumber);

        if (sexuality.equals("مرد")) {
            register.setTiSex(1);
        } else {
            register.setTiSex(2);
        }

        register.setiMobileDomain(domains.get(spnDomain.getSelectedItemPosition()).getiMobileDomain());

        APIService apiService = APIClient.getClient().create(APIService.class);
        Call<Register> call = apiService.RegisterUser(register);
        call.enqueue(new Callback<Register>() {
            @Override
            public void onResponse(@NonNull Call<Register> call, @NonNull Response<Register> response) {
                if (response.code() == 200 && response.body() != null) {
                    registerResult(response.body().getResult());
                    //save values behalf of sharepref...
                    App.register.setStrMobile(mobileNumber);
                    Cache.setString("mobileNumber", mobileNumber);
                } else
                    registerResult(-1);
            }

            @Override
            public void onFailure(@NonNull Call<Register> call, @NonNull Throwable t) {
                registerResult(-4);
            }
        });
    }

    public void GetChart() {

        APIService apiService = APIClient.getClient().create(APIService.class);
        Call<List<Chart>> call = apiService.GetChart();
        call.enqueue(new Callback<List<Chart>>() {
            @Override
            public void onResponse(@NotNull Call<List<Chart>> call, @NotNull Response<List<Chart>> response) {
                if (response.code() == 200 && response.body() != null) {
                    App.chartList = response.body();
                    setSpnSituationData(App.chartList);

                } else
                    setToast(-4);
            }

            @Override
            public void onFailure(@NotNull Call<List<Chart>> call, @NotNull Throwable t) {
                setToast(-5);
            }
        });
    }
}
