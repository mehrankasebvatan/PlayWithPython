package com.rayanandisheh.peysepar.passenger.models;

import com.google.gson.annotations.SerializedName;

public class Geocoding {

    @SerializedName("fLat")
    private double fLat;
    @SerializedName("fLon")
    private double fLon;
    @SerializedName("strAddress")
    private String strAddress;
    @SerializedName("strState")
    private String strState;
    @SerializedName("strCity")
    private String strCity;
    @SerializedName("strRouteName")
    private String strRouteName;
    @SerializedName("strPlace")
    private String strPlace;
    @SerializedName("strMunicipalityZone")
    private String strMunicipalityZone;
    @SerializedName("bInTrafficZone")
    private boolean bInTrafficZone;
    @SerializedName("bInOdEvenZzone")
    private boolean bInOdEvenZzone;
    @SerializedName("Result")
    private int Result;
    @SerializedName("strComment")
    private String strComment;

    public double getfLat() {
        return fLat;
    }

    public void setfLat(double fLat) {
        this.fLat = fLat;
    }

    public double getfLon() {
        return fLon;
    }

    public void setfLon(double fLon) {
        this.fLon = fLon;
    }

    public String getStrAddress() {
        return strAddress;
    }

    public void setStrAddress(String strAddress) {
        this.strAddress = strAddress;
    }

    public String getStrState() {
        return strState;
    }

    public void setStrState(String strState) {
        this.strState = strState;
    }

    public String getStrCity() {
        return strCity;
    }

    public void setStrCity(String strCity) {
        this.strCity = strCity;
    }

    public String getStrRouteName() {
        return strRouteName;
    }

    public void setStrRouteName(String strRouteName) {
        this.strRouteName = strRouteName;
    }

    public String getStrPlace() {
        return strPlace;
    }

    public void setStrPlace(String strPlace) {
        this.strPlace = strPlace;
    }

    public String getStrMunicipalityZone() {
        return strMunicipalityZone;
    }

    public void setStrMunicipalityZone(String strMunicipalityZone) {
        this.strMunicipalityZone = strMunicipalityZone;
    }

    public boolean isbInTrafficZone() {
        return bInTrafficZone;
    }

    public void setbInTrafficZone(boolean bInTrafficZone) {
        this.bInTrafficZone = bInTrafficZone;
    }

    public boolean isbInOdEvenZzone() {
        return bInOdEvenZzone;
    }

    public void setbInOdEvenZzone(boolean bInOdEvenZzone) {
        this.bInOdEvenZzone = bInOdEvenZzone;
    }

    public int getResult() {
        return Result;
    }

    public void setResult(int result) {
        Result = result;
    }

    public String getStrComment() {
        return strComment;
    }

    public void setStrComment(String strComment) {
        this.strComment = strComment;
    }
}
