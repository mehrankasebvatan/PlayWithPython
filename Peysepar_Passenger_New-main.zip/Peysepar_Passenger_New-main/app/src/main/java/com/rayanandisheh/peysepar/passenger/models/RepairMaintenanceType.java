package com.rayanandisheh.peysepar.passenger.models;

public class RepairMaintenanceType {
    public String strComment;
    public int iRepairMaintenanceType;

    public String getStrComment() {
        return strComment;
    }

    public void setStrComment(String strComment) {
        this.strComment = strComment;
    }

    public int getiRepairMaintenanceType() {
        return iRepairMaintenanceType;
    }

    public void setiRepairMaintenanceType(int iRepairMaintenanceType) {
        this.iRepairMaintenanceType = iRepairMaintenanceType;
    }
}
