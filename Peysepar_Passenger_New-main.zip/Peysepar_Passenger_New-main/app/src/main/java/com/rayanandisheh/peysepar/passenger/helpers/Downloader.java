package com.rayanandisheh.peysepar.passenger.helpers;

import android.app.DownloadManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import androidx.core.content.FileProvider;
import android.util.Log;
import android.widget.Toast;
import com.rayanandisheh.peysepar.passenger.BuildConfig;
import com.rayanandisheh.peysepar.passenger.R;

import java.io.File;

import static android.content.Context.DOWNLOAD_SERVICE;

public class Downloader {


        public static long DLid;
        android.app.DownloadManager downloadManager ;

        public void DownloadUpdateApp(Context context) {

            if (Validate.downloadUrl(App.userInfo.getDownloadLinkApp())) {
                IntentFilter filter = new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE);
                try {
                    context.registerReceiver(downloadReceiver, filter);
                } catch (IllegalArgumentException ignored) {
                }
                Uri apk_uri = Uri.parse(App.userInfo.getDownloadLinkApp());
                DLid = DownloadData(apk_uri, context);
            } else Toaster.shorter("لینک دانلود اشتباه دریافت شده");
        }

        private long DownloadData(Uri uri, Context context) {
            long downloadReference;
            downloadManager = (android.app.DownloadManager) context.getSystemService(DOWNLOAD_SERVICE);
            android.app.DownloadManager.Request request = new DownloadManager.Request(uri);
            request.setTitle(context.getResources().getString(R.string.app_name2));
            request.setDescription("بروزرسانی");
            request.setShowRunningNotification(true);
            request.setNotificationVisibility(android.app.DownloadManager.Request.
                    VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            request.setMimeType("application/vnd.android.package-archive");
            request.setVisibleInDownloadsUi(true);
            request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS,
                    "Passenger.apk");
            assert downloadManager != null;
            downloadReference = downloadManager.enqueue(request);
            return downloadReference;
        }

        private BroadcastReceiver downloadReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                long referenceId = intent.getLongExtra(android.app.DownloadManager.EXTRA_DOWNLOAD_ID,
                        -1);
                if (referenceId == DLid) {

                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {

                        try {
                            File toInstall = new File(Environment.getExternalStorageDirectory(),
                                    "Download/Passenger.apk");
                            if (toInstall.exists()) {
                                Uri apkUri = FileProvider.getUriForFile(context, BuildConfig.APPLICATION_ID + ".com.vansuita.pickimage.provider", toInstall);
//                            Intent intent1 = new Intent(Intent.ACTION_INSTALL_PACKAGE);
//                            intent1.setData(apkUri);
//                            intent.setDataAndType(apkUri, "application/vnd.android.package-archive");
//                            intent.setFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
//                            context.startActivity(intent1);
                                Intent install = new Intent(Intent.ACTION_VIEW);
                                install.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);

                                install.setDataAndType(apkUri, downloadManager.getMimeTypeForDownloadedFile(DLid));
                                install.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                                context.startActivity(install);
                            }
                        } catch (Exception e) {
                            Log.e("update", "onReceive: " + e.toString());
                            Toast.makeText(context, "!!!!!!!!!!!!!!!", Toast.LENGTH_SHORT).show();
                        }

                        Toast.makeText(context, "فایل نصبی با موفقیت در پوشه دانلودهای شما ذخیره شد",
                                Toast.LENGTH_LONG).show();
                    } else {
                        Uri apkUri = Uri.fromFile(new File(Environment.getExternalStorageDirectory(),
                                "Download/Passenger.apk"));
                        intent = new Intent(Intent.ACTION_VIEW);
                        intent.setDataAndType(apkUri, "application/vnd.android.package-archive");
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        context.startActivity(intent);
                    }

                }
            }
        };
    }

