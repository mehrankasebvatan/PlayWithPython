package com.rayanandisheh.peysepar.passenger.view.dialog;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.view.Gravity;
import android.widget.LinearLayout;
import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.appcompat.widget.AppCompatTextView;
import com.rayanandisheh.peysepar.passenger.R;
import com.rayanandisheh.peysepar.passenger.models.WhatsUpResponse;

public class WhatsUpDialog extends Dialog {

    public WhatsUpDialog(@NonNull Context context, WhatsUpResponse response) {
        super(context);
        setContentView(R.layout.layout_whatsup_dialog);
        getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        getWindow().setLayout(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        getWindow().setGravity(Gravity.BOTTOM);
        AppCompatTextView link = findViewById(R.id.link);
        AppCompatTextView google = findViewById(R.id.google);
        AppCompatTextView cafebazar = findViewById(R.id.cafebazar);
        AppCompatTextView message = findViewById(R.id.message);
        AppCompatImageView close = findViewById(R.id.close);

        if (response.getStrComment() != null && !response.getStrComment().isEmpty()) {
            message.setText(response.getStrComment());
        } else {
            message.setText("لطفا برنامه را از طرق زیر به روز رسانی کنید");
        }

        link.setOnClickListener(v -> {
            if (response.getStrURL() != null && !response.getStrURL().isEmpty()) {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(response.getStrURL()));
                context.startActivity(intent);
                dismiss();
            }
        });
        google.setOnClickListener(v -> {
            if (response.getStrGooglePlayURL() != null && !response.getStrGooglePlayURL().isEmpty()) {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(response.getStrGooglePlayURL()));
                context.startActivity(intent);
                dismiss();
            }
        });
        cafebazar.setOnClickListener(v -> {
            if (response.getStrCafebazarURL() != null && !response.getStrCafebazarURL().isEmpty()) {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(response.getStrCafebazarURL()));
                context.startActivity(intent);
                dismiss();
            }

        });
        close.setOnClickListener(v -> dismiss());
    }
}
