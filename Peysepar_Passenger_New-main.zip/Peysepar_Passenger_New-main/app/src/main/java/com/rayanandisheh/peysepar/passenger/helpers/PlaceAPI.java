package com.rayanandisheh.peysepar.passenger.helpers;

import android.util.Log;
import android.widget.Toast;

import com.rayanandisheh.peysepar.passenger.services.WebServiceCaller;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;

public class PlaceAPI {

    private static final String TAG = PlaceAPI.class.getSimpleName();

    private static final String PLACES_API_BASE = "https://maps.googleapis.com/maps/api/place";
    private static final String TYPE_AUTOCOMPLETE = "/autocomplete";
    private static final String OUT_JSON = "/json";

    private static final String GEOCODE_API_BASE = "https://maps.googleapis.com/maps/api/geocode";

    private static String ANDROID_VERSION = "";

    public ArrayList<String> autocomplete(String input) {
        ArrayList<String> resultList = null;

        HttpURLConnection conn = null;
        StringBuilder jsonResults = new StringBuilder();

        WebServiceCaller webServiceCaller = new WebServiceCaller();
        webServiceCaller.getAndroidVersion(App.user.getiOfficialTrip(), new WebServiceCaller.callBack() {
            @Override
            public String onSuccess(String Response) {
                ANDROID_VERSION = Response;
                return null;
            }

            @Override
            public String onFailure(String Response) {
                Toast.makeText(App.context, Response, Toast.LENGTH_SHORT).show();
                return null;
            }
        });

        try {
            StringBuilder sb = new StringBuilder(PLACES_API_BASE + TYPE_AUTOCOMPLETE + OUT_JSON);
            sb.append("?key=" + ANDROID_VERSION);
//            sb.append("&types=(cities)");
            sb.append("&language=fa&region=ir");
            sb.append("&input=" + URLEncoder.encode(input, "utf8"));

            URL url = new URL(sb.toString());
            conn = (HttpURLConnection) url.openConnection();
            InputStreamReader in = new InputStreamReader(conn.getInputStream());

            // Load the results into a StringBuilder
            int read;
            char[] buff = new char[1024];
            while ((read = in.read(buff)) != -1) {
                jsonResults.append(buff, 0, read);
            }
        } catch (MalformedURLException e) {
            Log.e(TAG, "Error processing Places API URL", e);
            return resultList;
        } catch (IOException e) {
            Log.e(TAG, "Error connecting to Places API", e);
            return resultList;
        } finally {
            if (conn != null) {
                conn.disconnect();
            }
        }

        try {
            // Log.d(TAG, jsonResults.toString());

            // Create a JSON object hierarchy from the results
            JSONObject jsonObj = new JSONObject(jsonResults.toString());
            JSONArray predsJsonArray = jsonObj.getJSONArray("predictions");

            // Extract the Place descriptions from the results
            resultList = new ArrayList<String>(predsJsonArray.length());
            for (int i = 0; i < predsJsonArray.length(); i++) {
                resultList.add(predsJsonArray.getJSONObject(i).getString("description"));
            }
        } catch (JSONException e) {
            Log.e(TAG, "Cannot process JSON results", e);
        }

        return resultList;
    }


    public ArrayList<String> geocode(String address) {
        ArrayList<String> locationList = null;

        HttpURLConnection conn = null;
        StringBuilder jsonResults = new StringBuilder();

        try {
            StringBuilder sb = new StringBuilder(GEOCODE_API_BASE + OUT_JSON);
//            sb.append("&input=" + URLEncoder.encode(address, "utf8"));
            sb.append("?address=" + address);
            sb.append("&key=" + ANDROID_VERSION);


            URL url = new URL(sb.toString());
            conn = (HttpURLConnection) url.openConnection();
            InputStreamReader in = new InputStreamReader(conn.getInputStream());

            // Load the results into a StringBuilder
            int read;
            char[] buff = new char[1024];
            while ((read = in.read(buff)) != -1) {
                jsonResults.append(buff, 0, read);
            }
        } catch (MalformedURLException e) {
            Log.e(TAG, "Error processing Places API URL", e);
            return locationList;
        } catch (IOException e) {
            Log.e(TAG, "Error connecting to Places API", e);
            return locationList;
        } finally {
            if (conn != null) {
                conn.disconnect();
            }
        }

//        JSONObject jsonObj = new JSONObject(jsonResults.toString());
//        JSONArray predsJsonArray = jsonObj.getJSONArray("predictions");
//
//        // Extract the Place descriptions from the results
//        resultList = new ArrayList<String>(predsJsonArray.length());
//        for (int i = 0; i < predsJsonArray.length(); i++) {
//            resultList.add(predsJsonArray.getJSONObject(i).getString("description"));
//        }

        try {
            JSONObject jsonObject = new JSONObject(jsonResults.toString());

            double lng = ((JSONArray) jsonObject.get("results")).getJSONObject(0)
                    .getJSONObject("geometry").getJSONObject("location")
                    .getDouble("lng");

            double lat = ((JSONArray) jsonObject.get("results")).getJSONObject(0)
                    .getJSONObject("geometry").getJSONObject("location")
                    .getDouble("lat");

            Log.d("latitude", "" + lat);
            Log.d("longitude", "" + lng);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return locationList;
    }

}
