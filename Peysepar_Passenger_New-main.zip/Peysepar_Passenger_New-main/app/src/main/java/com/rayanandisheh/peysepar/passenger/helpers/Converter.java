package com.rayanandisheh.peysepar.passenger.helpers;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.util.Base64;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import java.io.ByteArrayOutputStream;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
public class Converter {

    public static String Encoder(String forConvert) {
        switch (App.encodingFormat) {
            case "base64":
                return Base64.encodeToString(forConvert.getBytes(), Base64.DEFAULT);
            case "md5":
                MessageDigest mdEnc;
                try {
                    mdEnc = MessageDigest.getInstance("MD5");
                    mdEnc.update(forConvert.getBytes(), 0, forConvert.length());
                    StringBuilder sUnMD5Builder = new StringBuilder(new BigInteger(1, mdEnc.digest()).toString(16));
                    while (sUnMD5Builder.length() < 16)
                        sUnMD5Builder.insert(0, "0");
                    return sUnMD5Builder.toString();
                } catch (NoSuchAlgorithmException e1) {
                    e1.printStackTrace();
                    return forConvert;
                }
            default:
                return forConvert;
        }
    }


    public static String bitmapToString(Bitmap bitmap) {
        if(bitmap!=null) {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);
//            byte [] b=baos.toByteArray();
            String img = Base64.encodeToString(baos.toByteArray(), Base64.DEFAULT);

            return img;
        }else{
            return "";
        }
    }

    public static BitmapDescriptor drawableToBitmap(Drawable drawable) {
        Canvas canvas = new Canvas();
        Bitmap bitmap = Bitmap.createBitmap(drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
        canvas.setBitmap(bitmap);
        drawable.setBounds(0, 0, drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight());
        drawable.draw(canvas);
        return BitmapDescriptorFactory.fromBitmap(bitmap);
    }

    private static String toEnglish(String text) {
        try {
            return text
                    .replace('\u0660', '0').replace('\u06F0', '0')
                    .replace('\u0661', '1').replace('\u06F1', '1')
                    .replace('\u0662', '2').replace('\u06F2', '2')
                    .replace('\u0663', '3').replace('\u06F3', '3')
                    .replace('\u0664', '4').replace('\u06F4', '4')
                    .replace('\u0665', '5').replace('\u06F5', '5')
                    .replace('\u0666', '6').replace('\u06F6', '6')
                    .replace('\u0667', '7').replace('\u06F7', '7')
                    .replace('\u0668', '8').replace('\u06F8', '8')
                    .replace('\u0669', '9').replace('\u06F9', '9')
                    .replace("٫", ".");
        } catch (Exception ignored) {
            return "";
        }
    }

    private static int toEnglish(int number) {
        try {
            return Integer.parseInt(toEnglish(String.valueOf(number)));
        } catch (Exception ignored) {
            return 0;
        }
    }

    private static float toEnglish(float number) {
        try {
            return Float.parseFloat(toEnglish(String.valueOf(number)));
        } catch (Exception ignored) {
            return 0;
        }
    }

    private static double toEnglish(double number) {
        try {
            return Double.parseDouble(toEnglish(String.valueOf(number)));
        } catch (Exception ignored) {
            return 0;
        }
    }

    private static short toEnglish(short number) {
        try {
            return Short.parseShort(toEnglish(String.valueOf(number)));
        } catch (Exception ignored) {
            return 0;
        }
    }

    public static String valueChecked(String text) {
        if (text == null || text.isEmpty()) {
            return "";
        } else {
            return toEnglish(text);
        }
    }

    public static int valueChecked(int number) {
        return toEnglish(number);
    }
    public static float valueChecked(float number) {
        return toEnglish(number);
    }
    public static double valueChecked(double number) {
        return toEnglish(number);
    }
    public static short valueChecked(short number) {
        return toEnglish(number);
    }

}