package com.rayanandisheh.peysepar.passenger.view.Activity;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;
import com.rayanandisheh.peysepar.passenger.BuildConfig;
import com.rayanandisheh.peysepar.passenger.R;

public class AboutPassengerApplicationActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about_passenger_application);
        setActivitySetting();
        //getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        ((TextView) findViewById(R.id.TEXT_VIEW_APPLICATION_VERSION)).
                setText(String.format("نسخه %s", BuildConfig.VERSION_NAME));
    }

    private void setActivitySetting() {
        getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        setTitle(R.string.about_peysepar);
        setSupportActionBar(findViewById(R.id.TOOLBAR));
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
