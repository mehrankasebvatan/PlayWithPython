package com.rayanandisheh.peysepar.passenger.view.Activity;

import android.content.Context;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.rayanandisheh.peysepar.passenger.R;
import com.rayanandisheh.peysepar.passenger.helpers.App;
import com.rayanandisheh.peysepar.passenger.helpers.PersianAppcompatActivity;
import com.rayanandisheh.peysepar.passenger.helpers.Toaster;
import com.rayanandisheh.peysepar.passenger.models.News;
import com.rayanandisheh.peysepar.passenger.services.APIClient;
import com.rayanandisheh.peysepar.passenger.services.APIService;
import com.rayanandisheh.peysepar.passenger.view.Adapter.NewsAdapter;

import java.util.List;

import jp.wasabeef.recyclerview.adapters.AlphaInAnimationAdapter;
import jp.wasabeef.recyclerview.adapters.ScaleInAnimationAdapter;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class NewsActivity extends PersianAppcompatActivity {
    Context context;
    Toolbar toolbar;
    RecyclerView recyclerView;
    SwipeRefreshLayout swp_refresh;
    ImageView img_no_Item;
    NewsAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_news);
        //getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        context = this;
        bindView();
        viewLoaded();
        swp_refresh.setOnRefreshListener(this::viewLoaded);
    }

    private void bindView() {
        swp_refresh = findViewById(R.id.swp_refresh_news);
        img_no_Item = findViewById(R.id.img_no_Item);
        recyclerView = findViewById(R.id.recyclerview_news);
        toolbar = findViewById(R.id.toolbar_news);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        getSupportActionBar().setTitle("اخبار");
    }

    public void requestNewsList() {
        APIService apiService = APIClient.getClient().create(APIService.class);
        Call<List<News>> call = apiService.news();
        call.enqueue(new Callback<List<News>>() {
            @Override
            public void onResponse(@NonNull Call<List<News>> call, @NonNull Response<List<News>> response) {

                if (response.code() == 200) {
                    App.listNews = response.body();
                    newsRequestResult(1);
                } else {
                    newsRequestResult(-4);
                }
            }

            @Override
            public void onFailure(@NonNull Call<List<News>> call, @NonNull Throwable t) {
                newsRequestResult(-5);
            }
        });
    }

    public void showSwipeRefresh() {
        swp_refresh.setRefreshing(true);
    }

    public void hideSwpRefresh() {
        swp_refresh.setRefreshing(false);
    }

    public void showImg_noItem() {
        img_no_Item.setVisibility(View.VISIBLE);
    }

    public void hideImg_noItem() {
        img_no_Item.setVisibility(View.GONE);
    }

    public void setAdapter() {

        adapter = new NewsAdapter(App.listNews, context);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(context);
        recyclerView.setLayoutManager(layoutManager);
        AlphaInAnimationAdapter alphaAdapter = new AlphaInAnimationAdapter(adapter);
        recyclerView.setAdapter(new ScaleInAnimationAdapter(alphaAdapter));
    }

    public void viewLoaded() {
        showSwipeRefresh();
        if (App.listNewsSuccess) {
            requestNewsList();
        } else if (App.listNews.size() > 0) {
            setAdapter();
            hideImg_noItem();
        } else if (App.listHistoryTrip.size() == 0) {
            showImg_noItem();
        }
    }

    public void newsRequestResult(int result) {
        hideSwpRefresh();
        if (result == -4) {
            Toaster.shorter(context.getString(R.string.serverFaield));
        } else if (result == -5) {
            Toaster.shorter(context.getString(R.string.connectionFaield));
        } else if (result == 1) {
            setAdapter();
            if (App.listNews.size() > 0)
                hideImg_noItem();
            else
                showImg_noItem();
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    protected void onResume() {
        super.onResume();
        viewLoaded();
    }
}
