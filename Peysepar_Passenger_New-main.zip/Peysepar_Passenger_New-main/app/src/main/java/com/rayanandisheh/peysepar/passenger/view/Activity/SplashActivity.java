package com.rayanandisheh.peysepar.passenger.view.Activity;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.rayanandisheh.peysepar.passenger.BuildConfig;
import com.rayanandisheh.peysepar.passenger.R;
import com.rayanandisheh.peysepar.passenger.customes.mAppCompatActivity;
import com.rayanandisheh.peysepar.passenger.helpers.App;
import com.rayanandisheh.peysepar.passenger.helpers.Base64Util;
import com.rayanandisheh.peysepar.passenger.helpers.Cache;
import com.rayanandisheh.peysepar.passenger.helpers.DeviceInfo;
import com.rayanandisheh.peysepar.passenger.helpers.Toaster;
import com.rayanandisheh.peysepar.passenger.helpers.Validate;
import com.rayanandisheh.peysepar.passenger.models.Register;
import com.rayanandisheh.peysepar.passenger.models.UserInfo;
import com.rayanandisheh.peysepar.passenger.models.WhatsUpRequest;
import com.rayanandisheh.peysepar.passenger.models.WhatsUpResponse;
import com.rayanandisheh.peysepar.passenger.services.APIClient;
import com.rayanandisheh.peysepar.passenger.services.APIService;
import com.rayanandisheh.peysepar.passenger.utils.NetworkConnected;
import com.rayanandisheh.peysepar.passenger.view.dialog.WhatsUpDialog;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.util.Timer;
import java.util.TimerTask;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SplashActivity extends mAppCompatActivity {
    //    Contract.Presenter presenter = new Presenter();
    private static final String TAG = "SplashActivity1";
    Context context = this;
    ProgressBar progressBar;
    int badgeCount = 4;
    TextView txtVersionSplash, txtStaticpeysepar, txtReconnect;
    PackageInfo pinfo = null;
    String versionName;
    String IMEI = "";
    int currentVersion = 0;
    boolean BoolisRoot = false;
    boolean BoolisEmulator = false;
    boolean isEmulatorDevice = false;
    ImageView ivBackground;

    public static boolean checkForRoot() {
        return checkRootMethod1() || checkRootMethod2() || checkRootMethod3();
    }
//check method

    private static boolean checkRootMethod1() {
        String buildTags = android.os.Build.TAGS;
        return buildTags != null && buildTags.contains("test-keys");
    }

    private static boolean checkRootMethod2() {
        String[] paths = {"/system/app/Superuser.apk",
                "/system/etc/init.d/99SuperSUDaemon ",
                "/dev/com.koushikdutta.superuser.daemon/ ",
                "/system/xbin/daemonsu",
                "/sbin/su /system/bin/su",
                "/system/bin/failsafe/su",
                "/system/xbin/su",
                " /system/xbin/busybox",
                "/system/sd/xbin/su ",
                "/data/local/su ",
                "/data/local/xbin/su",
                "/data/local/bin/su"
        };

        for (String path : paths) {
            if (new File(path).exists())
                return true;
        }
        return false;

    }

    private static boolean checkRootMethod3() {

        Process process = null;
        try {
            process = Runtime.getRuntime().exec(new String[]{"/system/xbin/which", "su"});
            BufferedReader in = new BufferedReader(new InputStreamReader(process.getInputStream()));
            return in.readLine() != null;
        } catch (Throwable t) {
            return false;
        } finally {
            if (process != null) process.destroy();
        }
    }


    private boolean checkForEmulator() {

        return Build.FINGERPRINT.startsWith("generic")
                || Build.FINGERPRINT.startsWith("unknown")
                || Build.MODEL.contains("google_sdk")
                || Build.MODEL.contains("Emulator")
                || Build.MODEL.contains("Android SDK built for x86")
                || Build.MANUFACTURER.contains("Genymotion")
                || (Build.BRAND.startsWith("generic") && Build.DEVICE.startsWith("generic"))
                || "google_sdk".equals(Build.PRODUCT);
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        if (!checkForRoot()) {

            if (!checkForEmulator()) {
                BoolisEmulator = false;
                BoolisRoot = false;
                mOnCreate();

            } else {
                BoolisEmulator = true;
                new androidx.appcompat.app.AlertDialog.Builder(context)
                        .setMessage(getResources().getString(R.string.nopossibleforemulator))
                        .setCancelable(false)
                        .setPositiveButton("خروج", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                finishAffinity();
                            }
                        })
                        .show();
            }

        } else {
            BoolisRoot = true;
            new androidx.appcompat.app.AlertDialog.Builder(context)
                    .setMessage(getResources().getString(R.string.textnoposiipleonroot))
                    .setCancelable(false)
                    .setPositiveButton("خروج", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            finishAffinity();
                        }
                    })
                    .show();
        }
    }

    private void mOnCreate() {

        bindViews();

        if (Cache.getString("logo") != null) {
            ivBackground.setImageBitmap(Base64Util.decodebitmap(Cache.getString("logo")));
        }


        executeShellCommand("su");

        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
//        presenter.attachView(context, this);

//        if (badgeCount != 0)
//            ShortcutBadger.applyCount(SplashActivity.this, badgeCount);
//        ShortcutBadger.removeCount(context);

        try {
            pinfo = getPackageManager().getPackageInfo(getPackageName(), 0);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }

        versionName = pinfo.versionName;

        txtVersionSplash.setText(String.format("نسخه : %s", versionName));

        try {
            if (!Cache.getString("peyseparDomain").equals("") && Cache.getString("peyseparDomain") != null) {
                txtStaticpeysepar.setVisibility(View.VISIBLE);
                String txt = "پی سپار " + Cache.getString("peyseparDomain");
                txtStaticpeysepar.setText(txt);
            } else {
                txtStaticpeysepar.setText("پی سپار");
            }
        } catch (Exception e) {
        }

        // use setting Activity to change IP
//        App.ServerURL = Cache.getString("IP");
        App.ServerURL = Cache.getString("IP");

        txtReconnect.setOnClickListener(v -> activityLoaded());
    }

    //moved codes in onCreate to onStart for resolve the problem of
    // checkPermission when we goto settingPermission and back to splash
    @Override
    protected void onStart() {
        super.onStart();

        if (!BoolisRoot && !BoolisEmulator) {
            if (App.ServerURL.equals("")) {
                context.startActivity(new Intent(context, SettingUrlActivity.class));
            } else {
                if (ContextCompat.checkSelfPermission(getApplicationContext(),
                        Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
                    requestPermission();
                } else {
                    activityLoaded();
                }
            }
        }

    }

    private void bindViews() {
        progressBar = findViewById(R.id.progressSplash);
        txtVersionSplash = findViewById(R.id.txtVersionSplash);
        txtStaticpeysepar = findViewById(R.id.txtStaticpeysepar);
        txtReconnect = findViewById(R.id.txtReconnect);
        ivBackground = findViewById(R.id.ivBackground);
    }

    public void activityLoaded() {
        Log.d(TAG, "activityLoaded: ");
        progressBar.setVisibility(View.VISIBLE);
        txtReconnect.setVisibility(View.GONE);
        String mobile = Cache.getString("mobileNumber");
        if (NetworkConnected.getInstance(this)) {
            if (Validate.mobile(mobile)) {



                Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        login();
                    }
                }, 3000);

            } else
                new Timer().schedule(new TimerTask() {
                    @Override
                    public void run() {
                        gotoLogin();
                    }
                }, 3000);
        } else {
            Toaster.shorter("لطفا اینترت دستگاه خود را بررسی کنید");
            progressBar.setVisibility(View.GONE);
            txtReconnect.setVisibility(View.VISIBLE);
        }
    }

    @SuppressLint("HardwareIds")
    public void login() {
        Register register = new Register();
        register.setStrMobile(Cache.getString("mobileNumber"));
//        register.setStrIMEI(Cache.getString("IMEI"));
        if (Build.VERSION.SDK_INT > 28) {
            IMEI = Settings.Secure.getString(context.getContentResolver(),
                    Settings.Secure.ANDROID_ID);
            register.setStrIMEI(IMEI);
        } else
            register.setStrIMEI(DeviceInfo.getDeviceIMEI(context));
        register.setStrToken(Cache.getString("FirebaseToken"));

        PackageInfo pinfo = null;
        try {
            pinfo = context.getPackageManager().getPackageInfo(context.getPackageName(), 0);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        register.setVersionCode(pinfo.versionCode);

        request(register);
    }

    private void request(Register register) {
        APIService apiService = APIClient.getClient().create(APIService.class);
        Call<UserInfo> call = apiService.Login(register);
        call.enqueue(new Callback<UserInfo>() {
            @Override
            public void onResponse(@NonNull Call<UserInfo> call, @NonNull Response<UserInfo> response) {
                if (response.code() == 200) {
                    App.userInfo = response.body();
                    Cache.setString("logo",response.body().getStrLogo());
                    assert App.userInfo != null;
                    Cache.setString("photo", App.userInfo.getImgLink());
                    App.register.setStrMobile(register.getStrMobile());

                    assert response.body() != null;
                    App.mapMode = response.body().getiSAndDBaseCurrentLoc();
                    App.Session = response.body().getStrSession();
                    Log.d(TAG, "onResponse: " + App.Session);
                    Cache.setString("peyseparDomain", response.body().getStrComment_strMbileDomain());
                    assert response.body() != null;
                    loginResult(response.body().getResult());
                } else
                    loginResult(-1);
            }

            @Override
            public void onFailure(@NonNull Call<UserInfo> call, @NonNull Throwable t) {
                loginResult(-5);
            }
        });
    }


    public void loginResult(int result) {
        if (result == 1) {
            getWhatsUP();
        } else if (result == 0) {
            context.startActivity(new Intent(context, LoginActivity.class));
            ((Activity) context).finish();
        } else if (result == -2) {
            context.startActivity(new Intent(context, ActivationActivity.class));
            Toaster.longer(context.getString(R.string.validateYourNumber));
            ((Activity) context).finish();
        } else if (result == -1) {
            Toaster.shorter(context.getString(R.string.serverFaield));
            //comment below line to prevent jumping splash when the web service is not correct
//            context.startActivity(new Intent(context,SplashActivity.class));
            ((Activity) context).finish();
        } else if (result == -5) {

            //after 3 times encountiong timeout ,refer to loginActivity
//            requestCount++;
//            if(requestCount<4){
//                Toaster.shorter(context.getString(R.string.connectionFaield));
//                context.startActivity(new Intent(context,SplashActivity.class));
//            }else{
            context.startActivity(new Intent(context, LoginActivity.class));
//            }
            ((Activity) context).finish();

        } else if (result == 100) {
            context.startActivity(new Intent(context, LoginActivity.class));
            ((Activity) context).finish();
        } else {
            gotoLogin();
        }
    }

    private void getWhatsUP() {
        WhatsUpRequest request = new WhatsUpRequest();
        request.setiPassenger(App.userInfo.getiPassenger());
        request.setStrAppVersion(BuildConfig.VERSION_NAME);
        request.setStrFullName(App.userInfo.getStrName() + " " + App.userInfo.getStrFamily());
        APIClient.getClient().create(APIService.class).Peysepar_WhatsUp(request).enqueue(new Callback<WhatsUpResponse>() {
            @Override
            public void onResponse(Call<WhatsUpResponse> call, Response<WhatsUpResponse> response) {
                if (response != null && response.isSuccessful() && response.body() != null) {
                    if (response.body().getiResult() == 1) {
                        showUpdateDialog(response.body());
                    } else {
                        goToMainActivity();
                    }
                } else {
                    goToMainActivity();
                }
            }

            @Override
            public void onFailure(Call<WhatsUpResponse> call, Throwable t) {
                goToMainActivity();
            }
        });
    }

    private void showUpdateDialog(WhatsUpResponse whatsUpResponse) {
        WhatsUpDialog dialog = new WhatsUpDialog(this, whatsUpResponse);
        dialog.show();
    }

    private void goToMainActivity() {
        startActivity(new Intent(context, MainActivity.class));
        cacheMobilePhone();
        finish();
    }

    public void cacheMobilePhone() {
        Cache.setString("mobileNumber", App.register.getStrMobile());
    }

    private void gotoLogin() {
        startActivity(new Intent(context, LoginActivity.class));
        finish();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        exitApp();
    }

    private void exitApp() {
        finish();
        startActivity(new Intent(Intent.ACTION_MAIN).
                addCategory(Intent.CATEGORY_HOME).
                setFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        android.os.Process.killProcess(android.os.Process.myPid());
        super.finish();
    }

    private void requestPermission() {
        ActivityCompat.requestPermissions(this
                , new String[]{Manifest.permission.READ_PHONE_STATE}, 5);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions
            , @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case 5:
                if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    activityLoaded();
//                    dosomthing();
                } else {
                    showAccessPermissionDialog();
                }
                break;
        }
    }

    //permission dialog
    private void showAccessPermissionDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("عدم اجازه دسترسی");
        builder.setMessage(R.string.accessDeniedMessage);
        builder.setPositiveButton("برو به تنظیمات", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Intent intent = new Intent();
                intent.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                Uri uri = Uri.fromParts("package", getPackageName(), null);
                intent.setData(uri);
                startActivity(intent);
                //mused below code for resolve the problem of
                // checkPermission when we goto settingPermission and back to splash
                SplashActivity.super.onStop();

            }
        });
        builder.setCancelable(false);
        builder.create().show();
    }

    //check root device
    private void executeShellCommand(String su) {
        Process process = null;
        try {
            process = Runtime.getRuntime().exec(su);
            Toast.makeText(context, "دستگاه شما روت میباشد , برنامه قابلیت اجرا روی دستگاه های روت را ندارد.", Toast.LENGTH_SHORT).show();
            finishAffinity();
        } catch (Exception e) {

        } finally {
            if (process != null) {
                try {
                    process.destroy();
                } catch (Exception e) {
                }
            }
        }
    }
}


