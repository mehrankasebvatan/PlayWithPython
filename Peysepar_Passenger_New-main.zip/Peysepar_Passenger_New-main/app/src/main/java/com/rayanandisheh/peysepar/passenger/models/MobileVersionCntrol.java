package com.rayanandisheh.peysepar.passenger.models;

import com.google.gson.annotations.SerializedName;

public class MobileVersionCntrol {

	@SerializedName("strDriverPath")
	private String strDriverPath;

	@SerializedName("strMinValidDriverVersion")
	private String strMinValidDriverVersion;

	@SerializedName("strPassengerPath")
	private String strPassengerPath;

	@SerializedName("strLastDriverVersion")
	private String strLastDriverVersion;

	@SerializedName("strMinValidPassengerVersion")
	private String strMinValidPassengerVersion;

	@SerializedName("strLastPassengerVersion")
	private String strLastPassengerVersion;

	public void setStrDriverPath(String strDriverPath){
		this.strDriverPath = strDriverPath;
	}

	public String getStrDriverPath(){
		return strDriverPath;
	}

	public void setStrMinValidDriverVersion(String strMinValidDriverVersion){
		this.strMinValidDriverVersion = strMinValidDriverVersion;
	}

	public String getStrMinValidDriverVersion(){
		return strMinValidDriverVersion;
	}

	public void setStrPassengerPath(String strPassengerPath){
		this.strPassengerPath = strPassengerPath;
	}

	public String getStrPassengerPath(){
		return strPassengerPath;
	}

	public void setStrLastDriverVersion(String strLastDriverVersion){
		this.strLastDriverVersion = strLastDriverVersion;
	}

	public String getStrLastDriverVersion(){
		return strLastDriverVersion;
	}

	public void setStrMinValidPassengerVersion(String strMinValidPassengerVersion){
		this.strMinValidPassengerVersion = strMinValidPassengerVersion;
	}

	public String getStrMinValidPassengerVersion(){
		return strMinValidPassengerVersion;
	}

	public void setStrLastPassengerVersion(String strLastPassengerVersion){
		this.strLastPassengerVersion = strLastPassengerVersion;
	}

	public String getStrLastPassengerVersion(){
		return strLastPassengerVersion;
	}
}