package com.rayanandisheh.peysepar.passenger.view.Activity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebView;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.appcompat.widget.Toolbar;

import com.bumptech.glide.Glide;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.rayanandisheh.peysepar.passenger.R;
import com.rayanandisheh.peysepar.passenger.helpers.PersianAppcompatActivity;
import com.rayanandisheh.peysepar.passenger.helpers.Toaster;
import com.rayanandisheh.peysepar.passenger.models.News;

public class NewsDetailActivity extends PersianAppcompatActivity {

    Context context;
    public static News model;

    TextView datetimeNewsDetail, eNewsDetail, news_detail_txtNews;

    //    JustifiedTextView news_detail_txtNews;
    Toolbar toolbar;
    RelativeLayout frame_imgNews;
    ImageView imgNews;
    WebView news_detail_webNews;
    FloatingActionButton fab;
    ScrollView sv;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_news_detail);
        context = this;
        //getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        bindView();

        try {
//            setTitle(model.getStrTitle());
//            Picasso.get()
//                    .load(model.getUrl())
//                    .placeholder(R.drawable.picture_loading)
//                    .error(R.drawable.picture_loading)
//                    .into(imgNews);

            Glide.with(context).load(model.getUrl()).into(imgNews);

            news_detail_txtNews.setText(model.getStrContent());
            datetimeNewsDetail.setText(model.getStrDateTime());


            eNewsDetail.setText(model.getStrValidDate());


            news_detail_webNews.getSettings().setJavaScriptEnabled(true);
            news_detail_webNews.loadDataWithBaseURL("", news_detail_txtNews.getText().toString(), "text/html", "UTF-8", "");


//todo justify showing text getting from server
//            // to justify String
//            String htmlText = "<html><body style=\"text-align:justify\"> %s </body></Html>";
//
//            String myData = model.getStrContent();
//            news_detail_webNews.getSettings().setJavaScriptEnabled(true);
//
//            news_detail_webNews.loadData(String.format(htmlText, myData), "text/html", "utf-8");


        } catch (Exception e) {
            Toaster.shorter("اشکال در بارگذاری");
            finish();
        }
        setListeners();


        fab.setOnClickListener(v -> {
            String title = news_detail_txtNews.getText().toString();
            startActivity(Intent.createChooser(new Intent().
                    setAction(Intent.ACTION_SEND).
                    putExtra(Intent.EXTRA_TEXT, title).
                    setType("text/plain").
                    setFlags(Intent.FLAG_ACTIVITY_NEW_TASK), "اشتراک گذاری"));
        });
    }

    private void setListeners() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                sv.setOnScrollChangeListener((view, i, i1, i2, i3) -> {
                    if (i1 < i3) {
                        fab.hide();
                    } else {
                        fab.show();
                    }
                });
            }
        } catch (Exception ignored) {
        }

    }

    private void bindView() {
        toolbar = findViewById(R.id.toolbar_news_detail);
        frame_imgNews = findViewById(R.id.news_detail_frame_imgNews);
        imgNews = findViewById(R.id.imgNewsDetail);
        datetimeNewsDetail = findViewById(R.id.datetimeNewsDetail);
        eNewsDetail = findViewById(R.id.ENewsDetail);
        news_detail_webNews = findViewById(R.id.news_detail_webNews);
        news_detail_txtNews = findViewById(R.id.news_detail_txtNews);
        fab = findViewById(R.id.news_detail_fab);
        sv = findViewById(R.id.sv_news_detail);

        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
//        setTitle("اخبار");
        setTitle(model.getStrTitle());
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }

}
