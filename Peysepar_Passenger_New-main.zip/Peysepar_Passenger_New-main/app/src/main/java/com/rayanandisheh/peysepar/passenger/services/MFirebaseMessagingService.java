package com.rayanandisheh.peysepar.passenger.services;

import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;
import com.rayanandisheh.peysepar.passenger.R;
import com.rayanandisheh.peysepar.passenger.helpers.App;
import com.rayanandisheh.peysepar.passenger.helpers.Cache;
import com.rayanandisheh.peysepar.passenger.models.NotificationModel;
import com.rayanandisheh.peysepar.passenger.models.Trip;
import com.rayanandisheh.peysepar.passenger.view.Activity.CancelTripDialogActivity;
import com.rayanandisheh.peysepar.passenger.view.Activity.OKdriverActivity;
import com.rayanandisheh.peysepar.passenger.view.Activity.SignatureActivity;
import com.rayanandisheh.peysepar.passenger.view.Activity.SplashActivity;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import java.util.List;

import static com.rayanandisheh.peysepar.passenger.helpers.App.CHANNEL_ID;
import static com.rayanandisheh.peysepar.passenger.helpers.App.context;

public class MFirebaseMessagingService extends FirebaseMessagingService {
    private static final String TAG = "MFirebaseMessagingServi";

    public MFirebaseMessagingService() {
        super();
    }

    @Override
    public void handleIntent(Intent intent) {
        super.handleIntent(intent);
        Bundle bundle = intent.getExtras();
        Log.i(TAG, "handleIntent: " + intent.getExtras());
        if (bundle != null) {
            Log.d(TAG, "handleIntent: " + bundle.getString("strDriverName"));
            NotificationModel notificationModel = new NotificationModel();
            notificationModel.setStrDriverName(bundle.getString("strDriverName") != null ? bundle.getString("strDriverName") : "");
            notificationModel.setDriverImage(bundle.getString("driverImage") != null ? bundle.getString("driverImage") : "");
            notificationModel.setMessage(bundle.getString("message") != null ? bundle.getString("message") : "");

            notificationModel.setOriginName(bundle.getString("OriginName") != null ? bundle.getString("OriginName") : "");
            notificationModel.setOriginAddress(bundle.getString("OriginAddress") != null ? bundle.getString("OriginAddress") : "");

            notificationModel.setDestinationName(bundle.getString("DestinationName") != null ? bundle.getString("DestinationName") : "");
            notificationModel.setDestinationAddress(bundle.getString("DestinationAddress") != null ? bundle.getString("DestinationAddress") : "");
//            notificationModel.setTitle(bundle.getString("title") != null ? bundle.getString("title") : "");
            notificationModel.setiOfficialTrip(bundle.getString("iOfficialTrip") != null ? Integer.parseInt(bundle.getString("iOfficialTrip")) : 0);
            notificationModel.setType(bundle.getString("Type") != null ? bundle.getString("Type") : "");
//            notificationModel.setMessage(bundle.getString("message") != null ? bundle.getString("message") : "");
            handleDataMessage(notificationModel);
//            notificationType = notificationModel.getType();
        }
    }

    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {
        super.onMessageReceived(remoteMessage);
//        if (notificationType.equals("ManageRequest"))
    }

    private void handleDataMessage(NotificationModel notificationModel) {

        switch (notificationModel.getType()) {
            //امضا برای به پایان رسیدن سفر
            case "newrequest":
//                save sended data from notification model in app
                App.notifModel = notificationModel;
                getApplicationContext().startActivity(new Intent(getApplicationContext(), SignatureActivity.class)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                break;
            /*---------------------*/
            //تاییدسفر
            case "OKRequest":
                requestForsetDetailTripData(notificationModel);
                break;

            //اختصاص راننده توسط مدیر
            case "AssignDriver":
//                requestForsetDetailTripData(notificationModel);
                requestForsetDetailTripData(notificationModel);
                break;

            //لغو سفر
            case "CancelTrip":
                App.notifModel = notificationModel;
//                requestForsetDetailTripData(notificationModel);
                showDialogForCancelTrip(notificationModel);
                break;

            //تایید راننده(مثلا میگه من تا ده دقیقه دیگه میرسم)
            case "OKDriver":
                requestForsetDetailTripData(notificationModel);
                break;

            //راننده من رسیدم را میزند
            case "ArriveDriver":
                requestForsetDetailTripData(notificationModel);
                break;

            case "ManageRequest":
                App.notifModel = notificationModel;
                PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
                App.isScreenOn = pm.isScreenOn();
//                wakeUpScreen();
                if (App.isScreenOn) {
                    showManageNotification(notificationModel);
                } else {
                    showManageNotification(notificationModel);
//                    Intent intent=new Intent("com.sample.service.h");
//                    this.startService(intent);
//                    startService(new Intent(this, Service.class));
                    wakeUpScreen();
                }
                break;

            default:
                showDifualtNotification(notificationModel);
                break;
        }

    }

    private void showManageNotification(NotificationModel notificationModel) {

//        NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
//        NotificationCompat.Builder builder = new NotificationCompat.Builder(this);
//        NotificationCompat.Builder builder = new NotificationCompat.Builder(this)
//                .setDefaults(Notification.DEFAULT_ALL | Notification.FLAG_ONGOING_EVENT)
//                .setAutoCancel(true)
//                .setSmallIcon(R.mipmap.ic_launcher)
//                .setAutoCancel(true)
//                .setDefaults(Notification.DEFAULT_ALL | Intent.FLAG_ACTIVITY_CLEAR_TASK)// must requires VIBRATE permission
//                .setPriority(NotificationCompat.PRIORITY_HIGH);
//
//        startService(new Intent(this, Service.class));

//        assert notificationManager != null;
//        notificationManager.notify(0, builder.build());
//        buildNotificationCommon(getApplicationContext());
//        getApplicationContext().startActivity(new Intent(getApplicationContext(), CancelTripDialogActivity.class)
//                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));


        Bundle myBundle = new Bundle();
        myBundle.putString("title", "myBundleTitle");

        NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "N", NotificationManager.IMPORTANCE_DEFAULT);
            channel.enableLights(true);
            channel.setDescription("پی سپار");
            assert notificationManager != null;
            notificationManager.createNotificationChannel(channel);
        }

        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle(notificationModel.getTitle())
                .setContentText(notificationModel.getMessage())
                .setDefaults(Notification.DEFAULT_ALL)
                .setAutoCancel(true)
                .setContentIntent(PendingIntent.getActivity(this, 111
                        , new Intent(this, SplashActivity.class)
                                .putExtras(myBundle)
                                .setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK), 0))
                .setLargeIcon(BitmapFactory.decodeResource(this.getResources(), R.mipmap.ic_launcher))
                .setDefaults(Notification.DEFAULT_ALL) // must requires VIBRATE permission
                .setPriority(NotificationCompat.PRIORITY_HIGH); //must give priority to High, Max which will considered as heads-up notification

        assert notificationManager != null;
        notificationManager.notify(0, builder.build());
        buildNotificationCommon(getApplicationContext());

    }

    private void showDialogForCancelTrip(NotificationModel notificationModel) {
        Log.d(TAG, "showDialogForCancelTrip: " + notificationModel.getMessage());

        Bundle myBundle = new Bundle();
        myBundle.putString("title", "myBundleTitle");
        // myBundle.putString("message", "myBundleMessage");
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this)
                .setSmallIcon(R.mipmap.ic_launcher)
//                        .setContentTitle(notificationModel.getTitle())
                .setContentTitle(notificationModel.getTitle())
                .setContentText(notificationModel.getMessage())
                .setDefaults(Notification.DEFAULT_ALL)
                .setAutoCancel(true)
                .setAutoCancel(true)
                .setContentIntent(PendingIntent.getActivity(getApplicationContext()
                        , 0, new Intent(getApplicationContext(), CancelTripDialogActivity.class)
                                .putExtras(myBundle)
                                .setFlags(Intent.FLAG_ACTIVITY_NEW_TASK), 0))
                .setLargeIcon(BitmapFactory.decodeResource(this.getResources(), R.mipmap.ic_launcher))
                .setDefaults(Notification.DEFAULT_ALL | Intent.FLAG_ACTIVITY_CLEAR_TASK)// must requires VIBRATE permission
                .setPriority(NotificationCompat.PRIORITY_HIGH);//must give priority to H// igh, Max which will considered as heads-up notification


        NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);


        assert notificationManager != null;
        notificationManager.notify(0, builder.build());

//      builder.setVibrate(new long[]{1000, 1000, 1000, 1000, 1000});
        buildNotificationCommon(getApplicationContext());
//      notificationManager.notify(0, builder.build());
    }

    private void requestForsetDetailTripData(NotificationModel notificationModel) {

        App.userInfo.setType(2);
        App.userInfo.setStrMobile(Cache.getString("mobileNumber"));
        try {

            APIService apiService = APIClient.getClient().create(APIService.class);
            Call<List<Trip>> call = apiService.TripListHistory(App.userInfo, App.Session);
            call.enqueue(new Callback<List<Trip>>() {
                @Override
                public void onResponse(@NonNull Call<List<Trip>> call, @NonNull Response<List<Trip>> response) {
                    if (response.isSuccessful() && response.body() != null) {
                        App.listCurrentTrip = response.body();
                        if (notificationModel.getType().equals("OKDriver") || notificationModel.getType().equals("AssignDriver")) {
                            showaokadriverNotification(notificationModel);
                        } else
                            showNotification(notificationModel);
                    }
                }

                @Override
                public void onFailure(@NonNull Call<List<Trip>> call, @NonNull Throwable t) {
                }
            });

        } catch (Exception ignore) {
        }

    }

    private void showaokadriverNotification(NotificationModel notificationModel) {

        Bundle myBundle = new Bundle();
        myBundle.putString("title", "myBundleTitle");

        NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

        try {
            if (App.listCurrentTrip.size() != 0) {
                for (int i = 0; App.listCurrentTrip.size() > i; i++) {
                    int iOfficialTrip = App.listCurrentTrip.get(i).getiOfficialTrip();
                    if (iOfficialTrip == notificationModel.getiOfficialTrip()) {
                        App.model2 = App.listCurrentTrip.get(i);
                    }
                }
            }
        } catch (Exception ignored) {

        }

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "N"
                    , NotificationManager.IMPORTANCE_DEFAULT);
            channel.enableLights(true);
            channel.setDescription(String.valueOf(getText(R.string.app_name)));
            assert notificationManager != null;
            notificationManager.createNotificationChannel(channel);
        }

        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle(notificationModel.getTitle())
                .setContentText(notificationModel.getMessage())
                .setDefaults(Notification.DEFAULT_ALL)
                .setAutoCancel(true)
                .setContentIntent(PendingIntent.getActivity(getApplicationContext(), 111
                        , new Intent(getApplicationContext(), OKdriverActivity.class)
                                .putExtras(myBundle)
                                .setFlags(Intent.FLAG_ACTIVITY_NEW_TASK), 0))
                .setLargeIcon(BitmapFactory.decodeResource(this.getResources(), R.mipmap.ic_launcher))
                .setDefaults(Notification.DEFAULT_ALL | Intent.FLAG_ACTIVITY_CLEAR_TASK) // must requires VIBRATE permission
                .setPriority(NotificationCompat.PRIORITY_HIGH); //must give priority to High, Max which will considered as heads-up notification

        assert notificationManager != null;
        notificationManager.notify(0, builder.build());
        buildNotificationCommon(getApplicationContext());
    }

    private void showDifualtNotification(NotificationModel notificationModel) {
        PendingIntent pendingIntent;
        Bundle myBundle = new Bundle();
        myBundle.putString("title", "myBundleTitle");
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            pendingIntent = PendingIntent.getActivity(getApplicationContext(), 111
                    , new Intent(getApplicationContext(), SplashActivity.class)
                            .putExtras(myBundle)
                            .setFlags(Intent.FLAG_ACTIVITY_NEW_TASK), PendingIntent.FLAG_IMMUTABLE);
        } else {
            pendingIntent = PendingIntent.getActivity(getApplicationContext(), 111
                    , new Intent(getApplicationContext(), SplashActivity.class)
                            .putExtras(myBundle)
                            .setFlags(Intent.FLAG_ACTIVITY_NEW_TASK), 0);
        }

        // myBundle.putString("message", "myBundleMessage");
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this)
                .setSmallIcon(R.mipmap.ic_launcher)
//                        .setContentTitle(notificationModel.getTitle())
                .setContentTitle(notificationModel.getTitle())
                .setContentText(notificationModel.getMessage())
                .setDefaults(Notification.DEFAULT_ALL)
                .setAutoCancel(true)
                .setAutoCancel(true)
                .setContentIntent(pendingIntent)
                .setLargeIcon(BitmapFactory.decodeResource(this.getResources(), R.mipmap.ic_launcher))
                .setDefaults(Notification.DEFAULT_ALL | Intent.FLAG_ACTIVITY_CLEAR_TASK) // must requires VIBRATE permission
                .setPriority(NotificationCompat.PRIORITY_HIGH); //must give priority to High, Max which will considered as heads-up notification

        NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        assert notificationManager != null;
        notificationManager.notify(0, builder.build());

//        builder.setVibrate(new long[]{1000, 1000, 1000, 1000, 1000});
        buildNotificationCommon(getApplicationContext());
//        notificationManager.notify(0, builder.build());


    }


    private void showNotification(NotificationModel notificationModel) {

        Bundle myBundle = new Bundle();
        myBundle.putString("title", "myBundleTitle");

        NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

        try {
            if (App.listCurrentTrip.size() != 0) {
                for (int i = 0; App.listCurrentTrip.size() > i; i++) {
                    int iOfficialTrip = App.listCurrentTrip.get(i).getiOfficialTrip();
                    if (iOfficialTrip == notificationModel.getiOfficialTrip()) {
                        App.model2 = App.listCurrentTrip.get(i);
                    } else showDifualtNotification(notificationModel);
                }
            } else
                showDifualtNotification(notificationModel);
        } catch (Exception ignored) {

        }


        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "N", NotificationManager.IMPORTANCE_DEFAULT);
            channel.enableLights(true);
            channel.setDescription(String.valueOf(getText(R.string.app_name)));
            assert notificationManager != null;
            notificationManager.createNotificationChannel(channel);
        }

        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle(notificationModel.getTitle())
                .setContentText(notificationModel.getMessage())
                .setDefaults(Notification.DEFAULT_ALL)
                .setAutoCancel(true)
                .setContentIntent(PendingIntent.getActivity(getApplicationContext(), 111, new Intent(getApplicationContext(), OKdriverActivity.class)
                        .putExtras(myBundle)
                        .setFlags(Intent.FLAG_ACTIVITY_NEW_TASK), 0))
                .setLargeIcon(BitmapFactory.decodeResource(this.getResources(), R.mipmap.ic_launcher))
                .setDefaults(Notification.DEFAULT_ALL | Intent.FLAG_ACTIVITY_CLEAR_TASK) // must requires VIBRATE permission
                .setPriority(NotificationCompat.PRIORITY_HIGH); //must give priority to High, Max which will considered as heads-up notification

        assert notificationManager != null;
        notificationManager.notify(0, builder.build());
        buildNotificationCommon(getApplicationContext());

    }

    private static void buildNotificationCommon(Context _context) {
        NotificationCompat.Builder builder = new NotificationCompat.Builder(_context)
                .setWhen(System.currentTimeMillis());
        //Vibration
        builder.setVibrate(new long[]{1000, 1000, 1000, 1000, 1000});

        //LED
        builder.setLights(Color.RED, 3000, 3000);

        //Ton
        builder.setSound(Uri.parse("uri://sadfasdfasdf.mp3"));

    }

    private void wakeUpScreen() {
        // Wake up screen
        PowerManager powerManager = (PowerManager) context.getSystemService(Context.POWER_SERVICE);
        boolean isScreenOn;
        if (Build.VERSION.SDK_INT >= 20) {
            isScreenOn = powerManager.isInteractive();
        } else {
            isScreenOn = powerManager.isScreenOn();
        }
        if (!isScreenOn) {
            @SuppressLint("InvalidWakeLockTag") PowerManager.WakeLock wl = powerManager.newWakeLock(PowerManager.FULL_WAKE_LOCK | PowerManager.ACQUIRE_CAUSES_WAKEUP | PowerManager.ON_AFTER_RELEASE, "MH24_SCREENLOCK");
            wl.acquire(2000);
            @SuppressLint("InvalidWakeLockTag") PowerManager.WakeLock wl_cpu = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "MH24_SCREENLOCK");
            wl_cpu.acquire(2000);
        }
    }

}