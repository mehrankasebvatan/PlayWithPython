package com.rayanandisheh.peysepar.passenger.view.Activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.NumberPicker;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.rayanandisheh.peysepar.passenger.R;
import com.rayanandisheh.peysepar.passenger.helpers.App;
import com.rayanandisheh.peysepar.passenger.helpers.Cache;
import com.rayanandisheh.peysepar.passenger.helpers.PersianAppcompatActivity;
import com.rayanandisheh.peysepar.passenger.helpers.Time;
import com.rayanandisheh.peysepar.passenger.helpers.Toaster;
import com.rayanandisheh.peysepar.passenger.models.TripInsert;
import com.rayanandisheh.peysepar.passenger.models.TripSAD;
import com.rayanandisheh.peysepar.passenger.services.APIClient;
import com.rayanandisheh.peysepar.passenger.services.APIService;
import com.rayanandisheh.peysepar.passenger.view.Adapter.AddPasengerAdapter;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import ir.hamsaa.persiandatepicker.Listener;
import ir.hamsaa.persiandatepicker.PersianDatePickerDialog;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AddTripActivity1 extends PersianAppcompatActivity implements AddPasengerAdapter.OnItemClickListener {

    private static final String TAG = "AddTripActivity";
    Context context;
    TextView txtTimePicker;
    Spinner spnReason, spnImportance, spnCarType;
    Button btnRegisterTrip;
    ProgressBar pbRegisterTrip;
    Toolbar toolbar;
    RelativeLayout rlACtextDes;
    LinearLayout rlTextDes;
    AutoCompleteTextView autoCompleteTxtOrigin, autoCompleteTxtDes;
    EditText edtDate, edtEnterNamePassenges, edtCommentAddTrip;
    ImageView imgAddPassengers;
    RecyclerView rvAddPassenges;
    LinearLayoutManager linearLayoutManager;
    AddPasengerAdapter addPasengerAdapter;
    //    TimePicker picker;
    CheckBox chkBoxInService;
    ImageView ivWarningOrigin;
    ImageView ivWarningDes;
    ImageView ivWarningTripReason;
    ImageView ivWarningTripImportance;
    CheckBox chkBxReturn;
    CheckBox chkBxMissionary;
    NumberPicker npHour, npMin;
    Calendar calander;
    String numberPickerTime, dateNow, timeNow;

    private int iTripS_SAD = -1;
    private int iTripD_SAD = -1;

    String date;
    private PersianDatePickerDialog picker;
    private RadioGroup rg_typeTrip;
    private RadioButton radioTypeButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_trip1);

        context = this;
        dateNow = Time.getNowPersianDate();
        //getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE)
//        picker.setIs24HourView(true);
        bindView();

        viewLoaded();
        initializeRecyclerViewAddPassengers();

        chkBxReturn.setOnCheckedChangeListener((buttonView, isChecked) -> {
            chkBoxInService.setChecked(false);
            chkBxMissionary.setChecked(false);
        });

        chkBoxInService.setOnCheckedChangeListener((v, isChecked) -> {
            chkBxReturn.setChecked(false);
            chkBxMissionary.setChecked(false);
            chkInServiceChecked(isChecked);
        });

        chkBxMissionary.setOnCheckedChangeListener((buttonView, isChecked) -> {
            chkBxReturn.setChecked(false);
            chkBoxInService.setChecked(false);
        });

        edtDate.setOnClickListener(v -> cvCalandarPressed(edtDate));
        btnRegisterTrip.setOnClickListener(v -> getSelectedTime());

        spinnerTripReasonPressed(spnReason);
        spinnerTripImportancePressed(spnImportance);

        autoCompleteTxtDes.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.length() == 0)
                    ivWarningDes.setVisibility(View.VISIBLE);
                else
                    ivWarningDes.setVisibility(View.GONE);
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

//        autoCompleteTxtDes.setOnTouchListener((v, e) -> {
//            autoCompleteTxtDes.showDropDown();
//            return false;
//        });
//
//        autoCompleteTxtOrigin.setOnTouchListener((v, e) -> {
//            autoCompleteTxtDes.showDropDown();
//            return false;
//        });

        autoCompleteTxtOrigin.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.length() == 0)
                    ivWarningOrigin.setVisibility(View.VISIBLE);
                else
                    ivWarningOrigin.setVisibility(View.GONE);
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }

    private void getSelectedTime() {
        String time = edtDate.getText().toString();

        if (!autoCompleteTxtOrigin.getText().toString().isEmpty() && !(time.compareTo(dateNow) < 0)
                && (!autoCompleteTxtDes.getText().toString().isEmpty() || chkBoxInService.isChecked())) {

            numberPickerTime = (String.format("%s:%s", String.valueOf(npHour.getValue()).length() < 2 ? "0" + npHour.getValue() : npHour.getValue(),
                    String.valueOf(npMin.getValue()).length() < 2 ? "0" + npMin.getValue() : npMin.getValue()));
//            txtTimePicker.setText(numberPickerTime);

            int selectedId = rg_typeTrip.getCheckedRadioButtonId();
            radioTypeButton = (RadioButton) findViewById(selectedId);

            Log.i(TAG, "radioTypeButton: " + radioTypeButton.getText());

            btnPressed(
                    spnReason.getSelectedItemPosition(), spnImportance.getSelectedItemPosition(),
                    spnCarType.getSelectedItemPosition(),
                    autoCompleteTxtOrigin.getText().toString(), autoCompleteTxtDes.getText().toString(),
                    edtDate.getText().toString(), numberPickerTime, chkBoxInService.isChecked(),
                    chkBxReturn.isChecked(), chkBxMissionary.isChecked(), addPasengerAdapter.getList(), edtCommentAddTrip.getText().toString());

        } else {
            if (time.compareTo(dateNow) < 0)
                Toast.makeText(context, "شما مجاز به انتخاب تاریخ گذشته نمی باشید", Toast.LENGTH_SHORT).show();
//            else if (edtCommentAddTrip.getText().toString().isEmpty()) {
//                Toast.makeText(context, "پرکردن فیلد توضیحات سفر الزامی می باشد", Toast.LENGTH_SHORT).show();
            else
                Toast.makeText(context, "آدرس می بایست مشخص گردد", Toast.LENGTH_SHORT).show();

        }
    }

    private void bindView() {
        toolbar = findViewById(R.id.toolbar_add_trip);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        setTitle("افزودن سفر");

        chkBoxInService = findViewById(R.id.chkBxAvailable);
        ivWarningOrigin = findViewById(R.id.ivWarningOrigin);
        ivWarningDes = findViewById(R.id.ivWarningDes);
        ivWarningTripReason = findViewById(R.id.ivWarningTripReason);
        ivWarningTripImportance = findViewById(R.id.ivWarningTripImportance);
        chkBxReturn = findViewById(R.id.chkBxReturn);
        chkBxMissionary = findViewById(R.id.chkBxMissionary);
        rg_typeTrip = findViewById(R.id.rg_typeTrip);

//        txtApplicantName = findViewById(R.id.txtapplicantNameRegisterTrip);
        edtDate = findViewById(R.id.edtDateRegisterTrip);
        edtDate.setText(Time.getNowPersianDate());

//        txtMobile = findViewById(R.id.txtMobileRegisterTrip);
        spnReason = findViewById(R.id.spinnerReason);
        spnImportance = findViewById(R.id.spinnerImportance);
        pbRegisterTrip = findViewById(R.id.pbRegisterTrip);
        btnRegisterTrip = findViewById(R.id.btnRegisterTrip);

        rlTextDes = findViewById(R.id.rlTextDes);
        rlACtextDes = findViewById(R.id.rlACtextDes);

        autoCompleteTxtOrigin = findViewById(R.id.autoCompleteTxtOrigin);
        autoCompleteTxtDes = findViewById(R.id.autoCompleteTxtDes);

        edtEnterNamePassenges = findViewById(R.id.edtEnterNamePassenges);
        imgAddPassengers = findViewById(R.id.imgAdd);
        rvAddPassenges = findViewById(R.id.recyclerViewAddPassengers);


        npHour = findViewById(R.id.npHour);
        npMin = findViewById(R.id.npMin);
        calander = Calendar.getInstance();
        npHour.setMinValue(0);
        npHour.setMaxValue(23);
        npHour.setFormatter(new NumberPicker.Formatter() {
            @Override
            public String format(int i) {
                return String.format("%02d", i);
            }
        });
        npHour.setValue(calander.get(Calendar.HOUR_OF_DAY));


        npMin.setMinValue(0);
        npMin.setMaxValue(59);
        npMin.setFormatter(new NumberPicker.Formatter() {
            @Override
            public String format(int i) {
                return String.format("%02d", i);
            }
        });
        npMin.setValue(calander.get(Calendar.MINUTE));


        spnCarType = findViewById(R.id.spinnerCarType);

        edtCommentAddTrip = findViewById(R.id.edtCommentAddTrip);
//        txtApplicantName.setText(String.format("%s %s", App.userInfo.getStrName(), App.userInfo.getStrFamily()));
//        txtMobile.setText(Cache.getString("mobileNumber"));
    }

    public void cvCalandarPressed(EditText edtDate) {

        final InputMethodManager imm = (InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.showSoftInput(edtDate, InputMethodManager.SHOW_IMPLICIT);

//        PersianCalendar initDate = new PersianCalendar();
//        initDate.setPersianDate(1370, 3, 13);

        picker = new PersianDatePickerDialog(context)
                .setPositiveButtonString("تایید")
                .setNegativeButton("انصراف")
                .setTodayButton("امروز")
                .setTodayButtonVisible(true)
                .setMinYear(1300)
                .setMaxYear(1450)
//                .setMaxYear(PersianDatePickerDialog.THIS_YEAR)
//                .setInitDate(initDate)
                .setActionTextColor(Color.GRAY)
//                .setTypeFace(typeface)
                .setListener(new Listener() {
                    @Override
                    public void onDateSelected(ir.hamsaa.persiandatepicker.util.PersianCalendar persianCalendar) {

//                        date = persianCalendar.getPersianYear() + "/"
//                                + persianCalendar.getPersianMonth() + "/"
//                                + persianCalendar.getPersianDay();

                        date = persianCalendar.getPersianYear() + "/" +
                                (String.valueOf(persianCalendar.getPersianMonth()).length() < 2 ? "0" + persianCalendar.getPersianMonth() : persianCalendar.getPersianMonth()) + "/" +
                                (String.valueOf(persianCalendar.getPersianDay()).length() < 2 ? "0" + persianCalendar.getPersianDay() : persianCalendar.getPersianDay());


//                             Toast.makeText(context, date, Toast.LENGTH_SHORT).show();
                        edtDate.setText(date);
                    }

                    @Override
                    public void onDismissed() {
                    }
                });
        picker.show();
    }

    public void spinnerTripReasonPressed(Spinner spnReason) {
        spnReason.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View v, int position, long id) {
                String item = parent.getItemAtPosition(position).toString();
                if (item.equals("انتخاب کنید")) {
                    showIvWarningReason();
                } else {
                    hideIvWarningReason();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
    }

    public void spinnerTripImportancePressed(Spinner spnImportance) {
        spnImportance.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View v, int position, long id) {
                String item = parent.getItemAtPosition(position).toString();
                if (item.equals("انتخاب کنید")) {
                    showIvWarningImportance();
                } else {
                    hideIvWarningImportance();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
    }

    public void viewLoaded() {
//        view.setSpnOriginData(model.getSpnOriginData());
//        view.setSpnDesData(model.getSpnDesData());
        setSpnReasonData(getSpnReasonData());
        setSpnImportanceData(getImportanceData());

        setOriginDes(getOriginDes());

        setSpnCarType(getSpnTypeCar());

//
//        String[] s = new String[App.userInfo.getTripSAD().size()];
//        for (int i = 0; i < App.userInfo.getTripSAD().size(); i++)
//            s[i] = App.userInfo.getTripSAD().get(i).getStrName();
//        ArrayAdapter<String> adapter = new ArrayAdapter<String>(context, android.R.layout.select_dialog_item, s);
//        List<String> redddasons = new ArrayList<String>();
//        for (int i = 0; i < App.userInfo.getTripSAD().size(); i++)
//         redddasons.add(App.userInfo.getTripReason().get(i).getStrComment());
//        view.getOriginDes(adapter);

    }

    public void chkInServiceChecked(boolean chkInServiceisChecked) {

        if (chkInServiceisChecked)
            HideDestination();
        else
            showDestination();
    }

    public void btnPressed(int spnReason, int spnImportance, int spnCarType, String autoCompleteTxtOrigin,
                           String autoCompleteTxtDes, String edtDate, String numberPickerTime,
                           boolean chkBoxInService, boolean chkBxReturn, boolean chkBxMissionary, String list, String strComment) {

        showProgressBar();
        requestAddTrip(spnReason, spnImportance, spnCarType, autoCompleteTxtOrigin,
                autoCompleteTxtDes, edtDate, numberPickerTime, chkBoxInService, chkBxReturn, chkBxMissionary, list, strComment);
    }

    public List<String> getSpnOriginData() {
        List<String> origin = new ArrayList<String>();
        origin.add("انتخاب کنید");
        origin.add("میدان آزادی");
        origin.add("انقلاب");
        origin.add("پیروزی");
        return origin;
    }

    public List<String> getSpnDesData() {
        List<String> destination = new ArrayList<String>();
        destination.add("انتخاب کنید");
        destination.add("بیمه سلامت");
        destination.add("ترمینال 4 فرودگاه مهرآباد");
        return destination;
    }

    public List<String> getSpnReasonData() {
        List<String> reasons = new ArrayList<>();
        for (int i = 0; i < App.userInfo.getTripReason().size(); i++)
            reasons.add(App.userInfo.getTripReason().get(i).getStrComment());
        return reasons;
    }

    public List<String> getSpnTypeCar() {
        List<String> cartype = new ArrayList<>();
        for (int i = 0; i < App.userInfo.getMobileType().size(); i++)
            cartype.add(App.userInfo.getMobileType().get(i).getStrComment());
        return cartype;
    }

    public List<String> getImportanceData() {
        List<String> importance = new ArrayList<>();
        for (int i = 0; i < App.userInfo.getTripImportance().size(); i++)
            importance.add(App.userInfo.getTripImportance().get(i).getStrComment());
        return importance;
    }

    public List<String> getOriginDes() {
        List<String> originDes = new ArrayList<String>();
        for (int i = 0; i < App.userInfo.getTripSAD().size(); i++)
            originDes.add(App.userInfo.getTripSAD().get(i).getStrName());
        return originDes;
    }

    public void requestAddTrip(int spnReason, int spnImportance, int spnCarType, String autoCompleteTxtOrigin,
                               String autoCompleteTxtDes, String edtDate, String numberPickerTime,
                               boolean chkBoxInService, boolean chkBxReturn, boolean chkBxMissionary, String list, String strComment) {

        TripInsert tripInsert = new TripInsert();
        tripInsert.setTiTripReason((short) App.userInfo.getTripReason().get(spnReason).getTiTripReason());
        tripInsert.setTiTripImportance((short) App.userInfo.getTripImportance().get(spnImportance).getTiTripImportance());
        tripInsert.setMobileType((short) App.userInfo.getMobileType().get(spnCarType).getTiMobileType());

        tripInsert.setStrComment(strComment);

        tripInsert.setStrTripDate(edtDate);
        tripInsert.setStrTripTime(numberPickerTime);

        tripInsert.setbHaveReturn(chkBxReturn);
        tripInsert.setbExclusive(chkBoxInService);
        tripInsert.setbMissionary(chkBxMissionary);

        tripInsert.setStrApplicantMobile(Cache.getString("mobileNumber"));
        tripInsert.setStrPassengersName(list);

//        for (TripImportance tripImportance : App.userInfo.getTripImportance()) {
//            if (autoCompleteTxtDes.equals(tripImportance.getStrComment())){
//                tripImportance.getTiTripImportance();
//            }
//        }

        for (TripSAD tripSAD : App.userInfo.getTripSAD()) {
            if (autoCompleteTxtOrigin.equals(tripSAD.getStrName())) {
                tripInsert.setiTripSADSource(tripSAD.getiTripSad());
            }
        }

        if (tripInsert.getiTripSADSource() == -1) {
            noValidOrigin();
            return;
        }


        for (TripSAD tripSAD : App.userInfo.getTripSAD()) {
            if (autoCompleteTxtDes.equals(tripSAD.getStrName())) {
//                tripSAD.getiTripSad();
                tripInsert.setiTripSADDestination(tripSAD.getiTripSad());
            }
        }
        if (!chkBoxInService && tripInsert.getiTripSADDestination() == -1) {
            noValidDes();
            return;
        }

        if (tripInsert.getiTripSADSource() == tripInsert.getiTripSADDestination()) {
            ErrorEqualOriginDestination();
            return;
        }

        APIService apiService = APIClient.getClient().create(APIService.class);
        Call<Integer> call = apiService.InsertTrip(tripInsert, iTripS_SAD, iTripD_SAD,App.Session);
        call.enqueue(new Callback<Integer>() {
            @Override
            public void onResponse(Call<Integer> call, Response<Integer> response) {

                if (response.code() == 200 && response.body() != null) {
                    tripInsertResult(response.body());
                    App.pursuitCode = response.body();

                } else {
                    tripInsertResult(-4);
                }
            }

            @Override
            public void onFailure(Call<Integer> call, Throwable t) {
                tripInsertResult(-1);
            }
        });
    }

    public void tripInsertResult(Integer result) {

        hidePreogressBar();

        if (result == -4) {
            Toaster.shorter(context.getString(R.string.serverFaield));
        } else if (result == -1) {
            Toaster.shorter(context.getString(R.string.connectionFaield));
        } else if (result == 0) {
            Toaster.shorter("سفر شما قبلا ثبت شده است");
        }else if (result == 100) {
            Intent intent=new Intent(AddTripActivity1.this, LoginActivity.class);
            startActivity(intent);

        } else if (result == -2) {
            Toaster.shorter("بازه ی زمانی درخواست شما به پایان رسیده است،لطفا در بازه مجاز اقدام به ثبت درخواست نمایید");
        } else {
//            Toast.makeText(context, "کد رهگیری شما" + result, Toast.LENGTH_SHORT).show();
            Toaster.shorter("سفر شما با موفقیت ثبت شد");

            context.startActivity(new Intent(context, MainActivity.class));
            ((Activity) context).finish();
        }
    }

    public void noValidDes() {
        Toaster.shorter("آدرس مقصد می بایست از موارد پیشنهادی انتخاب گردد");
        hidePreogressBar();
    }

    public void noValidOrigin() {
        Toaster.shorter("آدرس مبدا می بایست از موارد پیشنهادی انتخاب گردد");
        hidePreogressBar();
    }

    public void ErrorEqualOriginDestination() {
        Toaster.shorter("مبدا و مقصد نباید یکسان انتخاب گردند");
        hidePreogressBar();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public void setSpnReasonData(List<String> spnReasonData) {
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(context, android.R.layout.simple_spinner_item, spnReasonData);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spnReason.setAdapter(dataAdapter);
    }

    public void setSpnImportanceData(List<String> importanceData) {
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(context, android.R.layout.simple_spinner_item, importanceData);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spnImportance.setAdapter(dataAdapter);
    }

    public void setSpnCarType(List<String> spnTypeCar) {
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(context, android.R.layout.simple_spinner_item, spnTypeCar);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spnCarType.setAdapter(dataAdapter);
    }

    public void showIvWarningOrigin() {
        ivWarningOrigin.setVisibility(View.VISIBLE);
    }

    public void hideIvWarningOrigin() {
        ivWarningOrigin.setVisibility(View.GONE);
    }

    public void showIvWarningDes() {
        ivWarningDes.setVisibility(View.VISIBLE);
    }

    public void hideIvWarningDes() {
        ivWarningDes.setVisibility(View.GONE);
    }

    public void showIvWarningReason() {
        ivWarningTripReason.setVisibility(View.VISIBLE);
    }

    public void hideIvWarningReason() {
        ivWarningTripReason.setVisibility(View.GONE);
    }

    public void showIvWarningImportance() {
        ivWarningTripImportance.setVisibility(View.VISIBLE);
    }

    public void hideIvWarningImportance() {
        ivWarningTripImportance.setVisibility(View.GONE);
    }

    public void getOriginDes(ArrayAdapter<String> adapter) {
        autoCompleteTxtOrigin.setThreshold(1);
        autoCompleteTxtOrigin.setAdapter(adapter);

        autoCompleteTxtDes.setThreshold(1);
        autoCompleteTxtDes.setAdapter(adapter);
    }

    public void setOriginDes(List<String> originDes) {
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(context, R.layout.select_dialog_item_custom, originDes);
        autoCompleteTxtOrigin.setThreshold(1);
        autoCompleteTxtOrigin.setAdapter(adapter);
        autoCompleteTxtDes.setThreshold(1);
        autoCompleteTxtDes.setAdapter(adapter);
    }

    public void HideDestination() {

        rlACtextDes.setVisibility(View.GONE);
        rlTextDes.setVisibility(View.GONE);
    }

    public void showDestination() {
        rlACtextDes.setVisibility(View.VISIBLE);
        rlTextDes.setVisibility(View.VISIBLE);
    }

    public void showProgressBar() {
        pbRegisterTrip.setVisibility(View.VISIBLE);
        btnRegisterTrip.setVisibility(View.GONE);
    }

    public void hidePreogressBar() {
        pbRegisterTrip.setVisibility(View.GONE);
        btnRegisterTrip.setVisibility(View.VISIBLE);
    }

    private void initializeRecyclerViewAddPassengers() {
        linearLayoutManager = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);
        addPasengerAdapter = new AddPasengerAdapter(this);
        addPasengerAdapter.setOnItemClickListener(this);
        rvAddPassenges.setAdapter(addPasengerAdapter);
        rvAddPassenges.setLayoutManager(linearLayoutManager);

        imgAddPassengers.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                String newName = edtEnterNamePassenges.getText().toString();
                if (!newName.equals("")) {
                    if (addPasengerAdapter.getItemCount() > 1) {
                        addPasengerAdapter.add(0, newName);
                        edtEnterNamePassenges.setText("");
                    } else {
                        addPasengerAdapter.add(0, newName);
                        edtEnterNamePassenges.setText("");
                    }
                }
            }
        });
    }

    @Override
    public void onItemClick(AddPasengerAdapter.ItemHolder item, int position) {
//        Toast.makeText(this, "Remove " + position + " : " + item.getItemName(), Toast.LENGTH_SHORT).show();
        addPasengerAdapter.remove(position);
    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }
}

