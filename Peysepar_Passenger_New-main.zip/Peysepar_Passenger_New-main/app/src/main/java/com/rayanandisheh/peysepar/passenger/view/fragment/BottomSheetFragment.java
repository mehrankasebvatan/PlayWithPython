package com.rayanandisheh.peysepar.passenger.view.fragment;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;

import com.google.android.material.bottomsheet.BottomSheetDialogFragment;

import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.rayanandisheh.peysepar.passenger.R;
import com.rayanandisheh.peysepar.passenger.helpers.App;
import com.rayanandisheh.peysepar.passenger.helpers.Cache;
import com.rayanandisheh.peysepar.passenger.helpers.Time;
import com.rayanandisheh.peysepar.passenger.helpers.Toaster;
import com.rayanandisheh.peysepar.passenger.models.Report;
import com.rayanandisheh.peysepar.passenger.services.APIClient;
import com.rayanandisheh.peysepar.passenger.services.APIService;
import com.rayanandisheh.peysepar.passenger.view.Activity.LoginActivity;
import com.rayanandisheh.peysepar.passenger.view.Activity.TripManagementNewActivity;

import org.jetbrains.annotations.NotNull;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static android.content.ContentValues.TAG;

public class BottomSheetFragment extends BottomSheetDialogFragment {
    Context context;

    TextView txtRequestTodayTrip, txtTotalTimeTodayTrip, txtKMTodayTrip, currentDateFragment;

    //
//    float km;
    public BottomSheetFragment() {
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_bottom_sheet, container, false);
        context = getContext();

        bindView(view);

        viewLoaded();

        currentDateFragment.setText(Time.getNowPersianDate());

//        if(App.report.getTime() !=0)
//         txtTotalTimeTodayTrip.setText(Time.minutesToHours((int) App.report.getTime()) );
//         else{
//            txtTotalTimeTodayTrip.setText("0"+" " + "دقیقه");
//        }


//         txtKMTodayTrip.setText(String.valueOf(App.report.getFkm()));
//         txtRequestTodayTrip.setText(String.valueOf(App.report.getTripCount()));

        return view;
    }

    private void bindView(View view) {
        txtTotalTimeTodayTrip = view.findViewById(R.id.txtTotalTimeTodayTrip);
        txtRequestTodayTrip = view.findViewById(R.id.txtRequestTodayTrip);
        txtKMTodayTrip = view.findViewById(R.id.txtKMTodayTrip);
        currentDateFragment = view.findViewById(R.id.currentDateFragment);
    }

    public void setText() {
        if (App.report.getTime() != null)
            txtTotalTimeTodayTrip.setText(Time.minutesToHours(App.report.getTime()));
        else
            txtTotalTimeTodayTrip.setText("0" + " " + "دقیقه");


        //        txtKMTodayTrip.setText(String.valueOf(Float.parseFloat(FloatLimitation.formatFloatLimitation(App.report.getFkm()))));

//          km =App.report.getFkm();
//          if(km<1000){
//              String km1=String.valueOf(App.report.getFkm()) + "متر";
//          }


//
        if (App.report.getFkm() != 0) {

            txtKMTodayTrip.setText(String.format("%.2f", App.report.getFkm()) + " " + "کیلومتر");

//            if(App.report.getFkm()<1000 && App.report.getFkm()>0)
//            txtKMTodayTrip.setText(String.format("%.2f", App.report.getFkm())+" "+ "کیلومتر");
//            else if(App.report.getFkm()>1000){
//                txtKMTodayTrip.setText(String.format("%.2f", App.report.getFkm()/1000)+" "+ " کیلومتر");
//            }
        }

//        if(App.report.getFkm() !=0)
//                txtKMTodayTrip.setText(String.format("%.1f", App.report.getFkm()));
        else
            txtKMTodayTrip.setText("0" + " " + "کیلومتر");
        txtRequestTodayTrip.setText(String.valueOf(App.report.getTripCount()));
    }

    public void requestTripTodayInfo() {

        App.report.setStrMobile(Cache.getString("mobileNumber"));
        APIService apiService = APIClient.getClient().create(APIService.class);
        Call<Report> call = apiService.report(App.report, App.Session);

        call.enqueue(new Callback<Report>() {
            @Override
            public void onResponse(@NonNull Call<Report> call, @NotNull Response<Report> response) {

                if (response.code() == 200 && response.body() != null) {
                    App.report = response.body();
                    reportResult(response.body().getResult());

                } else {
                    reportResult(-4);
                }
            }

            @Override
            public void onFailure(@NonNull Call<Report> call, @NotNull Throwable t) {
                reportResult(-5);
            }
        });
    }

    public void viewLoaded() {
        requestTripTodayInfo();
    }

    public void reportResult(int reportResult) {
        if (reportResult < 1) {
            Toaster.shorter(App.report.getStrMessage());
        } else if (reportResult == -4) {
            Toaster.shorter(context.getString(R.string.serverFaield));
        } else if (reportResult == -5) {
            Toaster.shorter(context.getString(R.string.connectionFaield));
        } else if (reportResult == 100) {
            Intent intent = new Intent(getActivity(), LoginActivity.class);
            startActivity(intent);

        } else {
            setText();
        }
    }

    @Override
    public void onResume() {
        super.onResume();

        if (App.report.getTime() != null)
            txtTotalTimeTodayTrip.setText(Time.minutesToHours(App.report.getTime()));
        else
            txtTotalTimeTodayTrip.setText("0" + " " + "دقیقه");


        if (App.report.getFkm() != 0) {
            txtKMTodayTrip.setText(String.format("%.2f", App.report.getFkm()) + " " + "کیلومتر");
//            if(App.report.getFkm()<1000 && App.report.getFkm()>0)
//                txtKMTodayTrip.setText(String.format("%.0f", App.report.getFkm())+" "+ "متر");
//            else if(App.report.getFkm()>1000){
//                txtKMTodayTrip.setText(String.format("%.1f", App.report.getFkm()/1000)+" "+ " کیلومتر");
//            }
        } else
            txtKMTodayTrip.setText("0" + " " + "کیلومتر");


        txtRequestTodayTrip.setText(String.valueOf(App.report.getTripCount()));
    }
}
