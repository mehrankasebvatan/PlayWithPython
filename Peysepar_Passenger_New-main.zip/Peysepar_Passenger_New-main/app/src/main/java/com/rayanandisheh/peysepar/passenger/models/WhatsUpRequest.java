package com.rayanandisheh.peysepar.passenger.models;

import com.google.gson.annotations.SerializedName;

public class WhatsUpRequest {

    @SerializedName("iPassenger")
    int iPassenger;

    @SerializedName("strFullName")
    String strFullName;


    @SerializedName("strAppVersion")
    String strAppVersion;

    public int getiPassenger() {
        return iPassenger;
    }

    public void setiPassenger(int iPassenger) {
        this.iPassenger = iPassenger;
    }

    public String getStrFullName() {
        return strFullName;
    }

    public void setStrFullName(String strFullName) {
        this.strFullName = strFullName;
    }

    public String getStrAppVersion() {
        return strAppVersion;
    }

    public void setStrAppVersion(String strAppVersion) {
        this.strAppVersion = strAppVersion;
    }
}
