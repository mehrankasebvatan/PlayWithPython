package com.rayanandisheh.peysepar.passenger.view.Activity;

import static com.rayanandisheh.peysepar.passenger.helpers.App.modeOfInsert;
import static com.rayanandisheh.peysepar.passenger.helpers.App.userInfo;
import static com.rayanandisheh.peysepar.passenger.view.Activity.MapsForAddTripActivity.counter;
import static com.rayanandisheh.peysepar.passenger.view.Activity.MapsForAddTripActivity.destinationLatLon;
import static com.rayanandisheh.peysepar.passenger.view.Activity.MapsForAddTripActivity.originLatLon;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ActivityManager;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.util.Base64;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.bumptech.glide.Glide;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;
import com.rayanandisheh.peysepar.passenger.R;
import com.rayanandisheh.peysepar.passenger.helpers.App;
import com.rayanandisheh.peysepar.passenger.helpers.Cache;
import com.rayanandisheh.peysepar.passenger.helpers.EnumTypeVersion;
import com.rayanandisheh.peysepar.passenger.helpers.MyLocation;
import com.rayanandisheh.peysepar.passenger.helpers.PersianAppcompatActivity;
import com.rayanandisheh.peysepar.passenger.helpers.Time;
import com.rayanandisheh.peysepar.passenger.helpers.Toaster;
import com.rayanandisheh.peysepar.passenger.models.Dashboard;
import com.rayanandisheh.peysepar.passenger.models.MobileVersionCntrol;
import com.rayanandisheh.peysepar.passenger.models.Trip;
import com.rayanandisheh.peysepar.passenger.models.UserInfo;
import com.rayanandisheh.peysepar.passenger.services.APIClient;
import com.rayanandisheh.peysepar.passenger.services.APIService;
import com.rayanandisheh.peysepar.passenger.view.Adapter.CurrentTripAdapter;
import com.rayanandisheh.peysepar.passenger.view.dialog.DialogCheckVersion;
import com.rayanandisheh.peysepar.passenger.view.fragment.BottomSheetFragment;

import org.jetbrains.annotations.NotNull;

import java.util.List;
import java.util.Objects;

import de.hdodenhof.circleimageview.BuildConfig;
import de.hdodenhof.circleimageview.CircleImageView;
import jp.wasabeef.recyclerview.adapters.AlphaInAnimationAdapter;
import jp.wasabeef.recyclerview.adapters.ScaleInAnimationAdapter;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends PersianAppcompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    private static final String TAG = "MainActivity";
    public static int ACTION_MANAGE_OVERLAY_PERMISSION_REQUEST_CODE = 5469;
    public static boolean exit = false;
    public static String chooseIcon = "";
    Context context;
    Toolbar toolbar;
    Activity activity;
    Trip data = new Trip();
    //    ImageView ivMenu;
    FloatingActionButton fabAdd;
    FloatingActionButton fabInfo;
    RecyclerView recyclerView;
    CurrentTripAdapter adapter;
    SwipeRefreshLayout swipeRefresh;
    NavigationView navigationView;

    //    List<Trip> modelCurrentTrip =new ArrayList<>();
    DrawerLayout drawerLayout;
    View navHeader;
    ProgressBar progressBar;
    ImageView img_noCurrentItem;
    TextView tvMenuName, txtDateHeadMain;
    boolean doubleBackToExitPressedOnce = false;
    TextView txt_domain;
    private int currentVersion;
    private TextView tv_main_countTrips;
    private TextView tv_main_distanceTrips;
    private TextView tv_main_timeTrips;

    private CardView cv_main_trip_count;
    private CardView cv_main_distance;
    private CardView cv_main_time;
    private EnumTypeVersion enumTypeVersion = EnumTypeVersion.LAST_VERSION;
    private String appName = "Saman";
    private String packageName = "com.rayanandisheh.radyab";
    CircleImageView ivMenuProfilePicture;
    ConstraintLayout relativeLayout2;
    RelativeLayout nav_tripManagementNew, nav_historyTrips, nav_tripDashboard, nav_news, nav_help, nav_about_peysepar, nav_about, nav_exit;

    @SuppressLint("WrongConstant")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main1);
        context = this;
        activity = this;
        bindViews();
        menuHandle();

//        if (Helper.isAppRunning(context, "com.rayanandisheh.peysepar.passenger")) {
//            // App is running
//            App.IsRun = true;
//
//        } else {
//            // App is not running
//            App.IsRun = false;
//        }
//        presenter.startService(context);

        try {
            if (!Cache.getString("peyseparDomain").equals("") && Cache.getString("peyseparDomain") != null) {
                txt_domain.setVisibility(View.VISIBLE);
                String txt = "پی سپار " + Cache.getString("peyseparDomain");
                txt_domain.setText(txt);

            } else {

                txt_domain.setText("پی سپار");
            }
        } catch (Exception e) {
        }


        // txtDateHeadMain.setText(Time.getNowPersianDate());
        swipeRefresh.setOnRefreshListener(() -> {
//            adapter.clear();
            showSwipeRefresh();
            loadCurrentTripList();
            //tvMenuName.setText(String.format("%s %s", userInfo.getStrName(), userInfo.getStrFamily()));
        });


        // TripManagement Access
        //Menu menu = navigationView.getMenu();
        //MenuItem nav_tripManagementNew = menu.findItem(R.id.nav_tripManagementNew);
        //MenuItem nav_tripDashboard = menu.findItem(R.id.nav_tripDashboard);
        // nav_tripManagementNew.setVisible(false);
        //nav_tripDashboard.setVisible(false);

  /*      if (userInfo.getDashboard() == 1) {
            nav_tripDashboard.setVisible(true);
        }
        if (userInfo.getManageTrip() || userInfo.getConfirmTrip()) {
            nav_tripManagementNew.setVisible(true);
        }*/

        Intent intent = new Intent(Intent.ACTION_MAIN);
        intent.addCategory(Intent.CATEGORY_HOME);
        String currentHomePackage = "none";
        ResolveInfo resolveInfo = getPackageManager().resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY);

        // in case of duplicate apps (Xiaomi), calling resolveActivity from one will return null
        if (resolveInfo != null) {
            currentHomePackage = resolveInfo.activityInfo.packageName;
        }
    }


    public void menuHandle() {
        tvMenuName.setText(String.format("%s %s", userInfo.getStrName(), userInfo.getStrFamily()));

        if (tvMenuName == null) {
            Intent intent = new Intent(MainActivity.this, LoginActivity.class);
            startActivity(intent);
        }
        ivMenuProfilePicture.setOnClickListener(v -> {
            startActivity(new Intent(context, NewProfileActivity.class));
            drawerLayout.closeDrawer(GravityCompat.START);

        });

        if (userInfo.getDashboard() == 1) {
            nav_tripDashboard.setVisibility(View.VISIBLE);
        }
        if (userInfo.getManageTrip() || userInfo.getConfirmTrip()) {
            nav_tripManagementNew.setVisibility(View.VISIBLE);
        }

        nav_historyTrips.setOnClickListener(view -> {
            context.startActivity(new Intent(context, HistoryActivity.class));
            drawerLayout.close();
        });

        nav_tripManagementNew.setOnClickListener(view -> {
            context.startActivity(new Intent(context, TripManagementNewActivity.class));
            drawerLayout.close();

        });

        nav_about.setOnClickListener(view -> {
            context.startActivity(new Intent(context, AboutUsActivity.class));
            drawerLayout.close();
        });

        nav_news.setOnClickListener(view -> {
            context.startActivity(new Intent(context, NewsActivity.class));
            drawerLayout.close();
        });

        nav_tripDashboard.setOnClickListener(view -> {
            context.startActivity(new Intent(context, DashboardActivity.class));
            drawerLayout.close();
        });

        nav_about_peysepar.setOnClickListener(view -> {
            context.startActivity(new Intent(context, AboutPassengerApplicationActivity.class));
            drawerLayout.close();
        });

        nav_help.setOnClickListener(view -> {
            context.startActivity(new Intent(context, HelpActivity.class));
            drawerLayout.close();
        });

        nav_exit.setOnClickListener(view -> {
            drawerLayout.close();
            closeApp();
        });

    }

    public void loadDashboardTrips() {
        showProgressBar();
        App.score.setStrDate(Time.getNowPersianDate());
        App.score.setiMobileDomain(App.userInfo.getiMobileDomain());

        APIService apiService = APIClient.getClient().create(APIService.class);
        Call<Dashboard> call = apiService.PassengerDashboard(App.userInfo.getStrMobile(), App.Session);
        call.enqueue(new Callback<Dashboard>() {
            @Override
            public void onResponse(@NotNull Call<Dashboard> call, @NotNull Response<Dashboard> response) {
                showLayoutDashboard();
                if (response.code() == 200 && response.body() != null) {
                    App.dashboard = response.body();

                    tv_main_countTrips.setText(String.valueOf(response.body().getPassenger_CountTrip()));
                    tv_main_distanceTrips.setText(String.valueOf(response.body().getPassenger_KMTrip()));
                    tv_main_timeTrips.setText(String.valueOf(response.body().getPassenger_TimeTrip()));

//                    tv_main_countTrips.setText("7");
//                    tv_main_distanceTrips.setText("427");
//                    tv_main_timeTrips.setText("08:26");

                    hideProgressBar();
                    hideSwipeRefresh();
                    hideRecyclerView();
                } else {
                    dashboardTripResult(-4);
                }
            }

            @Override
            public void onFailure(@NotNull Call<Dashboard> call, @NotNull Throwable t) {
                dashboardTripResult(-5);
            }
        });
    }

    public void dashboardTripResult(int result) {
        hideSwipeRefresh();
        if (result == -4) {
            Toaster.shorter(context.getString(R.string.serverFaield));
        } else if (result == -5) {
            Toaster.shorter(context.getString(R.string.connectionFaield));
        } else if (result == 100) {
            Intent intent = new Intent(MainActivity.this, LoginActivity.class);
            startActivity(intent);
//        else if (result == 1) {
        } else {
            Toast.makeText(context, App.dashboard.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    public void loadCurrentTripList() {
        showProgressBar();
        App.userInfo.setType(2);
        App.userInfo.setStrMobile(Cache.getString("mobileNumber"));
        APIService apiService = APIClient.getClient().create(APIService.class);
        Call<List<Trip>> call = apiService.TripListHistory(App.userInfo, App.Session);
        call.enqueue(new Callback<List<Trip>>() {
            @Override
            public void onResponse(@NonNull Call<List<Trip>> call, @NonNull Response<List<Trip>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    App.listCurrentTrip = response.body();
                    for (int i = 0; App.listCurrentTrip.size() > i; i++) {
                        if (App.listCurrentTrip.get(i).getResult() == 100) {
                            currentTripResult(100);

                        }
                    }

                    if (App.listCurrentTrip.size() > 0)
                        currentTripResult(1);
//                        App.currentTripSuccess=false;
                    else
                        currentTripResult(0);

                } else {
                    currentTripResult(-4);
                }
            }

            @Override
            public void onFailure(@NonNull Call<List<Trip>> call, @NonNull Throwable t) {
                currentTripResult(-5);
                Log.i(TAG, "loadCurrentTripList: " + t.toString());
            }
        });
    }

    public void currentTripResult(int result) {
        hideProgressBar();
        hideSwipeRefresh();
        if (result == -4) {
            Toaster.shorter(context.getString(R.string.serverFaield));
        } else if (result == 100) {
            Intent intent = new Intent(MainActivity.this, LoginActivity.class);
            startActivity(intent);
            finish();
        } else if (result == -5) {
            Toaster.shorter(context.getString(R.string.connectionFaield));
        } else if (result == 0) {
            loadDashboardTrips();
            hideRecyclerView();
            showImageEmpety();
        } else if (result == 1) {
            for (int i = 0; App.listCurrentTrip.size() > i; i++) {
                if (App.listCurrentTrip.get(i).getTiTripStatus() == 7) {
                    App.notifModel = null;
                    data = App.listCurrentTrip.get(i);
                    Bundle nbundle = new Bundle();
                    nbundle.putParcelable("signature", data);
                    Intent nintent = new Intent(context, SignatureActivity.class);
                    nintent.putExtras(nbundle);
                    context.startActivity(nintent);
                    Log.i(TAG, "currentTripResult: SignatureActivity");
                }
            }
            hideLayoutDashboard();
            showRecyclerView();
            setAdapter();

            if (App.listCurrentTrip.size() > 0) {
                hideImageEmpety();
                showRecyclerView();
            } else {
                hideRecyclerView();
                showImageEmpety();
            }
        } else {
            showImageEmpety();
        }
    }

    private void CheckVersion() {
        APIService apiService = APIClient.getClient().create(APIService.class);
        Call<MobileVersionCntrol> call = apiService.CheckVersion();
        call.enqueue(new Callback<MobileVersionCntrol>() {
            @Override
            public void onResponse(Call<MobileVersionCntrol> call, Response<MobileVersionCntrol> response) {
                if (response.isSuccessful() && response.body() != null) {

                    int LastPassengerVersion = Integer.parseInt(response.body().getStrLastPassengerVersion());
                    int MinValidPassengerVersion = Integer.parseInt(response.body().getStrMinValidPassengerVersion());
                    String text;

                    if (BuildConfig.VERSION_CODE < LastPassengerVersion) {

                        if (BuildConfig.VERSION_CODE < MinValidPassengerVersion) {
                            enumTypeVersion = EnumTypeVersion.MIN_VALID_VERSION;
                            text = "برای ادامه کار با برنامه میبایست از نسخه جدید استفاده کنید! آیا مایل به استفاده از نسخه جدید میباشید؟";
                        } else {
                            enumTypeVersion = EnumTypeVersion.LAST_VERSION;
                            text = "نسخه ای که استفاده میکنید قدیمی است، آیا مایل به استفاده از نسخه جدید میباشید؟";
                        }

                        FragmentManager manager = getSupportFragmentManager();
                        Fragment frag = manager.findFragmentByTag("DialogCheckVersion");
                        if (frag != null) {
                            manager.beginTransaction().remove(frag).commit();
                        }
                        DialogCheckVersion dialogConfirm = new DialogCheckVersion(text, enumTypeVersion
                                , new DialogCheckVersion.OnClickDialogFinalOrderRegister() {
                            @Override
                            public void onClick() {
                                Intent browserIntent = new Intent(Intent.ACTION_VIEW
                                        , Uri.parse(response.body().getStrPassengerPath()));
                                startActivity(browserIntent);
                            }

                            @Override
                            public void onCancel() {
                                if (enumTypeVersion == EnumTypeVersion.MIN_VALID_VERSION)
                                    exitApp();
                            }
                        });

                        dialogConfirm.show(manager, "DialogCheckVersion");

                    }
                } else {
//                    Toaster.shorter(context, getResources().getString(R.string.serverError));
                }
            }

            @Override
            public void onFailure(Call<MobileVersionCntrol> call, Throwable t) {
//                Toaster.shorter(context, getResources().getString(R.string.connectionError));
            }
        });
    }

    @SuppressLint("InlinedApi")
    private void checkAlertPermission() {
        Intent myIntent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION);
        startActivity(myIntent);
    }

    public void checkNightMode() {
        if (App.modeChanged) {
            App.modeChanged = false;
            ((Activity) context).finish();
            context.startActivity(new Intent(context, MainActivity.class).setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP));
//        }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        //        presenter.swipRefreshPressed();
        if (exit)
            exitApp();
        checkNightMode();
        // tvMenuName.setText(String.format("%s %s", App.userInfo.getStrName(), App.userInfo.getStrFamily()));
        viewLoaded();

        //CheckVersion();

        try {

            if (!Cache.getString("photo").equals("")) {
                String pic = Cache.getString("photo");
                if (!pic.equals("")) {
                    byte[] decodedString = Base64.decode(pic, Base64.DEFAULT);
                    Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
                    Glide.with(context).load(decodedByte).into(ivMenuProfilePicture);
                }
            } else
                ivMenuProfilePicture.setImageResource(R.drawable.ic_account3);

        } catch (Exception ignored) {
        }

       /* try {
            Picasso.get()
                    .load(App.userInfo.getImgLink())
                    .placeholder(R.drawable.ic_account3)// Place holder image from drawable folder
                    .error(R.drawable.ic_account3)
                    .memoryPolicy(MemoryPolicy.NO_CACHE, MemoryPolicy.NO_STORE)
                    .networkPolicy(NetworkPolicy.NO_CACHE)
                    .resize(110, 110)
                    .centerCrop()
                    .into(ivMenuProfilePicture);
        } catch (Exception ignored) {

        }*/

    }

    public void updateResult(int appVersion, int versionCodeMin) {
        try {
            currentVersion = context.getPackageManager().getPackageInfo(context.getPackageName(), 0).versionCode;
        } catch (PackageManager.NameNotFoundException e) {
        }

        if (currentVersion < versionCodeMin && App.userInfo.getDownloadLinkApp() != null) {
//            view.showStorageAccessDialog(App.updatResult);
            showForceUpdate();
        }
        //test forec update
//        if(currentVersion < 2 && App.userInfo.getDownloadLinkApp()!=null) {
//            view.showForceUpdate();
//        }

        else if (currentVersion < appVersion && App.userInfo.getDownloadLinkApp() != null) {
            showStorageAccessDialog();
//            view.showAvailableUpdate();
        }
    }

    public void checkUpdate() {
//        presenter.updateResult(App.user.getAppVersion());
        updateResult(App.userInfo.getVersionCode(), App.userInfo.getVersionCodeMin());
    }

    public void viewLoaded() {
//        context.startActivity(new Intent(context, SignatureActivity.class));
        checkUpdate();

//        model.loadCurrentTripList();
        if (App.currentTripSuccess) {
            loadCurrentTripList();
        } else if (App.listCurrentTrip.size() > 0) {
            for (int i = 0; App.listCurrentTrip.size() > i; i++) {
                if (App.listCurrentTrip.get(i).getTiTripStatus() == 7) {
                    context.startActivity(new Intent(context, SignatureActivity.class));
                    Log.i(TAG, "viewLoaded: SignatureActivity");
                }
            }
//            Model.DataLoaded();
            setAdapter();
            hideImageEmpety();

        } else if (App.listCurrentTrip.size() == 0)
            showImageEmpety();
    }

    private void bindViews() {

        ivMenuProfilePicture = findViewById(R.id.ivMenuProfilePicture);
        tvMenuName = findViewById(R.id.tvMenuName);
        nav_exit = findViewById(R.id.nav_exit);
        nav_tripManagementNew = findViewById(R.id.nav_tripManagementNew);
        nav_historyTrips = findViewById(R.id.nav_historyTrips);
        nav_tripDashboard = findViewById(R.id.nav_tripDashboard);
        nav_help = findViewById(R.id.nav_help);
        nav_about_peysepar = findViewById(R.id.nav_about_peysepar);
        nav_about = findViewById(R.id.nav_about);
        nav_news = findViewById(R.id.nav_news);


        relativeLayout2 = findViewById(R.id.relativeLayout2);
        toolbar = findViewById(R.id.toolbar_main);
        drawerLayout = findViewById(R.id.drawerLayout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawerLayout.setDrawerListener(toggle);
        toggle.syncState();
        swipeRefresh = findViewById(R.id.swipeRefreshCurrentTrip);
        img_noCurrentItem = findViewById(R.id.img_noCurrentItem);
        progressBar = findViewById(R.id.progressBar_main);
//        ivMenu = findViewById(R.id.ivMenu);
        //    navigationView = findViewById(R.id.navigationView);
        //     navHeader = navigationView.getHeaderView(0);
        //
        txt_domain = findViewById(R.id.txt_domain);
        tv_main_countTrips = findViewById(R.id.tv_main_countTrips);
        tv_main_distanceTrips = findViewById(R.id.tv_main_distanceTrips);
        tv_main_timeTrips = findViewById(R.id.tv_main_timeTrips);
        cv_main_trip_count = findViewById(R.id.cv_main_trip_count);
        cv_main_distance = findViewById(R.id.cv_main_distance);
        cv_main_time = findViewById(R.id.cv_main_time);

        // navigationView.setNavigationItemSelectedListener(this);

        txtDateHeadMain = findViewById(R.id.txtDateHeadMain);
        //

        fabInfo = findViewById(R.id.fabInfo);
        fabAdd = findViewById(R.id.fabAdd);

//initializing RecyclerView
        recyclerView = findViewById(R.id.rvCurrentTrip);
//        adapter=new CurrentTripAdapter(modelCurrentTrip,getApplicationContext());
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(context);
        recyclerView.setLayoutManager(layoutManager);

        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(@NotNull RecyclerView recyclerView, int dx, int dy) {
                if (dy > 0) {
                    fabAdd.hide();
                    fabInfo.hide();
                } else {
                    fabAdd.show();
                    fabInfo.show();
                }
            }
        });

        fabAdd.setOnClickListener(v -> {
//            showDialog();
            if (userInfo.getiSAndDBaseCurrentLoc() != 0)
                MyLocation.getLocation2(context);
            //context.startActivity(new Intent(context, AddTripActivity.class));
            fabADDpressed(userInfo);
            originLatLon = null;
            destinationLatLon = null;
            MapsForAddTripActivity.originSelectLocation = null;
            MapsForAddTripActivity.destintionSelectLocation = null;
            counter = 0;
//            BottomSheetSelect bottomSheetSelect = new BottomSheetSelect(new BottomSheetSelect.OnClickSheet() {
//                @Override
//                public void onClickNewTrip() {
//                    if (userInfo.getiSAndDBaseCurrentLoc() != 0)
//                        Location.getLocation2(context);
//                    fabADDpressed(userInfo);
//                    originLatLon = null;
//                    destinationLatLon = null;
//                    MapsForAddTripActivity.originSelectLocation = null;
//                    MapsForAddTripActivity.destintionSelectLocation = null;
//                    counter = 0;
//                }
//
//                @Override
//                public void onClickDataTrip() {
//                    showFabInfo();
//                }
//            });
//            bottomSheetSelect.show(getSupportFragmentManager(), "");

        });

        fabInfo.setOnClickListener(v -> showFabInfo());
    }

    public void fabADDpressed(UserInfo userInfo) {
        switch (App.mapMode) {
          /*  case 0:
                modeOfInsert = "Normal";
                context.startActivity(new Intent(context, AddTripActivity.class));
                break;
*/
            case 1:
                modeOfInsert = "Map";
                context.startActivity(new Intent(context, MapsForAddTripActivity.class));
                break;

            case 2:
//                BottomSheetNewTrip bottomSheetNewTrip = new BottomSheetNewTrip(new BottomSheetNewTrip.OnClickSheet() {
//                    @Override
//                    public void onClickNormal() {
//                        modeOfInsert = "Normal";
//                        InsertTripNormal();
//                    }
//
//                    @Override
//                    public void onClickMap() {
//                        if (ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.ACCESS_FINE_LOCATION)
//                                != PackageManager.PERMISSION_GRANTED
//                                && ContextCompat.checkSelfPermission(getApplicationContext()
//                                , Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
//
//                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
//                                requestPermission();
//                            }
//                        } else {
//                            modeOfInsert = "Map";
//                            InsertTripWithMap();
//                        }
//                    }
//                });
//                bottomSheetNewTrip.show(getSupportFragmentManager(), "");
                showDialog();
                break;

            case 0:
            case 3:
                modeOfInsert = "hybrid";
                InsertTripHybrid();
                break;

        }

//        context.startActivity(new Intent(context, AddTripActivity.class));

        // InsertDialog
//        view.showDialog();
    }

    private void showFabInfo() {
        BottomSheetFragment bottomFragment = new BottomSheetFragment();
        bottomFragment.show(getSupportFragmentManager(), bottomFragment.getTag());
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {

        menuItemSelected(item.getItemId());

        drawerLayout.closeDrawer(GravityCompat.START);

        return true;
    }

    public void menuItemSelected(int id) {

        if (id == R.id.nav_historyTrips)
            context.startActivity(new Intent(context, HistoryActivity.class));

        else if (id == R.id.nav_vehiclesManagment) {
            openApp(context, appName, packageName);
        } else if (id == R.id.nav_tripManagementNew)
            context.startActivity(new Intent(context, TripManagementNewActivity.class));

        else if (id == R.id.nav_about)
//            context.startActivity(new Intent(context, AboutActivity.class));
            context.startActivity(new Intent(context, AboutUsActivity.class));

        else if (id == R.id.nav_pass)
            context.startActivity(new Intent(context, ChangePasswordActivity.class));

        else if (id == R.id.nav_news)
            context.startActivity(new Intent(context, NewsActivity.class));

        else if (id == R.id.nav_tripDashboard)
            context.startActivity(new Intent(context, DashboardActivity.class));

        else if (id == R.id.nav_about_peysepar)
//            context.startActivity(new Intent(context, AboutPeyseparActivity.class));
            context.startActivity(new Intent(context, AboutPassengerApplicationActivity.class));

        else if (id == R.id.nav_help)
            context.startActivity(new Intent(context, HelpActivity.class));

        else if (id == R.id.nav_exit) {
            closeApp();
        }

//        else if (id == R.id.nav_feedback)
//            context.startActivity(new Intent(context, FeedbackActivity.class));

//        else if (id == R.id.nav_changeIP)
//            context.startActivity(new Intent(context, SettingActivity.class));

//        else if (id == R.id.nav_signature)
//            context.startActivity(new Intent(context, MapsActivity2.class));


//        else if (id == R.id.nav_share) {
//            context.startActivity(Intent.createChooser(new Intent(android.content.Intent.ACTION_SEND).setType("text/plain").
//                            putExtra(android.content.Intent.EXTRA_SUBJECT, context.getResources().getString(R.string.app_name_persian)).
//                            putExtra(android.content.Intent.EXTRA_TEXT,
//                                    context.getString(R.string.app_share_content) + "\n" +
//                                            context.getResources().getString(R.string.app_share_link))
//                    , context.getString(R.string.app_share_title)));
//        }
    }

    private void openApp(Context context, String appName, String packageName) {
        if (isAppInstalled(context, packageName))
            if (isAppEnabled(context, packageName))
                context.startActivity(context.getPackageManager().getLaunchIntentForPackage(packageName));
            else Toaster.shorter(appName + " app is not enabled.");
        else {
//            Intent promptInstall = new Intent(Intent.ACTION_VIEW)
//                    .setDataAndType(Uri.parse("content:///path/to/your.apk"),
//                            "application/vnd.android.package-archive");
//            context.startActivity(promptInstall);
            Toaster.shorter(appName + " app is not installed.");
        }
    }

    private boolean isAppEnabled(Context context, String packageName) {
        PackageManager pm = context.getPackageManager();
        try {
            pm.getPackageInfo(packageName, PackageManager.GET_ACTIVITIES);
            return true;
        } catch (PackageManager.NameNotFoundException ignored) {
        }
        return false;
    }

    private boolean isAppInstalled(Context context, String packageName) {
        boolean appStatus = false;
        try {
            ApplicationInfo ai = context.getPackageManager().getApplicationInfo(packageName, 0);
            if (ai != null) {
                appStatus = ai.enabled;
            }
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        return appStatus;
    }

    public void showStorageAccessDialog() {
        AlertDialog.Builder dialog1 = new AlertDialog.Builder(context);
        dialog1.setMessage("جهت به روز رسانی برنامه لازم است دسترسی به حافظه ذخیره سازی موبایل وجود داشته باشد");
        dialog1.setPositiveButton("تأیید", (dialog2, which) -> checkPermission1());
        dialog1.setCancelable(false);
        dialog1.show();
    }

    public void checkPermission1() {
        permissionResult(
                (ContextCompat.checkSelfPermission(App.context, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                        != PackageManager.PERMISSION_GRANTED) ? -1 : 1);
    }

    public void permissionResult(int result) {
        if (result == 1) {
            update();
        } else {
            showPermissionAlert();
        }
    }

    // showDialog
    public void showDialog() {
        final Dialog dialog = new Dialog(context, android.R.style.Theme_DeviceDefault_Light_Dialog_NoActionBar_MinWidth);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        Objects.requireNonNull(dialog.getWindow()).setBackgroundDrawableResource(android.R.color.transparent);
        dialog.setContentView(R.layout.insert_trip_dialog1);

        TextView txt_map_insertTrip = dialog.findViewById(R.id.txt_map_insertTrip);
        TextView txt_normal_insertTrip = dialog.findViewById(R.id.txt_normal_insertTrip);
        ImageView map_dialog = dialog.findViewById(R.id.map_dialog);
        ImageView normal_dialog = dialog.findViewById(R.id.normal_dialog);

        Typeface tf = Typeface.createFromAsset(getAssets(), "IRANSansMobile.ttf");
        txt_map_insertTrip.setTypeface(tf);
        txt_normal_insertTrip.setTypeface(tf);

        map_dialog.setOnClickListener(v -> {
            if (ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.ACCESS_FINE_LOCATION)
                    != PackageManager.PERMISSION_GRANTED
                    && ContextCompat.checkSelfPermission(getApplicationContext()
                    , Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    requestPermission();
                }
            } else {
                modeOfInsert = "Map";
                InsertTripWithMap();
                dialog.dismiss();
            }

        });
        txt_map_insertTrip.setOnClickListener(v -> {
            if (ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.ACCESS_FINE_LOCATION)
                    != PackageManager.PERMISSION_GRANTED
                    && ContextCompat.checkSelfPermission(getApplicationContext()
                    , Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    requestPermission();
                }
            } else {
                modeOfInsert = "Map";
                InsertTripWithMap();
                dialog.dismiss();
            }
        });

        txt_normal_insertTrip.setOnClickListener(v -> {
            modeOfInsert = "Normal";
            InsertTripNormal();
            dialog.dismiss();
        });

        normal_dialog.setOnClickListener(v -> {
            modeOfInsert = "Normal";
            InsertTripNormal();
            dialog.dismiss();
        });

        dialog.show();

    }

    public void InsertTripNormal() {
        context.startActivity(new Intent(context, AddTripWithMapActivity.class));
    }

    public void InsertTripHybrid() {
        context.startActivity(new Intent(context, AddTripWithMapActivity.class));
    }

    public void InsertTripWithMap() {
        context.startActivity(new Intent(context, MapsForAddTripActivity.class));
    }

    public void showAvailableUpdate() {
        AlertDialog.Builder dialog = new AlertDialog.Builder(context);
        dialog.setMessage(R.string.newUpdateAvailable);
        dialog.setPositiveButton(R.string.update, (dialog15, which) -> updateFromBazar());
//        dialog.setPositiveButton(R.string.update, (dialog15, which) -> showStorageAccessDialog());
        dialog.setNegativeButton(R.string.cancel, (dialog16, which) -> dialog16.dismiss());
        dialog.show();
    }

    public void updateFromBazar() {
        String url = "https://cafebazaar.ir/app/com.rayanandisheh.peysepar.customer";
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setData(Uri.parse(url));
        context.startActivity(i);
    }

    public void showForceUpdate() {

        AlertDialog.Builder dialog = new AlertDialog.Builder(context);
        dialog.setMessage(R.string.forceUpdateAvailable);
        dialog.setPositiveButton(R.string.update, (dialog1, which) -> showStorageAccessDialog());
        dialog.setNegativeButton(R.string.exit, (dialog12, which) -> exitApp());
        dialog.setCancelable(false);
        dialog.show();
    }

    public void showPermissionAlert() {
        AlertDialog.Builder dialog = new AlertDialog.Builder(context);
        dialog.setMessage(R.string.externalStorageAccess);
        dialog.setPositiveButton(R.string.accessPermission, (dialog13, which) -> requestPermission());
        dialog.setNegativeButton(R.string.cancel, (dialog14, which) -> dialog14.dismiss());
        dialog.show();
    }

    public void hideProgressBar() {
        progressBar.setVisibility(View.GONE);
    }

    public void setAdapter() {
        progressBar.setVisibility(View.GONE);
        adapter = new CurrentTripAdapter(App.listCurrentTrip, context);
        adapter.setModelFrCurrentTrip(App.listCurrentTrip);
        AlphaInAnimationAdapter alphaAdapter = new AlphaInAnimationAdapter(adapter);
        recyclerView.setAdapter(new ScaleInAnimationAdapter(alphaAdapter));
    }

    public void showProgressBar() {
//        progressBar.setVisibility(View.VISIBLE);
        swipeRefresh.setRefreshing(true);
    }

    public void showSwipeRefresh() {
        swipeRefresh.setRefreshing(true);
    }

    public void hideSwipeRefresh() {
        swipeRefresh.setRefreshing(false);
        progressBar.setVisibility(View.GONE);
    }

    public void showLayoutDashboard() {
        cv_main_trip_count.setVisibility(View.VISIBLE);
        cv_main_distance.setVisibility(View.VISIBLE);
        cv_main_time.setVisibility(View.VISIBLE);
        //hideImageEmpety();
    }

    public void hideLayoutDashboard() {
        cv_main_trip_count.setVisibility(View.GONE);
        cv_main_distance.setVisibility(View.GONE);
        cv_main_time.setVisibility(View.GONE);
    }

    public void showImageEmpety() {
        img_noCurrentItem.setVisibility(View.VISIBLE);
    }

    public void hideImageEmpety() {
        img_noCurrentItem.setVisibility(View.GONE);
    }

    public void hideRecyclerView() {
        recyclerView.setVisibility(View.GONE);
    }

    public void showRecyclerView() {
        recyclerView.setVisibility(View.VISIBLE);
    }

    public void closeApp() {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setMessage("مطمین هستید که از برنامه می خواهید خارج شوید؟");
        builder.setPositiveButton("بله", (dialog, which) -> {
//            Cache.setString("mobileNumber", "");
            Cache.removeString("mobileNumber");
            exitApp();
        });
        builder.setNegativeButton("خیر", (dialog, which) -> {
        });
        builder.create().show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1)
            update();

        if (requestCode == ACTION_MANAGE_OVERLAY_PERMISSION_REQUEST_CODE) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (!Settings.canDrawOverlays(this)) {
                    // You don't have permission
                    checkPermission();
                } else {
                    // Do as per your logic
                }
            }
        }
    }

    public void update() {
//        new DownloadManager().DownloadUpdateApp(context);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_option, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();
        if (id == R.id.menuOption) {
//            drawerLayout.openDrawer(Gravity.RIGHT);
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.close();
        } else {

            if (doubleBackToExitPressedOnce) {
                super.onBackPressed();
                exitApp();
                return;
            }

            this.doubleBackToExitPressedOnce = true;
            Toast.makeText(this, "برای خروج مجددا دکمه ی بازگشت را بزنید", Toast.LENGTH_SHORT).show();

            new Handler().postDelayed(new Runnable() {

                @Override
                public void run() {
                    doubleBackToExitPressedOnce = false;
                }
            }, 2000);
        }
    }

    /*---------- close all app---------*/
    private void exitApp() {
        finish();
        startActivity(new Intent(Intent.ACTION_MAIN).
                addCategory(Intent.CATEGORY_HOME).
                setFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            finishAndRemoveTask();
        }
        android.os.Process.killProcess(android.os.Process.myPid());
        super.finish();
    }

    public void checkPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!Settings.canDrawOverlays(this)) {
                Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                startActivityForResult(intent, ACTION_MANAGE_OVERLAY_PERMISSION_REQUEST_CODE);
            }
        }
    }

    private void requestPermission() {
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 2);
    }

    private void gotoPermissionSetting() {
        context.startActivity(new Intent().setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                .setData(Uri.fromParts("package", activity.getPackageName(), null)));
    }

    @SuppressLint("NewApi")
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String permissions[], @NonNull int[] grantResults) {
        if (requestCode == 2) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {

            } else
                new AlertDialog.Builder(context)
                        .setTitle("عدم اجازه دسترسی")
                        .setMessage(R.string.accessDeniedMessage2)
                        .setPositiveButton("ورود به تنظیمات", (dialog, which) ->
                                gotoPermissionSetting()).create().show();
        }
    }

    public static class Helper {
        public static boolean isAppRunning(final Context context, final String packageName) {
            final ActivityManager activityManager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
            final List<ActivityManager.RunningAppProcessInfo> procInfos = activityManager.getRunningAppProcesses();
            if (procInfos != null) {
                for (final ActivityManager.RunningAppProcessInfo processInfo : procInfos) {
                    if (processInfo.processName.equals(packageName)) {
                        return true;
                    }
                }
            }
            return false;
        }
    }

}