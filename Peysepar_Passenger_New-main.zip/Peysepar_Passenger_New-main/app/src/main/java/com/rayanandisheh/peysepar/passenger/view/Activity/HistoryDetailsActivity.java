package com.rayanandisheh.peysepar.passenger.view.Activity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.rayanandisheh.peysepar.passenger.R;
import com.rayanandisheh.peysepar.passenger.helpers.App;
import com.rayanandisheh.peysepar.passenger.helpers.PersianAppcompatActivity;
import com.rayanandisheh.peysepar.passenger.helpers.Time;
import com.rayanandisheh.peysepar.passenger.helpers.Toaster;
import com.rayanandisheh.peysepar.passenger.models.Car;
import com.rayanandisheh.peysepar.passenger.models.Data;
import com.rayanandisheh.peysepar.passenger.models.Trip;
import com.rayanandisheh.peysepar.passenger.services.APIClient;
import com.rayanandisheh.peysepar.passenger.services.APIService;
import com.rayanandisheh.peysepar.passenger.utils.MyClass;

import org.jetbrains.annotations.NotNull;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class HistoryDetailsActivity extends PersianAppcompatActivity {
    private static final String TAG = "HistoryDetailsActivity";
    Context context;
    TextView txtImportance_historyDtls, txtPersuadeCode_HistoryTripDtls, txtTripStatus_historyDtls, txtRequestDate_Time_historyDtls, txtPassengerNames_HistoryTripDtls,
            txtSupposedDate_Time_historyDtls, txtOriginName_HistoryTripDtls, txtDesName_HistoryTripDtls, txtReasonImportance_historyDtls,
            txtVehicleType_HistoryTripDtls,  txtComment_historyDtls, txtDriverName_HistoryTripDtls,
            txtCarModel_historyDtls, txtStartTripTime_historyDtls, txtFinishTripDateTime_historyDtls, txtTripDurationTime_historyDtls,
            txt1_NPlate_historyDtls, txt2_NPlate_historyDtls, txt3_NPlate_historyDtls,txt_colorCar, txt4_NPlate_historyDtls, txtTripType_historyDtls;
    TextView txtTripKilometer, txtTripTime;

    RatingBar rateNotToday_HistoryTripDtls, rateToday_historyDetails;
    RelativeLayout rlScoreNotToday, rlScoreToday, rlTripType;
    private FloatingActionButton fb_mapRoting;

    public static Trip model = new Trip();

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history_details1);
        context = this;
        bindView();
        //getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        txtImportance_historyDtls.setText(model.getStrTripImportance_strComment());
        txt_colorCar.setText(model.getStrColor());
        txtPersuadeCode_HistoryTripDtls.setText(String.valueOf(model.getiOfficialTrip()));
        txtTripStatus_historyDtls.setText(model.getStrOfficialStatus_strComment());
        txtRequestDate_Time_historyDtls.setText(model.getStrRequestTime().trim() + "  -  " + model.getStrRequestDate());
        txtPassengerNames_HistoryTripDtls.setText(model.getStrPassengers());
        txtSupposedDate_Time_historyDtls.setText(model.getStrTripTime() + "  -  " + model.getStrTripDate());
        txtOriginName_HistoryTripDtls.setText(model.getStrOriginAddress());
        txtDesName_HistoryTripDtls.setText(model.getStrDestinationAddress());
        txtReasonImportance_historyDtls.setText(model.getStrTripReason_strComment());
        txtVehicleType_HistoryTripDtls.setText(model.getStrMobileType());
        txtTripKilometer.setText(String.valueOf(model.getfTripKm()));
        txtTripTime.setText(model.getStrTripTime());

        if (model.isbExclusive() || model.isbHaveReturn() || model.isbMission()) {
            rlTripType.setVisibility(View.VISIBLE);
        } else
            rlTripType.setVisibility(View.GONE);

        if (model.isbHaveReturn())
            txtTripType_historyDtls.setText("دارای برگشت");
        else if (model.isbExclusive())
            txtTripType_historyDtls.setText("در اختیار");
        else if (model.isbMission())
            txtTripType_historyDtls.setText("ماموریتی");

        if (model.getStrComment().length() != 0)
            txtComment_historyDtls.setText(model.getStrComment());
        else
            txtComment_historyDtls.setText("-");

        txtDriverName_HistoryTripDtls.setText(model.getStrDriverName());

        txtCarModel_historyDtls.setText(model.getStrMobileType());
        txtStartTripTime_historyDtls.setText(model.getStrTripTime());

        if (model.getStrTrimpFinishTime() != null && model.getStrFinishDate() != null) {
            txtFinishTripDateTime_historyDtls.setText(model.getStrTrimpFinishTime() + " - " + model.getStrFinishDate());
        }

        if (model.getStrTrimTimeEstimate() != null)
            txtTripDurationTime_historyDtls.setText(Time.minutesToHours(model.getStrTrimTimeEstimate()));
        else
            txtTripDurationTime_historyDtls.setText("-");

        //numberPlate
        String numberPlate = model.getStrVehicleNo();

        if (numberPlate != null) {
            txt1_NPlate_historyDtls.setText(numberPlate.substring(0, 2));
            txt2_NPlate_historyDtls.setText(numberPlate.substring(3, 4));
            txt3_NPlate_historyDtls.setText(numberPlate.substring(5, 8));
            txt4_NPlate_historyDtls.setText(numberPlate.substring(11));
        }else{
            txt1_NPlate_historyDtls.setText("-");
            txt2_NPlate_historyDtls.setText("-");
            txt3_NPlate_historyDtls.setText("-");
            txt4_NPlate_historyDtls.setText("-");
        }

        rateNotToday_HistoryTripDtls.setRating(model.getiSatisfication() / 20);

        switch (model.getStrTripImportance_strComment()) {
            case "عادی":
                txtImportance_historyDtls.setBackground(ContextCompat.getDrawable(context, R.drawable.shape_circle_normal));
                txtImportance_historyDtls.setTextColor(context.getResources().getColor(R.color.colorText));
                break;
            case "فوری":
                txtImportance_historyDtls.setBackground(ContextCompat.getDrawable(context, R.drawable.shape_circle_urgent));
                txtImportance_historyDtls.setTextColor(context.getResources().getColor(R.color.colorOrenge));
                break;
            case "خیلی فوری":
                txtImportance_historyDtls.setBackground(ContextCompat.getDrawable(context, R.drawable.shape_circle_very_urgent));
                txtImportance_historyDtls.setTextColor(context.getResources().getColor(R.color.colorPink));
                break;
        }
    }

    private void bindView() {
        txtImportance_historyDtls = findViewById(R.id.txtImportance_historyDtls);
        txt_colorCar = findViewById(R.id.txt_colorCar);
        txtPersuadeCode_HistoryTripDtls = findViewById(R.id.txtPersuadeCode_HistoryTripDtls);
        txtTripStatus_historyDtls = findViewById(R.id.txtTripStatus_historyDtls);
        txtRequestDate_Time_historyDtls = findViewById(R.id.txtRequestDate_Time_historyDtls);
        txtPassengerNames_HistoryTripDtls = findViewById(R.id.txtPassengerNames_HistoryTripDtls);
        txtSupposedDate_Time_historyDtls = findViewById(R.id.txtSupposedDate_Time_historyDtls);
        txtOriginName_HistoryTripDtls = findViewById(R.id.txtOriginName_HistoryTripDtls);
        txtDesName_HistoryTripDtls = findViewById(R.id.txtDesName_HistoryTripDtls);
        txtReasonImportance_historyDtls = findViewById(R.id.txtReasonImportance_historyDtls);
        txtVehicleType_HistoryTripDtls = findViewById(R.id.txtVehicleType_HistoryTripDtls);

        txtTripType_historyDtls = findViewById(R.id.txtTripType_historyDtls);

        txtComment_historyDtls = findViewById(R.id.txtComment_historyDtls);
        txtDriverName_HistoryTripDtls = findViewById(R.id.txtDriverName_HistoryTripDtls);
        txtCarModel_historyDtls = findViewById(R.id.txtCarModel_historyDtls);
        txtStartTripTime_historyDtls = findViewById(R.id.txtStartTripTime_historyDtls);
        txtFinishTripDateTime_historyDtls = findViewById(R.id.txtFinishTripDateTime_historyDtls);
        txtTripDurationTime_historyDtls = findViewById(R.id.txtTripDurationTime_historyDtls);
        txt1_NPlate_historyDtls = findViewById(R.id.txt1_NPlate_historyDtls);
        txt2_NPlate_historyDtls = findViewById(R.id.txt2_NPlate_historyDtls);
        txt3_NPlate_historyDtls = findViewById(R.id.txt3_NPlate_historyDtls);
        txt4_NPlate_historyDtls = findViewById(R.id.txt4_NPlate_historyDtls);
        rateNotToday_HistoryTripDtls = findViewById(R.id.rateNotToday_historyDetails);
        rlScoreNotToday = findViewById(R.id.rlScoreNotToday);
        rlScoreToday = findViewById(R.id.rlScoreToday);
        rlTripType = findViewById(R.id.rlTripType);
        fb_mapRoting = findViewById(R.id.fb_mapRoting);
        txtTripKilometer = findViewById(R.id.txtTripKilometer);
        txtTripTime = findViewById(R.id.txtTripTime);

        fb_mapRoting.setOnClickListener(v -> {
            Intent intent = new Intent(getApplicationContext(), ActivityMap.class);
            intent.putExtra("iOfficialTrip", model.getiOfficialTrip());
            startActivity(intent);

        });
    }

    private void RequestcarLocation(final Context context) {
        APIService apiService = APIClient.getClient().create(APIService.class);
        Call<List<Car>> call = apiService.GetTripPath(App.iOfficialTrip);
        call.enqueue(new Callback<List<Car>>() {
            @Override
            public void onResponse(@NonNull Call<List<Car>> call, @NonNull Response<List<Car>> response) {
                if (response.code() == 200) {
                    App.listHistoryTrip.clear();
                    List<Car> listCar = response.body();//Car car = response.body();

                    if (listCar == null || listCar.size() < 1){
                        MyClass.ToastM(context, "موردی یافت نشد");
//                        App.listCarLocation = listCarLocation;
                        Intent i = new Intent(context, ActivityMap.class);
                        context.startActivity(i);
                    }

                } else {
                    MyClass.ToastM(context, "خطا در برقراری ارتباط");
                }
            }

            @Override
            public void onFailure(@NonNull Call<List<Car>> call, @NonNull Throwable t) {
                MyClass.ToastM(context, "خطا در برقراری ارتباط");
            }
        });
    }

    public void showProgressBar() {
//        pb_rateTodayHistoryDetail.setVisibility(View.VISIBLE);
//        btn_rateTodayHistoryDetail.setVisibility(View.GONE);
    }

    public void hideProgressBar() {
//        pb_rateTodayHistoryDetail.setVisibility(View.GONE);
//        btn_rateTodayHistoryDetail.setVisibility(View.VISIBLE);
    }

    public void requestSendTodayRating(float rating, int iOfficialTrip) {

        App.score.setIofficialtrip(iOfficialTrip);
        App.score.setFscore(rating * 20);

        APIService apiService = APIClient.getClient().create(APIService.class);
        Call<Data> call = apiService.ChangeScore(App.score);
        call.enqueue(new Callback<Data>() {
            @Override
            public void onResponse(@NotNull Call<Data> call, @NotNull Response<Data> response) {
                if (response.code() == 200) {
                    App.data = response.body();
                    changeScoreResult(1);
                } else {
                    changeScoreResult(-4);
                }
            }

            @Override
            public void onFailure(Call<Data> call, Throwable t) {
                changeScoreResult(-5);
            }
        });
    }

    public void sendRate(float rating, int iOfficialTrip) {
        showProgressBar();
        requestSendTodayRating(rating, iOfficialTrip);
    }

    public void changeScoreResult(int result) {
        hideProgressBar();
        if (result == -4) {
            Toaster.shorter(context.getString(R.string.serverFaield));
        } else if (result == -5) {
            Toaster.shorter(context.getString(R.string.connectionFaield));
        } else if (result == 1) {
//            Toaster.shorter("امتیاز شما ثبت گردید");
            Toaster.shorter(App.data.getMessage());

        } else if (result == -1) {
//            Toaster.shorter("امتیاز شما ثبت گردید");
            Toaster.shorter(App.data.getMessage());

//           view.setTodayScore();
        }
    }
}