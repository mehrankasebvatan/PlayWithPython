package com.rayanandisheh.peysepar.passenger.view.fragment;


import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import com.rayanandisheh.peysepar.passenger.R;
import com.rayanandisheh.peysepar.passenger.helpers.App;
import com.rayanandisheh.peysepar.passenger.helpers.Time;
import com.rayanandisheh.peysepar.passenger.helpers.Toaster;
import com.rayanandisheh.peysepar.passenger.models.Trip;
import com.rayanandisheh.peysepar.passenger.services.APIClient;
import com.rayanandisheh.peysepar.passenger.services.APIService;
import com.rayanandisheh.peysepar.passenger.view.Activity.LoginActivity;
import com.rayanandisheh.peysepar.passenger.view.Activity.TripManagementNewActivity;
import com.rayanandisheh.peysepar.passenger.view.Adapter.TripConfirmedFragmentAdapter;

import java.util.List;

import jp.wasabeef.recyclerview.adapters.AlphaInAnimationAdapter;
import jp.wasabeef.recyclerview.adapters.ScaleInAnimationAdapter;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


/**
 * A simple {@link Fragment} subclass.
 */
public class TripConfirmedFragment extends Fragment {
    Context context;

    ProgressBar progressBar;
    RecyclerView recyclerView;
    SwipeRefreshLayout swp_refresh;
    TripConfirmedFragmentAdapter adapter;
    ImageView img_noItem;

    public TripConfirmedFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_trip_confirmed, container, false);
        context = getContext();

        bindView(view);

        viewLoaded();
        swp_refresh.setOnRefreshListener(() -> swpRefreshPressed());
        return view;
    }

    private void bindView(View view) {

        recyclerView=view.findViewById(R.id.rv_confirmedFragment);
        progressBar=view.findViewById(R.id.progressBarConfirmedTabLayout);
        img_noItem=view.findViewById(R.id.img_noIconConfirmedTripTabLayout);
        swp_refresh=view.findViewById(R.id.swp_TripConfirmedFragment);
    }

    public void hideImg_noItem() {
        img_noItem.setVisibility(View.GONE);
    }

    public void showImg_noItem() {
        img_noItem.setVisibility(View.VISIBLE);
    }

    public void showSwipeRefresh() {
      swp_refresh.setRefreshing(true);
    }

    public void hideSwipeRefresh() {
        swp_refresh.setRefreshing(false);
    }

    public void setAdapter() {
        adapter = new TripConfirmedFragmentAdapter(App.listConfirmedTripTabLayout, context, iOfficialTrip -> {
                cancelConfirmedTripAlertTabLayoutTripManagement(iOfficialTrip);
        });
        recyclerView.setLayoutManager(new LinearLayoutManager(context));
        AlphaInAnimationAdapter alphaAdapter = new AlphaInAnimationAdapter(adapter);
        recyclerView.setAdapter(new ScaleInAnimationAdapter(alphaAdapter));
    }

    @Override
    public void onResume() {
        super.onResume();
        swpRefreshPressed();
    }

    //to solve the problem of not refreshing the neighbour tabs
    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        if (isVisibleToUser) {
            swpRefreshPressed();
        } else {

        }
    }

    public void requesrListConfimedTripTabLayout() {

        if(App.dateFromTripManagement.equals("") && App.dateToTripManagement.equals("")){
            App.userInfo.setDateFrom(Time.getNowPersianDate());
            App.userInfo.setDateTo(Time.getNowPersianDate());
        }else if(!App.dateFromTripManagement.equals("") && !App.dateToTripManagement.equals("")){
            App.userInfo.setDateFrom(App.dateFromTripManagement);
            App.userInfo.setDateTo(App.dateToTripManagement);
        }else if(!App.dateFromTripManagement.equals("") && App.dateToTripManagement.equals("")){
            App.userInfo.setDateFrom(App.dateFromTripManagement);
            App.userInfo.setDateTo(Time.getNowPersianDate());
        }else if(App.dateFromTripManagement.equals("") && !App.dateToTripManagement.equals("")){
            App.userInfo.setDateFrom(Time.getNowPersianDate());
            App.userInfo.setDateTo(App.dateToTripManagement);
        }

        App.userInfo.setType(3);

        APIService apiService= APIClient.getClient().create(APIService.class);
        Call<List<Trip>> call= apiService.manageTrip(App.userInfo,App.Session);
        call.enqueue(new Callback<List<Trip>>() {
            @Override
            public void onResponse(Call<List<Trip>> call, Response<List<Trip>> response) {
                if(response.code()==200){
                    App.confirmedTripTabLayoutListSuccess=false;

                    App.listConfirmedTripTabLayout= response.body();
                    if(App.listConfirmedTripTabLayout != null){
                        loadDataResult(1);
                    }else{
                        loadDataResult(0);
                    }
                }else{
                    loadDataResult(-4);
                }
            }

            @Override
            public void onFailure(Call<List<Trip>> call, Throwable t) {
                loadDataResult(-5);
            }
        });
    }

    public void requestCancelConfirmedTripAlertTabLayout(int iOfficialTrip) {
        Trip trip=new Trip();
        trip.setiOfficialTrip(iOfficialTrip);

        APIService apiService=APIClient.getClient().create(APIService.class);
        Call<Integer> call=apiService.cancelTrip(trip, "",App.Session);

        call.enqueue(new Callback<Integer>() {
            @Override
            public void onResponse(Call<Integer> call, Response<Integer> response) {
                if(response.code()==200){
                    cencelAlertResult(response.body());
                }else{
                    cencelAlertResult(-4);
                }
            }

            @Override
            public void onFailure(Call<Integer> call, Throwable t) {
                cencelAlertResult((-5));
            }
        });
    }

    public void viewLoaded() {

        if (App.confirmedTripTabLayoutListSuccess) {
            showSwipeRefresh();
            requesrListConfimedTripTabLayout();

        } else if (App.listConfirmedTripTabLayout.size() > 0) {
//            view.setAdapter();
            hideImg_noItem();
        } else if(App.listConfirmedTripTabLayout.size()==0){
            showImg_noItem();
        }
    }

    public void swpRefreshPressed() {
        showSwipeRefresh();
        requesrListConfimedTripTabLayout();
    }

    public void loadDataResult(int result) {
        hideSwipeRefresh();
        if (result == -4)
            Toaster.shorter(context.getString(R.string.serverFaield));
        else if (result == -5)
            Toaster.shorter(context.getString(R.string.connectionFaield));
        else if(result==0)
            showImg_noItem();
        else if(result==1){
            setAdapter();
            hideImg_noItem();
            if(App.listConfirmedTripTabLayout.size()>0)
                hideImg_noItem();
            else
                showImg_noItem();
        }else if(result==100){
            Intent intent = new Intent(getActivity(), LoginActivity.class);
            startActivity(intent);
        }
    }

    public void cancelConfirmedTripAlertTabLayoutTripManagement(int iOfficialTrip) {
       showSwipeRefresh();
        requestCancelConfirmedTripAlertTabLayout(iOfficialTrip);
    }

    public void cencelAlertResult(int result) {
        hideSwipeRefresh();
        if (result == -4) {
            Toaster.shorter(context.getString(R.string.serverFaield));
        } else if (result == -5) {
            Toaster.shorter(context.getString(R.string.connectionFaield));
        } else if (result == 100) {
            Intent intent=new Intent(getActivity(), LoginActivity.class);
            startActivity(intent);

        }else{
            Toaster.shorter("سفر شما با موفقیت لغو گردید");
            //to update list
            requesrListConfimedTripTabLayout();
        }
    }

}
