package com.rayanandisheh.peysepar.passenger.view.Activity;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;

import com.rayanandisheh.peysepar.passenger.BuildConfig;
import com.rayanandisheh.peysepar.passenger.R;
import com.rayanandisheh.peysepar.passenger.customes.mAppCompatActivity;
import com.rayanandisheh.peysepar.passenger.helpers.App;
import com.rayanandisheh.peysepar.passenger.helpers.Cache;
import com.rayanandisheh.peysepar.passenger.helpers.DeviceInfo;
import com.rayanandisheh.peysepar.passenger.helpers.Toaster;
import com.rayanandisheh.peysepar.passenger.helpers.Validate;
import com.rayanandisheh.peysepar.passenger.models.Register;
import com.rayanandisheh.peysepar.passenger.models.UserInfo;
import com.rayanandisheh.peysepar.passenger.models.WhatsUpRequest;
import com.rayanandisheh.peysepar.passenger.models.WhatsUpResponse;
import com.rayanandisheh.peysepar.passenger.services.APIClient;
import com.rayanandisheh.peysepar.passenger.services.APIService;
import com.rayanandisheh.peysepar.passenger.utils.SmsReceiver;
import com.rayanandisheh.peysepar.passenger.view.dialog.WhatsUpDialog;

import org.jetbrains.annotations.NotNull;

import java.text.MessageFormat;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ActivationActivity extends mAppCompatActivity {
    private static final String TAG = "ActivationActivity";
    Context context = this;
    EditText etValidateCode, etFormerMobilePhone;
    Button btValidate, btnGotoRegisterDifferentIMEI, btValidateDifferentIMEI;
    ProgressBar pbValidate, pbValidateDifferentIMEI;
    TextView tvRequestValidationCodeAgain, tvSendValidationCodeAgainLoading;
    ImageView ivWarningActvationCode, ivWarningFormerMobilePhone;
    RelativeLayout rlStaticright, rlSameIMEI_MOBILE;
    LinearLayout llFormerMobilePhoneDiffrentIMEI, rlDifferentIMEI;
    String IMEI = "";
    int currentVersion = 0;
    private SmsReceiver smsReceiver = new SmsReceiver(new SmsReceiver.OnSmsReceivedListener() {
        @Override
        public void onSmsReceived(String code) {
            if (code == null) {
                etValidateCode.setError("لطفا کد تایید را وارد نمایید");
                etValidateCode.setText(code);
            } else {
                etValidateCode.setText(code);
            }
        }
    });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_activation);

        bindViews();
        //getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        if (!Cache.getString("mobileNumber").equals("")) {
            etFormerMobilePhone.setText(Cache.getString("mobileNumber"));
        } else {
            if (!App.periviousMobileNum.isEmpty())
                etFormerMobilePhone.setText(App.periviousMobileNum);
            else
                etFormerMobilePhone.setText("");
        }

        if (App.diffrentIMEI) {
            rlStaticright.setVisibility(View.GONE);
            btValidateDifferentIMEI.setText("تغییر شماره");
            llFormerMobilePhoneDiffrentIMEI.setVisibility(View.VISIBLE);
            rlDifferentIMEI.setVisibility(View.VISIBLE);
            rlSameIMEI_MOBILE.setVisibility(View.GONE);

        } else {
            llFormerMobilePhoneDiffrentIMEI.setVisibility(View.GONE);
            rlDifferentIMEI.setVisibility(View.GONE);
            rlSameIMEI_MOBILE.setVisibility(View.VISIBLE);
        }

        btnGotoRegisterDifferentIMEI.setOnClickListener(v ->
                btnGotoRegisterDifferentIMEI_Pressed(etFormerMobilePhone.getText().toString()));

        /*----------------------------------------------------------------------------------------*/
        etValidateCode.setOnKeyListener((v, keyCode, event) -> {
            if (event.getAction() == KeyEvent.ACTION_DOWN) {
                switch (keyCode) {
                    case KeyEvent.KEYCODE_DPAD_CENTER:
                    case KeyEvent.KEYCODE_ENTER:
                        btValidateDifferentIMEI_Pressed(etValidateCode.getText().toString()
                                , etFormerMobilePhone.getText().toString());
                        return true;
                    default:
                        break;
                }
            }
            return false;
        });

        etFormerMobilePhone.setOnKeyListener((v, keyCode, event) -> {
            if (event.getAction() == KeyEvent.ACTION_DOWN) {
                switch (keyCode) {
                    case KeyEvent.KEYCODE_DPAD_CENTER:
                    case KeyEvent.KEYCODE_ENTER:
                        btValidateDifferentIMEI_Pressed(etValidateCode.getText().toString()
                                , etFormerMobilePhone.getText().toString());
                        return true;
                    default:
                        break;
                }
            }
            return false;
        });

        /*----------------------------------------------------------------------------------------*/

        btValidate.setOnClickListener(v -> btValidatePressed(etValidateCode.getText().toString()));

        btValidateDifferentIMEI.setOnClickListener(v -> btValidateDifferentIMEI_Pressed(etValidateCode.getText().toString()
                , etFormerMobilePhone.getText().toString()));

        etValidateCode.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.length() < 3)
                    ivWarningActvationCode.setVisibility(View.VISIBLE);
                else
                    ivWarningActvationCode.setVisibility(View.GONE);
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });


        etFormerMobilePhone.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.length() != 11)
                    ivWarningFormerMobilePhone.setVisibility(View.GONE);
                else
                    ivWarningFormerMobilePhone.setVisibility(View.GONE);
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

    }

    @SuppressLint("WrongViewCast")
    private void bindViews() {

        btValidate = findViewById(R.id.btValidate);
        pbValidate = findViewById(R.id.pbValidate);
        etValidateCode = findViewById(R.id.etValidateCode);
        tvRequestValidationCodeAgain = findViewById(R.id.tvRequestValidationCodeAgain);
        tvSendValidationCodeAgainLoading = findViewById(R.id.tvSendValidationCodeAgainLoading);

        llFormerMobilePhoneDiffrentIMEI = findViewById(R.id.llFormerMobilePhoneDiffrentIMEI);
        ivWarningFormerMobilePhone = findViewById(R.id.ivWarningFormerMobilePhone);
        etFormerMobilePhone = findViewById(R.id.etFormerMobilePhone);
        rlDifferentIMEI = findViewById(R.id.rlDifferentIMEI);
        rlStaticright = findViewById(R.id.rlRegister);
        btnGotoRegisterDifferentIMEI = findViewById(R.id.btnGotoRegisterDifferentIMEI);
        btValidateDifferentIMEI = findViewById(R.id.btValidateDifferentIMEI);
        pbValidateDifferentIMEI = findViewById(R.id.pbValidateDifferentIMEI);
        rlSameIMEI_MOBILE = findViewById(R.id.rlSameIMEI_MOBILE);
        ivWarningActvationCode = findViewById(R.id.ivWarningActvationCode);
        tvRequestValidationCodeAgain.setOnClickListener(v -> sendAgainPressed());

    }

    public void startSendCodeAgainLoading() {
        new CountDownTimer(60000, 1000) {
            public void onTick(long millisUntilFinished) {
                tvRequestValidationCodeAgain.setVisibility(View.GONE);
                tvSendValidationCodeAgainLoading.setVisibility(View.VISIBLE);
                tvSendValidationCodeAgainLoading.setText(MessageFormat.format("{0} {1} {2}", getString(R.string.after), millisUntilFinished / 1000, getString(R.string.secends)));
            }

            public void onFinish() {
                sendCodeAgainLoadTimeFinished();
            }
        }.start();
    }

    public void stopSendCodeAgainLoading() {
        tvRequestValidationCodeAgain.setVisibility(View.VISIBLE);
        tvSendValidationCodeAgainLoading.setVisibility(View.GONE);
    }

    public void startValidateLoading() {
        pbValidate.setVisibility(View.VISIBLE);
        btValidate.setVisibility(View.GONE);
    }

    public void stopValidateLoading() {
        pbValidate.setVisibility(View.GONE);
        btValidate.setVisibility(View.VISIBLE);
    }

    public void showActivationCodeError(String string) {
        etValidateCode.setError(string);
        etValidateCode.requestFocus();
    }

    public void showPbDiffrentIMEI() {
        pbValidateDifferentIMEI.setVisibility(View.VISIBLE);
        btValidateDifferentIMEI.setVisibility(View.GONE);
    }

    public void stopPbValidateDifferentIMEI() {
        pbValidateDifferentIMEI.setVisibility(View.GONE);
        btValidateDifferentIMEI.setVisibility(View.VISIBLE);
    }

    @SuppressLint({"HardwareIds", "MissingPermission"})
    public String getDeviceIMEI() {

        String deviceUniqueIdentifier = null;
        TelephonyManager tm = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
        if (null != tm) {
//            if (ActivityCompat.checkSelfPermission(context, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED)
            if (ActivityCompat.checkSelfPermission(context, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED)

                ActivityCompat.requestPermissions((Activity) context, new String[]{Manifest.permission.READ_PHONE_STATE}, 3);
            else
                deviceUniqueIdentifier = tm.getDeviceId();
            if (null == deviceUniqueIdentifier || 0 == deviceUniqueIdentifier.length())
                deviceUniqueIdentifier = "0";
        }
        return deviceUniqueIdentifier;
    }

    @SuppressLint("HardwareIds")
    public void validate(String validationCode) {
        Register register = new Register();

        if (App.register.getStrMobile().length() > 0)
            register.setStrMobile(App.register.getStrMobile());
        else if (Cache.getString("mobileNumber").length() > 0) register.setStrMobile(Cache.getString("mobileNumber"));
        else {
            Toast.makeText(context, "شماره موبایل یافت نشد", Toast.LENGTH_SHORT).show();
        }

        Log.d(TAG, "validate: " + App.register.getStrMobile());

        if (Build.VERSION.SDK_INT > 28) {
            IMEI = Settings.Secure.getString(context.getContentResolver(),
                    Settings.Secure.ANDROID_ID);
            register.setStrIMEI(IMEI);
        } else
            register.setStrIMEI(DeviceInfo.getDeviceIMEI(context));
        register.setStrActivateCode(validationCode);
        register.setStrToken(Cache.getString("FirebaseToken"));

        APIService apiService = APIClient.getClient().create(APIService.class);
        Call<UserInfo> call = apiService.Activate(register);
        call.enqueue(new Callback<UserInfo>() {
            @Override
            public void onResponse(@NonNull Call<UserInfo> call, @NonNull Response<UserInfo> response) {
                if (response.code() == 200 && response.body() != null) {
                    App.userInfo = response.body();
                    Log.d(TAG, "onResponse: ");
                    validateResult(response.body().getResult());
                } else
                    validateResult(-4);
            }

            @Override
            public void onFailure(@NonNull Call<UserInfo> call, @NonNull Throwable t) {
                validateResult(-5);
            }
        });
    }

    @SuppressLint("HardwareIds")
    public void validateDiffrentIMEI(String smsCode, String formerMobilePhone) {
        App.replace.setStrActivateCode(smsCode);
        App.replace.setStrMobile1(formerMobilePhone);
        App.replace.setStrMobile2(App.mobileFirstRunning);
        if (Build.VERSION.SDK_INT > 28) {
            IMEI = Settings.Secure.getString(context.getContentResolver(),
                    Settings.Secure.ANDROID_ID);
            App.replace.setStrIMEI(IMEI);
        } else
            App.replace.setStrIMEI(DeviceInfo.getDeviceIMEI(context));

        APIService apiService = APIClient.getClient().create(APIService.class);
        Call<UserInfo> call = apiService.Replacement(App.replace);
        call.enqueue(new Callback<UserInfo>() {
            @Override
            public void onResponse(@NotNull Call<UserInfo> call, @NotNull Response<UserInfo> response) {
                if (response.code() == 200 && response.body() != null) {
                    App.userInfo = response.body();
                    validateDiffrentIMEIResult(response.body().getResult());
                } else {
                    validateDiffrentIMEIResult(-4);
                }
            }

            @Override
            public void onFailure(@NotNull Call<UserInfo> call, @NotNull Throwable t) {
                validateDiffrentIMEIResult(-5);
            }
        });
    }

    @SuppressLint("HardwareIds")
    public void loginBackground() {

        Register register = new Register();

        if (App.register.getStrMobile().length() > 0)
            register.setStrMobile(App.register.getStrMobile());
        else if (Cache.getString("mobileNumber").length() > 0) register.setStrMobile(Cache.getString("mobileNumber"));
        else {
            Toast.makeText(context, "شماره موبایل یافت نشد", Toast.LENGTH_SHORT).show();
        }

      //  register.setStrMobile(App.mobileFirstRunning);
      //  register.setStrMobile(Cache.getString("mobileNumber"));
//        register.setStrIMEI(Cache.getString("IMEI"));
        if (Build.VERSION.SDK_INT > 28) {
            IMEI = Settings.Secure.getString(context.getContentResolver(),
                    Settings.Secure.ANDROID_ID);
            register.setStrIMEI(IMEI);
        } else
            register.setStrIMEI(getDeviceIMEI());
        register.setStrToken(Cache.getString("FirebaseToken"));


        PackageInfo pinfo = null;
        try {
            pinfo = context.getPackageManager().getPackageInfo(context.getPackageName(), 0);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        assert pinfo != null;
        register.setVersionCode(pinfo.versionCode);
        request(register);
    }

    public void cacheMobilePhone() {
        Cache.setString("mobileNumber", App.register.getStrMobile());
    }

    private void request(Register register) {
        APIService apiService = APIClient.getClient().create(APIService.class);
        Call<UserInfo> call = apiService.Login(register);
        call.enqueue(new Callback<UserInfo>() {
            @Override
            public void onResponse(@NonNull Call<UserInfo> call, @NonNull Response<UserInfo> response) {
                if (response.code() == 200 && response.body() != null) {
                    App.userInfo = response.body();
                    App.Session = response.body().getStrSession();
                    App.register.setStrMobile(register.getStrMobile());
                    Cache.setString("logo", response.body().getStrLogo());
                    assert response.body() != null;
                    loginBackgroundResult(response.body().getResult());
                } else
                    loginBackgroundResult(-1);
            }

            @Override
            public void onFailure(@NonNull Call<UserInfo> call, @NonNull Throwable t) {
                loginBackgroundResult(-5);
            }
        });

    }

    public void sendCodeAgain() {

        App.register.setStrMobile(App.register.getStrMobile());

        APIService apiService = APIClient.getClient().create(APIService.class);
        Call<Integer> call = apiService.SendActivateCode(App.register);
        call.enqueue(new Callback<Integer>() {
            @Override
            public void onResponse(@NonNull Call<Integer> call, @NonNull Response<Integer> response) {
                if (response.code() == 200 && response.body() != null)
                    sendCodeResult(response.body());
                else
                    sendCodeResult(-4);
            }

            @Override
            public void onFailure(@NonNull Call<Integer> call, @NonNull Throwable t) {
                sendCodeResult(-5);
            }
        });
    }

    public void cacheUser() {
        try {
            Cache.setString("mobileNumber", App.register.getStrMobile());
            Cache.setString("IMEI", App.register.getStrIMEI());
//            if (!App.userInfo.getImgLink().equals(""))
//                Cache.setString("photo", App.userInfo.getImgLink());
        } catch (Exception ignored) {

        }

//        Cache.setString("encodedPassword", App.user.getEncodedPassword());
    }

    public void btValidatePressed(String validationCode) {
        if (Validate.activationCode(validationCode)) {
            startValidateLoading();
            Log.d(TAG, "btValidatePressed: ");
            validate(validationCode);
        } else
            showActivationCodeError(context.getResources().getString(R.string.emptyValidationCode));
    }

    public void btValidateDifferentIMEI_Pressed(String smsCode, String formerMobilePhone) {
        if (Validate.activationCode(smsCode)) {
            showPbDiffrentIMEI();
            validateDiffrentIMEI(smsCode, formerMobilePhone);
        } else
            showActivationCodeError(context.getResources().getString(R.string.emptyValidationCode));
    }

    public void sendAgainPressed() {
        startSendCodeAgainLoading();
        sendCodeAgain();
    }

    public void sendCodeResult(int result) {
        stopValidateLoading();
        switch (result) {
            case -5:
                Toaster.shorter(context.getString(R.string.connectionFaield));
                break;
            case -4:
                Toaster.shorter(context.getString(R.string.serverFaield));
                break;
//            case -1:
//                Toaster.shorter(context.getString(R.string.wrongUser));
//                break;
            case 0:
                Toaster.longer("کد فعالسازی اشتباه است ");
                break;
            case 1:
                Toaster.longer(context.getString(R.string.validateYourNumber));
                cacheUser();
                break;
            default:
                break;
        }
    }

    public void validateResult(int result) {
        stopValidateLoading();
        Log.i(TAG, "validateResult: result " + result);
        switch (result) {
            case -5:
                stopSendCodeAgainLoading();
                Toaster.shorter(context.getString(R.string.connectionFaield));
                stopSendCodeAgainLoading();
                break;
            case -4:
                stopSendCodeAgainLoading();
                Toaster.shorter(context.getString(R.string.serverFaield));
                stopSendCodeAgainLoading();
                break;
            case -3:
//                Toaster.shorter(App.userInfo.strComment);
                context.startActivity(new Intent(context, LoginActivity.class));
                break;
            case -1:
                Toaster.shorter(App.userInfo.strComment);
                break;
            case 0:
                Toaster.longer("کد فعالسازی اشتباه است.");
                stopSendCodeAgainLoading();
                break;
            case 1:
                loginBackground();
//                context.startActivity(new Intent(context,MainActivity.class));
                cacheUser();
                //((Activity) context).finish();
                break;
            default:
                break;
        }
    }

    public void validateDiffrentIMEIResult(int result) {
        stopPbValidateDifferentIMEI();
        if (result == 1) {
//            context.startActivity(new Intent(context, MainActivity.class));
            context.startActivity(new Intent(context, LoginActivity.class));
            App.strResult = "";
            cacheUser();
            ((Activity) context).finish();
        } else if (result == -3) {
//            Toaster.longer(App.userInfo.strComment);
            App.strResult = "-3";
            loginBackground();
            cacheUser();
//            context.startActivity(new Intent(context,LoginActivity.class));
            ((Activity) context).finish();
        } else if (result == -1) {
            Toaster.shorter(App.userInfo.strComment);
            App.strResult = "";
        } else if (result == 0) {
            Toaster.longer(App.userInfo.getStrComment());
            App.strResult = "";
            stopSendCodeAgainLoading();
        } else if (result == -5) {
            Toaster.shorter(App.userInfo.strComment);
            App.strResult = "";
            stopSendCodeAgainLoading();
            Toaster.shorter(context.getString(R.string.connectionFaield));
            stopSendCodeAgainLoading();
        }
    }

    public void loginBackgroundResult(int result) {
        if (result == 1) {
            getWhatsUP();
        } else if (result == 0) {
            context.startActivity(new Intent(context, LoginActivity.class));
            ((Activity) context).finish();
        } else if (result == -2) {
            context.startActivity(new Intent(context, ActivationActivity.class));
            Toaster.longer(context.getString(R.string.validateYourNumber));
            ((Activity) context).finish();
        } else if (result == -1) {
            Toaster.shorter(context.getString(R.string.serverFaield));
            //comment below line to prevent jumping splash when the web service is not correct
//            context.startActivity(new Intent(context,SplashActivity.class));
            ((Activity) context).finish();
        } else if (result == -5) {
            context.startActivity(new Intent(context, LoginActivity.class));
            ((Activity) context).finish();

        } else {
            gotoLogin();
        }
    }

    private void getWhatsUP() {
        WhatsUpRequest request = new WhatsUpRequest();
        request.setiPassenger(App.userInfo.getiPassenger());
        request.setStrAppVersion(BuildConfig.VERSION_NAME);
        request.setStrFullName(App.userInfo.getStrName() + " " + App.userInfo.getStrFamily());
        APIClient.getClient().create(APIService.class).Peysepar_WhatsUp(request).enqueue(new Callback<WhatsUpResponse>() {
            @Override
            public void onResponse(Call<WhatsUpResponse> call, Response<WhatsUpResponse> response) {
                if (response != null && response.isSuccessful() && response.body() != null) {
                    if (response.body().getiResult() == 1) {
                        showUpdateDialog(response.body());
                    } else {
                        goToMainActivity();
                    }
                } else {
                    goToMainActivity();
                }
            }

            @Override
            public void onFailure(Call<WhatsUpResponse> call, Throwable t) {
                goToMainActivity();
            }
        });
    }

    private void showUpdateDialog(WhatsUpResponse whatsUpResponse) {
        WhatsUpDialog dialog = new WhatsUpDialog(this, whatsUpResponse);
        dialog.show();
    }

    private void goToMainActivity() {
        startActivity(new Intent(context, MainActivity.class));
        cacheMobilePhone();
        finish();
    }

    private void gotoLogin() {
        context.startActivity(new Intent(context, LoginActivity.class));
        ((Activity) context).finish();

    }

    public void sendCodeAgainLoadTimeFinished() {
        stopSendCodeAgainLoading();
    }

    public void btnGotoRegisterDifferentIMEI_Pressed(String formerMobilePhone) {
        App.formerMobilePhoneDiffrentIMEI = formerMobilePhone;
        App.formerMobileDiffrentIMEI = true;
        context.startActivity(new Intent(context, RegisterActivity.class));
    }

    /*----------------------------------------sms related---------------------------------------------*/
    @Override
    protected void onStart() {
        super.onStart();
        registerReceiver(smsReceiver, new IntentFilter("android.provider.Telephony.SMS_RECEIVED"));
    }

    @Override
    protected void onStop() {
        super.onStop();
        unregisterReceiver(smsReceiver);
    }
}
