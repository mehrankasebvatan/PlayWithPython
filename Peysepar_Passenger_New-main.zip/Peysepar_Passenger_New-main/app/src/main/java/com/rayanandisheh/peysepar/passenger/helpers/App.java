package com.rayanandisheh.peysepar.passenger.helpers;

import android.app.Application;
import android.content.Context;

import androidx.annotation.NonNull;
import androidx.multidex.MultiDex;

import cn.like.nightmodel.NightModelManager;

import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.messaging.FirebaseMessaging;
import com.rayanandisheh.peysepar.passenger.models.*;


import java.util.ArrayList;
import java.util.List;

public class App extends Application {

    public static String ServerURL = "";
    //    public static String ServerURL = "http://192.168.1.104:8085";
//    public static String ServerURL = "http://192.168.1.105:8085";
//    public static String ServerURL = "http://pilam.peysepar.com";
//    public static String ServerURL = "http://192.168.1.200:1000/Passenger/";
//    public static String ServerURL = "http://192.168.1.109:1000";
//    public static String ServerURL = "";
//      public static String ServerURL = "http://79.127.36.117:1000/Passenger/";
    public static String Session = "";
    public static Context context;
    public static String encodingFormat = "md5"; //used for encoding passwords in helpers/Converter/encoder
    public static User user = new User();
    public static double lastLat = 0;
    public static double lastLng = 0;
    public static boolean isRun = false;
    public static boolean historySuccess = true;
    public static int iOfficialTrip;
    public static String timeToArrive;
    public static String notificationType = "";
    public static boolean isScreenOn;
    public static String updatResult;
    public static boolean IsRun = false;

    public static String addressMap;
    public static Double mLat = 35.700780;
    public static Double mLong = 51.404134;
    public static String strOriginAddress = "";
    public static String strDestinationAddress = "";
    public static float originLat;
    public static float originLon;
    public static float destinationLat;
    public static float destinationLon;
    public static String originCityName;
    public static String destinationCityName;
    public static String modeOfInsert;
    public static List<Chart> chartList;
    public static String strResult = "";
    public static String googleDistanceApiKey = "AIzaSyD4Lt0Jg_fEDcqmM-Fr_M8woUICXf3wfgo";
    public static String periviousMobileNum = "";
    public static int driverTime = 0;
    public static LatLng driverLocation = new LatLng(0.0, 0.0);
    public static int mapMode = 0;
    public static List<Car> listCar = new ArrayList<>();
    public static String CHANNEL_ID = "com.rayanandisheh.peysepar";

//    public static List<Trip> historyList = new ArrayList<>();

    //    public static boolean modeChanged = false;
    public static boolean modeChanged = false;
    public static NotificationModel notifModel = new NotificationModel();
    public static Trip model2 = new Trip();
    public static Geocoding Geo = null;

    public static String GlobalStartAddress;
    public static String GlobalEndAddress;

    public static String address;

    @Override
    public void onCreate() {
        super.onCreate();
        MultiDex.install(this);
//        Fabric.with(this, new Crashlytics());
        NightModelManager.getInstance().init(this);
        context = this;
        FirebaseApp.initializeApp(this);
        FirebaseMessaging.getInstance().getToken().addOnCompleteListener(task -> {
            try {
                if (task != null && task.isSuccessful()) {
                    String token = task.getResult();
                    Cache.setString("FirebaseToken", token);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public static Register register = new Register();
    public static UserInfo userInfo = new UserInfo();

    public static Integer pursuitCode = 0;

    public static boolean historyTripSuccess = true;
    public static boolean currentTripSuccess = true;

    public static boolean newTabLayoutListSuccess = true;
    public static boolean confirmedTripTabLayoutListSuccess = true;
    public static boolean waitingDriverConfirmTabLayoutListSuccess = true;
    public static boolean RunningTabLayoutListSuccess = true;
    public static boolean CanceledTripTabLayoutListSuccess = true;
    public static boolean assignDriverListSuccess = true;

    public static List<Trip> listCurrentTrip = new ArrayList<>();
    public static List<Trip> listHistoryTrip = new ArrayList<>();

    /*------------------retated to managementTrip fragments-----------------*/
    public static List<Trip> listNewTabLayoutTrip = new ArrayList<>();
    public static List<Trip> listConfirmedTripTabLayout = new ArrayList<>();
    public static List<Trip> listWaitingDriverConfirmTabLayout = new ArrayList<>();
    public static List<Trip> listRunningTabLayout = new ArrayList<>();
    public static List<Trip> listCanceledTabLayout = new ArrayList<>();
    /*-----------------------------------------------------------------------*/


    /*------------------retated to TripManagementNew-----------------*/
    public static List<Trip> listNewTripManagementNew = new ArrayList<>();
    public static List<Trip> listConfirmedTripManagementNew = new ArrayList<>();
    public static List<Trip> listWaitingDriverConfirmTripManagementNew = new ArrayList<>();
    public static List<Trip> listRunningTripManagementNew = new ArrayList<>();
    public static List<Trip> listCanceledTripManagementNew = new ArrayList<>();
    /*-----------------------------------------------------------------------*/
    public static boolean newTripManagementSuccess = true;
    public static boolean confirmedTripManagementSuccess = true;
    public static boolean waitingDriverConfirmTripManagementSuccess = true;
    public static boolean RunningTripManagementSuccess = true;
    public static boolean CanceledTripManagementSuccess = true;
//    public static boolean assignDriverListSuccess = true;

    public static List<DriverInfo> listAssignDriverConfirmedTabLayout = new ArrayList<>();
    public static List<DriverInfo> listDriverForSetTime = new ArrayList<>();

    public static String selectedPositionName = "";
    public static LatLng selectedPosition = new LatLng(App.userInfo.getfLat(), App.userInfo.getfLon());

    public static boolean map = false;

    public static String mobileFirstRunning = "";

    public static boolean marker_existance = false;

    //to check autoCompleteTextView
    public static List<TripSAD> tripSAD = new ArrayList<>();

    public static Report report = new Report();


    public static Data data = new Data();
    public static AssignDriver assignDriver = new AssignDriver();


    public static Score score = new Score();


    public static String dateFromTripManagement = "";
    public static String dateToTripManagement = "";


    public static boolean diffrentIMEI = false;
    public static String formerMobilePhoneDiffrentIMEI = "";
    public static boolean formerMobileDiffrentIMEI = false;


    public static Replace replace = new Replace();

    public static String mobileNumber_inActiveUser = "";

    public static Dashboard dashboard = new Dashboard();

    public static boolean dateRengeTripManagement = false;

    public static List<News> listNews = new ArrayList<>();
    public static boolean listNewsSuccess = true;

}

// keyStorPassword : 123698745
// keyPassword : RayanAndishehNasr 123698745