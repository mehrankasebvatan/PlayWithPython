package com.rayanandisheh.peysepar.passenger.utils;

import android.Manifest;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Environment;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.text.InputType;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.res.ResourcesCompat;
import androidx.core.graphics.drawable.DrawableCompat;

import com.rayanandisheh.peysepar.passenger.BuildConfig;
import com.rayanandisheh.peysepar.passenger.R;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Timer;
import java.util.TimerTask;

import me.leolin.shortcutbadger.ShortcutBadger;

public class MyClass {

    private static ProgressDialog prgDlg;
    public static Boolean loadingkeep = true;
    public static String ImagePath = Environment.getExternalStorageDirectory() + "/Shot.jpg";

    public void ShowLoading(final Context context, final String Title, final String Msg, final int TimeOut) {
        try {
            ((Activity) context).runOnUiThread(() -> {
                try {
                    if (prgDlg.isShowing()) {
                        return;
                    }
                } catch (Exception e) {
                }
                prgDlg = new ProgressDialog(context);
                prgDlg.setCancelable(false);
                prgDlg.setIndeterminate(true);

                if (!Title.equals("") && Title != null) {
                    prgDlg.setTitle(Title);
                } else {
                    prgDlg.setTitle(Title);
                }

                if (!Msg.equals("") && Msg != null) {
                    prgDlg.setMessage(Msg);
                } else {
                    prgDlg.setMessage(Msg);
                }
                prgDlg.show();
                loadingkeep = false;

                try {
                    if (context == null)
                        return;
                    ((Activity) context).runOnUiThread(new Runnable() {

                        @Override
                        public void run() {

                            final Timer t = new Timer();
                            t.schedule(new TimerTask() {
                                public void run() {

                                    prgDlg.dismiss();

                                    ((Activity) context).runOnUiThread(new Runnable() {
                                        @Override
                                        public void run() {

                                            //inja

//                                                if(loadingkeep==false) {
//                                                    Toast.makeText(context, "خطا در برقراری ارتباط", Toast.LENGTH_SHORT).show();
//                                                }else{
//
//                                                }
                                        }
                                    });

                                    t.cancel();
                                }

                            }, TimeOut);

                        }
                    });

                } catch (Exception ex) {
                    prgDlg.dismiss();
                    //Toast.makeText(context, "خطا در برقراری ارتباط", Toast.LENGTH_SHORT).show();
                }
            });

        } catch (Exception ex) {
        }
    }

    public void HideLoading(Context context) {
        try {
            ((Activity) context).runOnUiThread(() -> {
                if (prgDlg != null) {
                    prgDlg.dismiss();
                    loadingkeep = true;
                }
            });

        } catch (Exception ex) {
        }
    }

    public void ShowTimedOut(final Context context, final String Text, final int TimeOut) {
        try {
            if (context == null)
                return;
            ((Activity) context).runOnUiThread(() -> {

                final Timer t = new Timer();
                t.schedule(new TimerTask() {
                    public void run() {

                        prgDlg.dismiss();
                        loadingkeep = true;
                        t.cancel();
                    }
                }, TimeOut);

            });

        } catch (Exception ex) {
            prgDlg.dismiss();
            Toast.makeText(context, "خطا در برقراری ارتباط", Toast.LENGTH_SHORT).show();
        }
    }

    public Boolean Checktext(Context context, EditText inputview, String msg, int len) {
        Boolean check = true;

        String tmptxt = inputview.getText().toString();
        if (tmptxt.matches("")) {
            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show();
            check = true;
            return check;
        } else {

            if (len == 0) {
                check = false;
                return check;

            } else if (tmptxt.length() < len) {
                Toast.makeText(context, msg, Toast.LENGTH_SHORT).show();
                check = true;
                return check;
            } else {
                check = false;
                return check;
            }

        }

    }

    public Boolean isPhoneNumber(Context context, String number) {
        Boolean check = true;

        if (number.startsWith("09")) {
            check = false;
            return check;
        } else {
            Toast.makeText(context, "شماره وارد شده صحیح نمی باشد", Toast.LENGTH_SHORT).show();
            check = true;
            return check;
        }

    }

    public static void ToastM(final Context context, final String msg) {

        ((Activity) context).runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    if (msg != null) {
                        if (msg.length() > 2) {
                            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show();
                        }
                    }
                } catch (Exception e) {
                    Log.i("LG", "eeeeeeeeeeeeeeeeeeeeee");
                }
            }
        });

    }

    public String getDeviceIMEI(Context context) {
        String deviceUniqueIdentifier = null;
        TelephonyManager tm = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
        if (null != tm) {
            if (ActivityCompat.checkSelfPermission(context, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {

                return "";
            }
            deviceUniqueIdentifier = tm.getDeviceId();
        }
        if (null == deviceUniqueIdentifier || 0 == deviceUniqueIdentifier.length()) {
            deviceUniqueIdentifier = Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ANDROID_ID);
        }
        return deviceUniqueIdentifier;
    }

    public boolean isOnline(Context context) {
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = cm.getActiveNetworkInfo();
        return netInfo != null && netInfo.isConnectedOrConnecting();
    }

    public int GetVersionCode(Context context) {
        int verCode = 0;
        try {
            PackageInfo pInfo = context.getPackageManager().getPackageInfo(context.getPackageName(), 0);
            String version = pInfo.versionName;
            verCode = pInfo.versionCode;


            if (verCode == 0) {
                verCode = BuildConfig.VERSION_CODE;
            }

            return verCode;
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
            return verCode;
        }
    }

    public void SavePicture(String filename, Bitmap bitmap) {
        FileOutputStream out = null;
        try {
            out = new FileOutputStream(filename);
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, out);

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (out != null) {
                    out.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public Bitmap LoadPicture(String filename) {
        File file = new File(filename);
        Bitmap bitmap = null;

        if (!file.exists()) {
            return bitmap;
        }

        try {
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inPreferredConfig = Bitmap.Config.ARGB_8888;
            o2.inScaled = true;
            o2.inDither = true;
            o2.inSampleSize = 2;
            FileInputStream fis = new FileInputStream(file);
            bitmap = BitmapFactory.decodeStream(fis, null, o2);
            fis.close();

            return bitmap;

        } catch (Exception e) {
            e.printStackTrace();
            return bitmap;
        }
    }

//    public void RemoveBadge(Context context) {
//
//        int getBadge = 0;
//        getBadge = SharedPrefrencesHelper.getIntPref(context, "badge");
//
//        if (getBadge > 0) {
//            try {
//                ShortcutBadger.removeCount(context);
//                SharedPrefrencesHelper.setIntPref(context, "badge", 0);
//            } catch (Exception ignored) {
//            }
//        }
//    }

    public Bitmap ConvertStringToBitmap(String strBitmap, float density) {
        Bitmap iconBitmap = null;
        try {
            if (strBitmap != null || !strBitmap.equals("")) {
                byte[] decodedString = Base64.decode(strBitmap, Base64.DEFAULT);
                iconBitmap = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);

                int pxSize = Math.round((float) 25 * density);
                iconBitmap = Bitmap.createScaledBitmap(iconBitmap, pxSize, pxSize, false);
            }

        } catch (Exception e) {
            return iconBitmap;
        }

        return iconBitmap;
    }

    public Bitmap ConvertStringToBitmap(String strBitmap) {
        Bitmap iconBitmap = null;
        try {
            if (strBitmap != null || !strBitmap.equals("")) {
                byte[] decodedString = Base64.decode(strBitmap, Base64.DEFAULT);
                iconBitmap = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
                iconBitmap = Bitmap.createScaledBitmap(iconBitmap, 75, 75, false);
            }
        } catch (Exception e) {
            return iconBitmap;
        }
        return iconBitmap;
    }

    public void AddtoBitmap(Bitmap bitmap, Bitmap bitmap2, Bitmap bitmap3, int iAngel) {
        Paint p = new Paint();
        p.setAntiAlias(true);
        p.setFilterBitmap(true);
        p.setDither(true);
        //p.setColor(Color.parseColor(strColor));
        p.setStyle(Paint.Style.FILL);

        Bitmap bmp1 = Bitmap.createBitmap(80, 80, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        //canvas.drawCircle(40.0F, 40.0F, 15.0F, p);
        //Bitmap bitmap21=bitmapRotate(bitmap2,iAngel);
        canvas.drawBitmap(bitmap2, 0.0F, 0.0F, p);
        canvas.drawBitmap(bitmap3, 0.0F, 0.0F, p);
        Log.i("", "");
        //return bmp1;
    }

    public Bitmap DrawabletoBitmap(Context context, int drawable) {
        Bitmap myLogo = null;
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP_MR1) {
                Drawable vectorDrawable = ResourcesCompat.getDrawable(context.getResources(), drawable, null);
                myLogo = ((BitmapDrawable) vectorDrawable).getBitmap();

            } else {
                Drawable myDrawable = context.getResources().getDrawable(drawable);
                myLogo = ((BitmapDrawable) myDrawable).getBitmap();
            }

            return myLogo;
        } catch (Exception e) {
            return myLogo;
        }

    }

    public Bitmap bitmapRotate(Bitmap bitmap, float angle) {
        Bitmap rotateBitmap = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(rotateBitmap);
        Matrix matrix = new Matrix();
        matrix.postRotate(angle, bitmap.getWidth() / 2, bitmap.getHeight() / 2);
        canvas.drawBitmap(bitmap, matrix, null);
        return rotateBitmap;
    }

    public Bitmap BitmapToGray(Bitmap bmpOriginal) {
        int width, height;
        height = bmpOriginal.getHeight();
        width = bmpOriginal.getWidth();

        Bitmap bmpGrayscale = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmpGrayscale);
        Paint paint = new Paint();
        ColorMatrix cm = new ColorMatrix();
        cm.setSaturation(0);
        ColorMatrixColorFilter f = new ColorMatrixColorFilter(cm);
        paint.setColorFilter(f);
        c.drawBitmap(bmpOriginal, 0, 0, paint);
        return bmpGrayscale;
    }

    //encode image(image from drawable) to base64 string
//    public String encodeDrawable(int res, int id){
//        ByteArrayOutputStream baos = new ByteArrayOutputStream();
//        Bitmap bitmap = BitmapFactory.decodeResource(res, id);
//        bitmap.compress(Bitmap.CompressFormat.JPEG,100,baos);
//        byte[] imageBytes = baos.toByteArray();
//        return Base64.encodeToString(imageBytes, Base64.DEFAULT);
//    }

    public static Bitmap getResizedBitmap(Bitmap bm, int newHeight, int newWidth) {
        int width = bm.getWidth();
        int height = bm.getHeight();
        float scaleWidth = ((float) newWidth) / width;
        float scaleHeight = ((float) newHeight) / height;
        // create a matrix for the manipulation
        Matrix matrix = new Matrix();
        // resize the bit map
        matrix.postScale(scaleWidth, scaleHeight);
        // recreate the new Bitmap
        Bitmap resizedBitmap = Bitmap.createBitmap(bm, 0, 0, width, height, matrix, false);
        return resizedBitmap;
    }

    public static Bitmap getBitmapFromVectorDrawable(Context context, int drawableId) {
        Drawable drawable = ContextCompat.getDrawable(context, drawableId);
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
            drawable = (DrawableCompat.wrap(drawable)).mutate();
        }

        Bitmap bitmap = Bitmap.createBitmap(drawable.getIntrinsicWidth(),
                drawable.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        drawable.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
        drawable.draw(canvas);

        return bitmap;
    }

    public static String convertToArabic(String value) {
        String newValue = (((((((((((value)
                .replaceAll("1", "١")).replaceAll("2", "٢"))
                .replaceAll("3", "٣")).replaceAll("4", "٤"))
                .replaceAll("5", "٥")).replaceAll("6", "٦"))
                .replaceAll("7", "٧")).replaceAll("8", "٨"))
                .replaceAll("9", "٩")).replaceAll("0", "٠"));
        return newValue;
    }

    public String FixFormatTime(int num) {
        String setNumber = num + "";

        if (setNumber != null && setNumber.length() > 0) {
            if (setNumber.length() == 1) {
                setNumber = "0" + setNumber;
            }
        }
        return setNumber;
    }

    public String FixFormatDate(int yyyy, int mm, int dd) {
        String strDate = "";
        String y = "0000";
        String m = "00";
        String d = "00";

        mm = mm + 1;

        if (yyyy < 1000) {
            y = 1397 + "";
        } else {
            y = yyyy + "";
        }

        if (mm > 12 || mm < 1) {
            m = 1 + "";
        } else {
            m = (mm) + "";
            if (mm < 10) {
                m = "0" + (mm);
            }
        }

        if (dd > 31 || dd < 1) {
            d = 1 + "";
        } else {
            d = dd + "";
            if (dd < 10) {
                d = "0" + dd;
            }
        }

        strDate = y + "/" + m + "/" + d;

        return strDate;
    }

    public String inputDialog(Context context, String title, int type) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle(title);

        final EditText input = new EditText(context);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        builder.setView(input);

        builder.setPositiveButton("تایید", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // m_Text = input.getText().toString();
                setInput(input.getText().toString());
            }

            private String setInput(String input) {
                return input;
            }
        });
        builder.setNegativeButton("انصراف", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });


        builder.show();
        return "";
    }

    float density;

    public int dpToPx(final Context context, final int dp) {
        ((Activity) context).runOnUiThread(new Runnable() {
            @Override
            public void run() {
                density = context.getResources().getDisplayMetrics().density;
                Math.round((float) dp * density);
            }
        });

        return Math.round((float) dp * density);
    }
}
