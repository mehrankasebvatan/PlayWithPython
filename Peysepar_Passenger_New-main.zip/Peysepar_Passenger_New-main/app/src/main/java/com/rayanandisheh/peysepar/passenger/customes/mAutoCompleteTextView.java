package com.rayanandisheh.peysepar.passenger.customes;

import android.content.Context;
import android.util.AttributeSet;
import androidx.appcompat.widget.AppCompatAutoCompleteTextView;


public class mAutoCompleteTextView extends AppCompatAutoCompleteTextView {

    public mAutoCompleteTextView(Context context) {
        super(context);
    }

    public mAutoCompleteTextView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public mAutoCompleteTextView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }
}
