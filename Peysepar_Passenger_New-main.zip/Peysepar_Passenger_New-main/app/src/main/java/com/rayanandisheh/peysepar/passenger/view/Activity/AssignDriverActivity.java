package com.rayanandisheh.peysepar.passenger.view.Activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.text.Spanned;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.RequiresApi;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.rayanandisheh.peysepar.passenger.R;
import com.rayanandisheh.peysepar.passenger.helpers.App;
import com.rayanandisheh.peysepar.passenger.helpers.Cache;
import com.rayanandisheh.peysepar.passenger.helpers.PersianAppcompatActivity;
import com.rayanandisheh.peysepar.passenger.helpers.Toaster;
import com.rayanandisheh.peysepar.passenger.models.Data;
import com.rayanandisheh.peysepar.passenger.models.DriverInfo;
import com.rayanandisheh.peysepar.passenger.services.APIClient;
import com.rayanandisheh.peysepar.passenger.services.APIService;
import com.rayanandisheh.peysepar.passenger.view.Adapter.AssignDriverAdapter;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import jp.wasabeef.recyclerview.adapters.AlphaInAnimationAdapter;
import jp.wasabeef.recyclerview.adapters.ScaleInAnimationAdapter;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.rayanandisheh.peysepar.passenger.helpers.App.listAssignDriverConfirmedTabLayout;

public class AssignDriverActivity extends PersianAppcompatActivity  {
    Context context;

    RecyclerView recyclerView;
    RelativeLayout rvlTimeBtn;
    AssignDriverAdapter adapter;
    SwipeRefreshLayout swp_refresh;
    Button btnArriveOrigin;
    ProgressBar pbArriveOrigin;
    ImageView noImgItem;
    Toolbar toolbar;
    public static int counter = 1;
    int jTime = 0, iTme = 0, i = 0;
    int j = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_assign_driver);

        context = this;

        bindView();
        //getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        Intent intent = getIntent();
        App.iOfficialTrip = (intent.getIntExtra("iOfficialTrip", 0));


        viewLoaded(App.iOfficialTrip);

        swp_refresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {

                for (int i = 0; i < listAssignDriverConfirmedTabLayout.size(); i++) {
                    if (listAssignDriverConfirmedTabLayout.get(i).getStrTime() != null) {
                        swpRefreshPressedWithTime(App.iOfficialTrip);
                        Collections.sort(listAssignDriverConfirmedTabLayout, new Comparator<DriverInfo>() {
                            @Override
                            public int compare(DriverInfo di1, DriverInfo di2) {
                                return di1.getStrTime().compareTo(di2.getStrTime());
                            }

                        });
                    } else
                        swpRefreshPressed(App.iOfficialTrip);
                }
            }
        });


//        adapter = new AssignDriverAdapter(assignDriverListModel, context, (Presenter) presenter);
//        recyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
//        AlphaInAnimationAdapter alphaAdapter = new AlphaInAnimationAdapter(adapter);
//        recyclerView.setAdapter(new ScaleInAnimationAdapter(alphaAdapter));

//        getData();

        btnArriveOrigin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loadOriginTimes();
                btnArriveOrigin.setVisibility(View.GONE);
                pbArriveOrigin.setVisibility(View.VISIBLE);
            }
        });

    }

    private void bindView() {
        recyclerView = findViewById(R.id.rv_assignDrivers);
        swp_refresh = findViewById(R.id.swp_assignDrivers);
        noImgItem = findViewById(R.id.img_noIconAssignDrivers);
        toolbar = findViewById(R.id.toolbar_driverList);
        btnArriveOrigin = findViewById(R.id.btnArriveOrigin);
        pbArriveOrigin = findViewById(R.id.pbArriveOrigin);
        rvlTimeBtn = findViewById(R.id.rvlTimeBtn);

        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        setTitle("لیست رانندگان");
    }

//    private void getData() {
//        assignDriverListModel.add(new ModelAssignDriverTest("علی احمدی","سمند","سواری","آماده ارائه سرویس",3));
//        assignDriverListModel.add(new ModelAssignDriverTest("محمد رضایی","پراید","سواری","خارج از سرویس",2));
//        assignDriverListModel.add(new ModelAssignDriverTest("مهدی پوری","پژو","سواری","آماده ارائه سرویس",0));
//        assignDriverListModel.add(new ModelAssignDriverTest("میلار حقی","وانت","باری","خارج از سرویس",1));
//        assignDriverListModel.add(new ModelAssignDriverTest("رضا علیپور","پارس","سواری","آماده ارائه سرویس",2));
//        assignDriverListModel.add(new ModelAssignDriverTest("محمد رضایی","پراید","سواری","خارج از سرویس",2));
//        assignDriverListModel.add(new ModelAssignDriverTest("مهدی پوری","پژو","سواری","آماده ارائه سرویس",0));
//    }

    public void showSwipeRefresh() {
        swp_refresh.setRefreshing(true);
    }

    public void hideImg_noItem() {
        rvlTimeBtn.setVisibility(View.VISIBLE);
        noImgItem.setVisibility(View.GONE);
    }

    public void showImg_noItem() {
        rvlTimeBtn.setVisibility(View.GONE);
        noImgItem.setVisibility(View.VISIBLE);
    }

    public void hideSwipeRefresh() {
        swp_refresh.setRefreshing(false);
    }

    public void setAdapter() {
        List<DriverInfo> sortedList = new ArrayList<>();

//        for (i = 0; i < listAssignDriverConfirmedTabLayout.size(); i++) {
//            if (listAssignDriverConfirmedTabLayout.get(i).getStrTime() != null) {
//                if (listAssignDriverConfirmedTabLayout.get(i).getStrTime().equals("موقعیتی ثبت نشده است") || listAssignDriverConfirmedTabLayout.get(i).getStrTime().length() > 4) {
//                    sortedList.add(listAssignDriverConfirmedTabLayout.get(i));
//                    listAssignDriverConfirmedTabLayout.remove(i);
//                }
//
////                Collections.sort(listAssignDriverConfirmedTabLayout, new Comparator<DriverInfo>() {
////                    @Override
////                    public int compare(DriverInfo di1, DriverInfo di2) {
////                        return di1.getStrTime().compareTo(di2.getStrTime());
////                    }
////                });
//
//
//            }
//        }

        if (App.driverTime == 1 && listAssignDriverConfirmedTabLayout.size() != 0) {
            for (i = 0; i < listAssignDriverConfirmedTabLayout.size(); i++) {
                if (listAssignDriverConfirmedTabLayout.get(i).getStrTime() != null) {
                    if (listAssignDriverConfirmedTabLayout.get(i).getStrTime().equals("موقعیتی ثبت نشده است") || listAssignDriverConfirmedTabLayout.get(i).getStrTime().length() > 4) {
                        sortedList.add(listAssignDriverConfirmedTabLayout.get(i));
                        listAssignDriverConfirmedTabLayout.remove(i);
                        i = i - 1;
                    }
                }
            }
            for (i = 0; i < listAssignDriverConfirmedTabLayout.size() - 1; i++) {
                DriverInfo tDriverInfo = new DriverInfo();
                String iData = listAssignDriverConfirmedTabLayout.get(i).getStrTime();
                DriverInfo iDriverInfo = new DriverInfo();
                iDriverInfo = listAssignDriverConfirmedTabLayout.get(i);
                for (j = i + 1; j < listAssignDriverConfirmedTabLayout.size(); j++) {
                    String jData = listAssignDriverConfirmedTabLayout.get(j).getStrTime();
                    DriverInfo jDriverInfo = new DriverInfo();
                    jDriverInfo = listAssignDriverConfirmedTabLayout.get(j);
                    if (Integer.parseInt(iData) > Integer.parseInt(jData)) {
                        tDriverInfo = iDriverInfo;
                        listAssignDriverConfirmedTabLayout.remove(i);
                        listAssignDriverConfirmedTabLayout.add(i, jDriverInfo);
                        listAssignDriverConfirmedTabLayout.remove(j);
                        listAssignDriverConfirmedTabLayout.add(j, tDriverInfo);
                        iData = listAssignDriverConfirmedTabLayout.get(i).getStrTime();

                    }
                }
            }
        }


        if (sortedList.size() != 0)
            listAssignDriverConfirmedTabLayout.addAll(sortedList);

        adapter = new AssignDriverAdapter(listAssignDriverConfirmedTabLayout
                , context, (strunitid, iofficialtrip) -> {
            requestConfirmDriverAlert(strunitid, iofficialtrip);
        });
        recyclerView.setLayoutManager(new LinearLayoutManager(context));
        AlphaInAnimationAdapter alphaAdapter = new AlphaInAnimationAdapter(adapter);
        recyclerView.setAdapter(new ScaleInAnimationAdapter(alphaAdapter));
    }

    public void setVisibility(int result) {
        if (App.userInfo.isbEnableGoogleAPI()) {
            btnArriveOrigin.setVisibility(View.VISIBLE);
            pbArriveOrigin.setVisibility(View.GONE);
        } else {
            btnArriveOrigin.setVisibility(View.GONE);
            pbArriveOrigin.setVisibility(View.GONE);
        }
    }

    public void showDurationText(Spanned fromHtml, TextView.BufferType spannable) {

//        textViewDuration.setText(fromHtml, spannable);
    }

    public void requesrListAssignDriver(int iOfficialTrip) {
        App.userInfo.setStrMobile(Cache.getString("mobileNumber"));
        App.userInfo.setIofficialtrip(iOfficialTrip);
        APIService apiService = APIClient.getClient().create(APIService.class);
        Call<List<DriverInfo>> call = apiService.driverList(App.userInfo,App.Session);
        call.enqueue(new Callback<List<DriverInfo>>() {
            @Override
            public void onResponse(@NotNull Call<List<DriverInfo>> call, @NotNull Response<List<DriverInfo>> response) {
                if (response.code() == 200) {
                    App.driverTime = 0;
                    App.listAssignDriverConfirmedTabLayout = response.body();
                    if (App.listAssignDriverConfirmedTabLayout != null) {
                        driverListResult(1);
                    }

                } else {
                    driverListResult(-4);
                }
            }

            @Override
            public void onFailure(@NotNull Call<List<DriverInfo>> call, @NotNull Throwable t) {
                driverListResult(-5);
            }
        });
    }

    public void requestConfirmDriverAlert(String strunitid, int iofficialtrip) {
        App.assignDriver.setStrunitId(strunitid);
        App.assignDriver.setIofficialtrip(iofficialtrip);

        APIService apiService = APIClient.getClient().create(APIService.class);
        Call<Data> call = apiService.assignDriver(App.assignDriver,App.Session);
        call.enqueue(new Callback<Data>() {
            @Override
            public void onResponse(@NotNull Call<Data> call, @NotNull Response<Data> response) {
                if (response.code() == 200) {
                    App.driverTime = 0;
                    App.data = response.body();
                    if (response.body().Result == -2) {
                        setTost();
                    } else
                        assignDriverSelectedResult(1);
                } else {
                    assignDriverSelectedResult(-4);
                }
            }

            @Override
            public void onFailure(@NotNull Call<Data> call, @NotNull Throwable t) {
                assignDriverSelectedResult(-5);
            }
        });
    }

    public void getDriversOrinTime() {
        App.userInfo.setStrMobile(Cache.getString("mobileNumber"));
        App.userInfo.setIofficialtrip(App.iOfficialTrip);
        APIService apiService = APIClient.getClient().create(APIService.class);
        Call<List<DriverInfo>> call = apiService.getTimeDriver(App.userInfo,App.Session);
        call.enqueue(new Callback<List<DriverInfo>>() {
            @Override
            public void onResponse(@NotNull Call<List<DriverInfo>> call, @NotNull Response<List<DriverInfo>> response) {
                if (response.code() == 200) {
                    App.listAssignDriverConfirmedTabLayout = response.body();
                    if (App.listAssignDriverConfirmedTabLayout != null) {
                        App.driverTime = 1;
                        driverListResult(1);
                    }

                } else {
                    driverListResult(-4);
                }
            }

            @Override
            public void onFailure(@NotNull Call<List<DriverInfo>> call, @NotNull Throwable t) {
                driverListResult(-5);
            }
        });

    }

//    @Override
//    public void checkDriverStatus(String drivername) {
//
//        APIService apiService = APIClient.getClient().create(APIService.class);
//        Call<Integer> call = apiService.checkDriverStatus(drivername);
//        call.enqueue(new Callback<Integer>() {
//            @Override
//            public void onResponse(@NotNull Call<Integer> call, @NotNull Response<Integer> response) {
//                if (response.code() == 200 && response.body() != null) {
//                    presenter.setDriverStatus(response.body());
//                } else
//                    presenter.setDriverStatus(-4);
//            }
//
//            @Override
//            public void onFailure(@NotNull Call<Integer> call, @NotNull Throwable t) {
//                presenter.setDriverStatus(-5);
//
//            }
//        });
//
//    }


//    private BroadcastReceiver mBroadcastReceiver = new BroadcastReceiver() {
//        @Override
//        public void onReceive(Context context, Intent intent) {
//            receivedBroadcast(intent);
//        }
//    };
//
//    private void receivedBroadcast(Intent intent) {
//        if (intent.getAction().matches("android.intent.action.map_result_ok") ||
//                intent.getAction().matches("android.intent.action.map_result_fail")) {
//            getExtras(intent.getIntExtra("hour", 0),
//                    intent.getIntExtra("minute", 0),
//                    intent.getStringExtra("duration"),
//                    intent.getStringExtra("distance"));
//        }
//    }
//
//
//    private void getExtras(int hour, int minute, String duration, String distance) {
//        minute = hour == 0 && minute < 5 ? 5 : minute;
//        timeToArrive = String.valueOf(hour).concat(":").concat(String.valueOf(minute));
////        try {
////            model.setDistance(Converter.valueChecked(Float.parseFloat(distance)));
////            model.setDuration(Converter.valueChecked(Integer.parseInt(duration)));
////        } catch (Exception ignored) {
////        }
//
//        String text = "";
//        if (!duration.isEmpty() && !distance.isEmpty()) {
//            text = "<font color='" + ContextCompat.getColor(App.context, R.color.colorPrimaryText) + "'>زمان تا مبدا: </font>" +
//                    "<font color='" + ContextCompat.getColor(App.context, R.color.colorAccent) +
//                    "'>" + Time.minutesToHours(Integer.parseInt(duration) / 60) + "</font>" + " <br /> <br /> " +
//                    "<font color='" + ContextCompat.getColor(App.context, R.color.colorPrimaryText) + "'>فاصله تا مبدا: </font>" +
//                    "<font color='" + ContextCompat.getColor(App.context, R.color.colorAccent) +
//                    "'>" + Location.meterToKM(distance) + "</font>";
//        }
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
//            view.showDurationText(Html.fromHtml(text, Html.FROM_HTML_MODE_LEGACY), TextView.BufferType.SPANNABLE);
//        } else {
//            view.showDurationText(Html.fromHtml(text), TextView.BufferType.SPANNABLE);
//        }
//
//    }

    public void viewLoaded(int iOfficialTrip) {
        if (App.assignDriverListSuccess) {
            showSwipeRefresh();
            requesrListAssignDriver(iOfficialTrip);

        } else if (App.listAssignDriverConfirmedTabLayout.size() > 0) {
//            view.setAdapter();
            hideImg_noItem();
        } else if (App.listAssignDriverConfirmedTabLayout.size() == 0) {
            showImg_noItem();
        }
    }

    public void swpRefreshPressed(int iOfficialTrip) {
        showSwipeRefresh();
        requesrListAssignDriver(iOfficialTrip);
    }

    public void swpRefreshPressedWithTime(int iOfficialTrip) {
        showSwipeRefresh();
        getDriversOrinTime();
    }

    public void setTost() {
        Toaster.shorter("هم اکنون راننده موردنظر از سرویس خارج شده است");
    }

    public void driverListResult(int result) {
        hideSwipeRefresh();
        if (result == -4) {
            Toaster.shorter(context.getString(R.string.serverFaield));
            setVisibility(result);
        } else if (result == -5) {
            Toaster.shorter(context.getString(R.string.connectionFaield));
            setVisibility(result);
        } else if (result == 0)
            showImg_noItem();
        else if (result == 1) {
            setVisibility(result);
            setAdapter();
            hideImg_noItem();
            if (App.listAssignDriverConfirmedTabLayout.size() == 0) {
                showImg_noItem();
            }
        }else if (result == 100) {
            Intent intent = new Intent(AssignDriverActivity.this, LoginActivity.class);
            startActivity(intent);
        }
    }


    public void assignDriverSelectedResult(int result) {
        hideSwipeRefresh();
        if (result == -4)
            Toaster.shorter(context.getString(R.string.serverFaield));
        else if (result == -5)
            Toaster.shorter(context.getString(R.string.connectionFaield));
        else if (result == 1) {
            Toaster.shorter(App.data.getMessage());
            ((Activity) context).finish();
        } else if (result == -1)
            Toaster.shorter(App.data.getMessage());
        else if (result == 100) {
            Intent intent = new Intent(AssignDriverActivity.this, LoginActivity.class);
            startActivity(intent);
        }
    }

    public void loadOriginTimes() {
        getDriversOrinTime();
    }

    public void loadDataResult(int result) {
        hideSwipeRefresh();
        if (result == -4)
            Toaster.shorter(context.getString(R.string.serverFaield));
        else if (result == -5)
            Toaster.shorter(context.getString(R.string.connectionFaield));
        else if (result == 0)
            showImg_noItem();
        else if (result == 1) {
            setAdapter();
            hideImg_noItem();
            if (App.listConfirmedTripTabLayout.size() > 0)
                hideImg_noItem();
            else
                showImg_noItem();

        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
