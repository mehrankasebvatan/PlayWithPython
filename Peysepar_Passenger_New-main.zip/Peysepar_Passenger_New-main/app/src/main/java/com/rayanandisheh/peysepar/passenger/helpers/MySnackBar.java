package com.rayanandisheh.peysepar.passenger.helpers;

import android.content.Context;
import android.graphics.Color;
import android.os.Build;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.core.content.ContextCompat;

import com.google.android.material.snackbar.Snackbar;
import com.rayanandisheh.peysepar.passenger.R;

public class MySnackBar {

    public static void ShowLong(View view, String text) {
        Snackbar mSnackBar = Snackbar.make(view, text, Snackbar.LENGTH_LONG);
        mSnackBar.setBackgroundTint(ContextCompat.getColor(App.context, R.color.colorBackSnackbar));
        TextView mainTextView = (mSnackBar.getView()).findViewById(R.id.snackbar_text);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1)
            mainTextView.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        else
            mainTextView.setGravity(Gravity.CENTER_HORIZONTAL);
        mSnackBar.setAction("فهمیدم", v -> mSnackBar.dismiss()).show();
        mSnackBar.setActionTextColor(ContextCompat.getColor(App.context, R.color.colorYellow));
        mSnackBar.show();
    }

    public static void ShowShort(View view, String text) {
        Snackbar mSnackBar = Snackbar.make(view, text, Snackbar.LENGTH_SHORT);
        mSnackBar.setBackgroundTint(ContextCompat.getColor(App.context, R.color.colorBackSnackbar));
        TextView mainTextView = (mSnackBar.getView()).findViewById(R.id.snackbar_text);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1)
            mainTextView.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        else
            mainTextView.setGravity(Gravity.CENTER_HORIZONTAL);
        mSnackBar.setAction("فهمیدم", v -> mSnackBar.dismiss()).show();
        mSnackBar.setActionTextColor(ContextCompat.getColor(App.context, R.color.colorYellow));
        mSnackBar.show();
    }

    public static void ShowShortDisble(View view, String text) {
        Snackbar mSnackBar = Snackbar.make(view, text, Snackbar.LENGTH_SHORT);
        mSnackBar.setBackgroundTint(ContextCompat.getColor(App.context, R.color.colorText));
        TextView mainTextView = (mSnackBar.getView()).findViewById(R.id.snackbar_text);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1)
            mainTextView.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        else
            mainTextView.setGravity(Gravity.CENTER_HORIZONTAL);
        mSnackBar.setAction("فهمیدم", v -> mSnackBar.dismiss()).show();
        mSnackBar.setActionTextColor(ContextCompat.getColor(App.context, R.color.colorYellow));
        mSnackBar.show();
    }

    public static void ShowSuccessful(View view, String text) {
        Snackbar mSnackBar = Snackbar.make(view, text, Snackbar.LENGTH_SHORT);
        mSnackBar.setBackgroundTint(ContextCompat.getColor(App.context, R.color.colorSuccessful));
        TextView mainTextView = (mSnackBar.getView()).findViewById(R.id.snackbar_text);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1)
            mainTextView.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        else
            mainTextView.setGravity(Gravity.CENTER_HORIZONTAL);
        mSnackBar.setAction("فهمیدم", v -> mSnackBar.dismiss()).show();
        mSnackBar.setActionTextColor(ContextCompat.getColor(App.context, R.color.colorYellow));
        mSnackBar.show();
    }

    public static void ShowWarning(View view, String text) {
        Snackbar mSnackBar = Snackbar.make(view, text, Snackbar.LENGTH_SHORT);
        mSnackBar.setBackgroundTint(ContextCompat.getColor(App.context, R.color.colorWarning));
        TextView mainTextView = (mSnackBar.getView()).findViewById(R.id.snackbar_text);
        mainTextView.setTextColor(ContextCompat.getColor(App.context, R.color.colorTextPrimery));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1)
            mainTextView.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        else
            mainTextView.setGravity(Gravity.CENTER_HORIZONTAL);
        mSnackBar.setAction("فهمیدم", v -> mSnackBar.dismiss()).show();
        mSnackBar.show();
    }

    public static void ShowCustomEnable(View view, String text) {
        final Snackbar snackbar = Snackbar.make(view, "", Snackbar.LENGTH_LONG);
        Snackbar.SnackbarLayout layout = (Snackbar.SnackbarLayout) snackbar.getView();
        LayoutInflater objLayoutInflater = (LayoutInflater) App.context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View snackView = objLayoutInflater.inflate(R.layout.custom_snac_layout, null);

        TextView tv_text = snackView.findViewById(R.id.tv_text);
        TextView tv_click = snackView.findViewById(R.id.tv_click);

        tv_text.setText(text);
        tv_text.setTextSize(16);
        tv_text.setTextColor(ContextCompat.getColor(App.context, R.color.colorWhite));
        tv_click.setTextColor(ContextCompat.getColor(App.context, R.color.colorWarning));
        snackView.setBackgroundColor(ContextCompat.getColor(App.context, R.color.colorBackSnackbar));
        snackbar.setBackgroundTint(ContextCompat.getColor(App.context, R.color.colorBackSnackbar));

        tv_click.setOnClickListener(v -> snackbar.dismiss());

        layout.addView(snackView);
        snackbar.show();
    }

    public static void ShowCustomDisable(View view, String text) {
        final Snackbar snackbar = Snackbar.make(view, "", Snackbar.LENGTH_LONG);
        Snackbar.SnackbarLayout layout = (Snackbar.SnackbarLayout) snackbar.getView();
        LayoutInflater objLayoutInflater = (LayoutInflater) App.context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View snackView = objLayoutInflater.inflate(R.layout.custom_snac_layout, null);

        TextView tv_text = snackView.findViewById(R.id.tv_text);
        TextView tv_click = snackView.findViewById(R.id.tv_click);

        tv_text.setText(text);
        tv_text.setTextSize(16);
        tv_click.setTextSize(16);
        tv_text.setTextColor(ContextCompat.getColor(App.context, R.color.colorWhite));
        tv_click.setTextColor(ContextCompat.getColor(App.context, R.color.colorWarning));
        snackView.setBackgroundColor(ContextCompat.getColor(App.context, R.color.colorText));
        snackbar.setBackgroundTint(ContextCompat.getColor(App.context, R.color.colorText));

        tv_click.setOnClickListener(v -> snackbar.dismiss());

        layout.addView(snackView);
        snackbar.show();
    }

    public static void ShowCustomSuccessful(View view, String text) {
        final Snackbar snackbar = Snackbar.make(view, "", Snackbar.LENGTH_LONG);
        Snackbar.SnackbarLayout layout = (Snackbar.SnackbarLayout) snackbar.getView();
        LayoutInflater objLayoutInflater = (LayoutInflater) App.context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View snackView = objLayoutInflater.inflate(R.layout.custom_snac_layout, null);

        TextView tv_text = snackView.findViewById(R.id.tv_text);
        TextView tv_click = snackView.findViewById(R.id.tv_click);

        tv_text.setText(text);
        tv_text.setTextSize(16);
        tv_click.setTextSize(16);
        tv_text.setTextColor(ContextCompat.getColor(App.context, R.color.colorWhite));
        tv_click.setTextColor(ContextCompat.getColor(App.context, R.color.colorBackSnackbar));
        snackView.setBackgroundColor(ContextCompat.getColor(App.context, R.color.colorSuccessful));
        snackbar.setBackgroundTint(ContextCompat.getColor(App.context, R.color.colorSuccessful));

        tv_click.setOnClickListener(v -> snackbar.dismiss());

        layout.addView(snackView);
        snackbar.show();
    }

    public static void ShowCustomWarning(View view, String text) {
        final Snackbar snackbar = Snackbar.make(view, "", Snackbar.LENGTH_LONG);
        Snackbar.SnackbarLayout layout = (Snackbar.SnackbarLayout) snackbar.getView();
        LayoutInflater objLayoutInflater = (LayoutInflater) App.context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View snackView = objLayoutInflater.inflate(R.layout.custom_snac_layout, null);

        TextView tv_text = snackView.findViewById(R.id.tv_text);
        TextView tv_click = snackView.findViewById(R.id.tv_click);

        tv_text.setText(text);
        tv_text.setTextSize(16);
        tv_click.setTextSize(16);
        tv_text.setTextColor(ContextCompat.getColor(App.context, R.color.colorPrimaryText));
        tv_click.setTextColor(ContextCompat.getColor(App.context, R.color.colorBackSnackbar));
        snackView.setBackgroundColor(ContextCompat.getColor(App.context, R.color.colorWarning));
        snackbar.setBackgroundTint(ContextCompat.getColor(App.context, R.color.colorWarning));

        tv_click.setOnClickListener(v -> snackbar.dismiss());

        layout.addView(snackView);
        snackbar.show();
    }
}