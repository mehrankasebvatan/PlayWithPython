package com.rayanandisheh.peysepar.passenger.view.Activity;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;

import androidx.appcompat.app.AppCompatActivity;

import android.net.Uri;
import android.os.Bundle;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;

import com.rayanandisheh.peysepar.passenger.BuildConfig;
import com.rayanandisheh.peysepar.passenger.R;

public class AboutPeyseparActivity extends AppCompatActivity {

    Context context;

    ImageView ivIcon;
    TextView tvAppName, tvAppVersion;

    String versionName;
    PackageInfo pinfo = null;
    int versionNumber;
    PackageManager packageManager;

    int currentVersion;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about_peysepar);

        context = this;

        activityLoaded();
        bindView();
        //getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE)

        ivIcon.setOnClickListener(v -> brandClicked());
        tvAppName.setOnClickListener(v -> brandClicked());


        try {
            pinfo = getPackageManager().getPackageInfo(getPackageName(), 0);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
//
        versionName = pinfo.versionName;

        try {
            currentVersion = context.getPackageManager().getPackageInfo(context.getPackageName(), 0).versionCode;

        } catch (PackageManager.NameNotFoundException e) {
        }
        tvAppVersion.setText(versionName);
//        tvAppVersion.setText(App.userInfo.getVersionName());

    }

    private void bindView() {
        ivIcon = findViewById(R.id.ivIcon);
        tvAppName = findViewById(R.id.tvAppName);
        tvAppVersion = findViewById(R.id.tvAppVersion);
    }

    public void showAppVersion() {
//todo get versionName from server and set here
//        tvAppVersion.setText(versionNumber);
    }

    public String getAppVersion() {
        return BuildConfig.VERSION_NAME;
    }

    public void brandClicked() {
        context.startActivity(new Intent(Intent.ACTION_VIEW).setData(Uri.parse(context.getString(R.string.app_link))));
    }

    public void activityLoaded() {
//        view.showAppVersion(context.getString(R.string.version) + " " + model.getAppVersion());
        showAppVersion();
    }
}
