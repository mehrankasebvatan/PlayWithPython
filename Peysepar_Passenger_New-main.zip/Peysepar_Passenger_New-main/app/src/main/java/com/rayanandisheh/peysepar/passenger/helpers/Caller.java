package com.rayanandisheh.peysepar.passenger.helpers;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;

public class Caller {
    public static void callTo(Context context, String name, String number) {
        context.startActivity(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + number)));
        Toaster.longer("تماس با  " + name);
    }
    public static void callTo(Context context, String firstName, String lastName, String number) {
        context.startActivity(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + number)));
        Toaster.longer("تماس با  " + firstName + " " + lastName);
    }
}