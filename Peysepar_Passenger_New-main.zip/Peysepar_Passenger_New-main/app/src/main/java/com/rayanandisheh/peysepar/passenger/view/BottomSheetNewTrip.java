package com.rayanandisheh.peysepar.passenger.view;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.rayanandisheh.peysepar.passenger.R;

public class BottomSheetNewTrip extends BottomSheetDialogFragment implements View.OnClickListener {

    private static final String TAG = "BottomSheetSelectCustomer";
    private View view;
    private Context context;
    private int id;
    public Activity m_activity;
    private TextView txt_normal_insertTrip;
    private TextView txt_map_insertTrip;
    public OnClickSheet onClickSheet;

    public BottomSheetNewTrip(OnClickSheet onClickSheet) {
        this.onClickSheet = onClickSheet;
    }

    @SuppressLint("InflateParams")
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container
            , @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.bottomsheet_new_trip, null);
        setViews();
        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        context = getContext();
//        setCancelable(false);
    }

    private void setViews() {
        txt_normal_insertTrip = view.findViewById(R.id.txt_normal_insertTrip);
        txt_map_insertTrip = view.findViewById(R.id.txt_map_insertTrip);

        txt_normal_insertTrip.setOnClickListener(this);
        txt_map_insertTrip.setOnClickListener(this);
    }

    public interface OnClickSheet {
        void onClickNormal();

        void onClickMap();
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.txt_normal_insertTrip:
                onClickSheet.onClickNormal();
                dismiss();
                break;
            case R.id.txt_map_insertTrip:
                onClickSheet.onClickMap();
                dismiss();
                break;
        }
    }
}
