package com.rayanandisheh.peysepar.passenger.view;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.rayanandisheh.peysepar.passenger.R;

public class BottomSheetSelect extends BottomSheetDialogFragment implements View.OnClickListener {

    private static final String TAG = "BottomSheetSelect";
    private View view;
    private Context context;
    private int id;
    public Activity m_activity;
    private TextView tv_newTrip;
    private TextView tv_dataTrip;
    public OnClickSheet onClickSheet;

    public BottomSheetSelect(OnClickSheet onClickSheet) {
        this.onClickSheet = onClickSheet;
    }

    @SuppressLint("InflateParams")
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container
            , @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.bottomsheet_select, null);
        setViews();
        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        context = getContext();
    }

    private void setViews() {
        tv_newTrip = view.findViewById(R.id.tv_newTrip);
        tv_dataTrip = view.findViewById(R.id.tv_dataTrip);

        tv_newTrip.setOnClickListener(this);
        tv_dataTrip.setOnClickListener(this);
    }

    public interface OnClickSheet {
        void onClickNewTrip();

        void onClickDataTrip();
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.tv_newTrip:
                onClickSheet.onClickNewTrip();
                dismiss();
                break;
            case R.id.tv_dataTrip:
                onClickSheet.onClickDataTrip();
                dismiss();
                break;
        }
    }
}
