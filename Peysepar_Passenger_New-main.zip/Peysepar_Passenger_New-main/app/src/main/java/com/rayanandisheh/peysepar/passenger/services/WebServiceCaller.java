package com.rayanandisheh.peysepar.passenger.services;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class WebServiceCaller {
    private APIService apiService;

    public void getAndroidVersion(int iPassenger, callBack callBack) {
        apiService.PM_GetAndroidVer(iPassenger).enqueue(new Callback<String>() {
            @Override
            public void onResponse(Call<String> call, Response<String> response) {
                if(response.code()==200){
                    callBack.onSuccess(response.body());

                }else {
                    callBack.onFailure("خطا در بارگذاری نقشه");
                }
            }

            @Override
            public void onFailure(Call<String> call, Throwable t) {
                callBack.onFailure("خطا در دریافت اطلاعات");
            }
        });
    }

    public interface callBack {
        String onSuccess(String response);

        String onFailure(String response);
    }
}
