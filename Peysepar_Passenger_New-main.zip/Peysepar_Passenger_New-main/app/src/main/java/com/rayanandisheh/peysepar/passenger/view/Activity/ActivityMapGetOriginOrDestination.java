package com.rayanandisheh.peysepar.passenger.view.Activity;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatEditText;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.UiSettings;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.rayanandisheh.peysepar.passenger.R;
import com.rayanandisheh.peysepar.passenger.helpers.App;
import com.rayanandisheh.peysepar.passenger.helpers.GpsTracker;
import com.rayanandisheh.peysepar.passenger.helpers.MyLocation;
import com.rayanandisheh.peysepar.passenger.helpers.MySnackBar;
import com.rayanandisheh.peysepar.passenger.helpers.Time;
import com.rayanandisheh.peysepar.passenger.models.Geocoding;
import com.rayanandisheh.peysepar.passenger.services.APIClient;
import com.rayanandisheh.peysepar.passenger.services.APIService;
import com.rayanandisheh.peysepar.passenger.utils.MyClass;

import java.util.Objects;
import java.util.Timer;
import java.util.TimerTask;

import static com.rayanandisheh.peysepar.passenger.helpers.GetDistanceData.callDistance;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ActivityMapGetOriginOrDestination extends AppCompatActivity implements OnMapReadyCallback {

    private static final String TAG = "AgencyActivity";
    private static final int LOCATION_PERMISSION_REQUEST_CODE = 1;

    private GoogleMap mMap;
    Marker selectLocation;
    public Marker originMarker, destinationMarker;
    public LatLng originLatLon = null;
    public LatLng destinationLatLon = null;
    Double mLat = 33.0;
    Double mLong = 53.0;
    float originLat, originLon, destinationLat, destinationLon;
    FloatingActionButton fb_back, fb_location;
    Activity activity;
    Context context;
    LocationManager locationManager;
    Button btn_SendData;
    String date;
    private ProgressBar pbRegisterTrip;
    MyClass MYC = new MyClass();
    private boolean gpsIsEnabled = false;
    private TextView tv_type;
    private Timer timer = new Timer();
    private String typeLocation;

    private AppCompatTextView search;

    private AppCompatEditText address;

    @SuppressLint("MissingPermission")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map_origin_destination);
        activity = this;
        context = this;
        initViews();
        //getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        date = Time.getNowPersianDate();
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        assert mapFragment != null;
        mapFragment.getMapAsync(this);

        MyLocation.getLocation2(context);

        gettingLocation();

        btn_SendData.setOnClickListener(view -> {
            if (typeLocation.equals("origin")) {
                if (originLatLon == null && originMarker == null) {
                    MySnackBar.ShowCustomWarning(view, "مبدا مورد نظر را روی نقشه مشخص کنید");
                } else {
                    getAddress(originLatLon.latitude, originLatLon.longitude, view);

                }

            } else {
                if (destinationLatLon == null && destinationMarker == null) {
                    MySnackBar.ShowCustomWarning(view, "مقصد مورد نظر را روی نقشه مشخص کنید");
                } else {
                    getAddress(destinationLatLon.latitude, destinationLatLon.longitude, view);

                }
            }

        });

        fb_back.setOnClickListener(view -> onBackPressed());

        fb_location.setOnClickListener(view -> {
            if (GpsTracker.isLocationEnable(context, 33))
                setLocation();
        });

        search.setOnClickListener(view -> getLocation(Objects.requireNonNull(address.getText()).toString()));
    }

    private void getLocation(String query) {
        Geocoding request = new Geocoding();
        request.setStrAddress(query);
        APIClient.getClient().create(APIService.class).Geocoding(request).enqueue(new Callback<Geocoding>() {
            @Override
            public void onResponse(@NonNull Call<Geocoding> call, @NonNull Response<Geocoding> response) {
                if (response.isSuccessful() && response.body() != null) {
                    zoomToLocation(response.body());
                    addPin(response.body());
                }
            }

            @Override
            public void onFailure(@NonNull Call<Geocoding> call, @NonNull Throwable t) {
                Log.d(TAG, "onFailure: " + t.getMessage());
            }
        });
    }

    private void addPin(Geocoding body) {
        if (mLat != null && mLong != null && mLat != 0 && mLong != 0) {

            if (typeLocation.equals("origin")) {
                mMap.clear();
                originLatLon = new LatLng(body.getfLat(), body.getfLon());
                App.originLat = (float) originLatLon.latitude;
                App.originLon = (float) originLatLon.longitude;
                originLat = (float) originLatLon.latitude;
                originLon = (float) originLatLon.longitude;

                originMarker = mMap.addMarker(new MarkerOptions().position(originLatLon)
                        .icon(BitmapDescriptorFactory.fromBitmap(MyClass.getResizedBitmap(
                                MyClass.getBitmapFromVectorDrawable(context, R.drawable.origin)
                                , 192, 128))).rotation(0));

                originMarker.showInfoWindow();
                originMarker.setTag("مبدا");


            } else if (typeLocation.equals("destination")) {
                mMap.clear();
                destinationLatLon = new LatLng(body.getfLat(), body.getfLon());
                App.destinationLat = (float) destinationLatLon.latitude;
                App.destinationLon = (float) destinationLatLon.longitude;
                destinationLat = (float) destinationLatLon.latitude;
                destinationLon = (float) destinationLatLon.longitude;

                destinationMarker = mMap.addMarker(new MarkerOptions().position(destinationLatLon)
                        .icon(BitmapDescriptorFactory.fromBitmap(MyClass.getResizedBitmap(
                                MyClass.getBitmapFromVectorDrawable(context, R.drawable.destination)
                                , 192, 128))).rotation(0));

                destinationMarker.showInfoWindow();
                destinationMarker.setTag("مقصد");

            }
        }
    }

    private void zoomToLocation(Geocoding body) {
        mMap.animateCamera(CameraUpdateFactory.newCameraPosition(new CameraPosition(new LatLng(body.getfLat(), body.getfLon()), 15, 0, 0)));
    }

    private void getAddress(double Lat, double Lon, View view) {
        ////Salar
        ////sendGeoCodeRequest
        Geocoding geoCodeing = new Geocoding();
        geoCodeing.setfLat(Lat);
        geoCodeing.setfLon(Lon);

        APIService apiService = APIClient.getClient().create(APIService.class);
        Call<Geocoding> call = apiService.ReverseGeocoding(geoCodeing);
        call.enqueue(new Callback<Geocoding>() {
            @Override
            public void onResponse(@NonNull Call<Geocoding> call, @NonNull Response<Geocoding> response) {
                if (response.code() == 200) {
                    App.Geo = response.body();
                    requestSetLocation();
                    finish();
                } else {
                    //   changePassResult(-4);
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            MySnackBar.ShowCustomWarning(view, "خطا در برقراری ارتباط با سرور");
                        }
                    });

                }

            }

            @Override
            public void onFailure(@NonNull Call<Geocoding> call, @NonNull Throwable t) {
                //changePassResult(-5);
                //   changePassResult(-4);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        MySnackBar.ShowCustomWarning(view, "خطا در برقراری ارتباط با سرور");
                    }
                });
            }
        });
    }

    private void initViews() {
        Bundle bundle = getIntent().getExtras();
        typeLocation = bundle.getString("typeLocation");

        btn_SendData = findViewById(R.id.btn_SendData);
        pbRegisterTrip = findViewById(R.id.pbRegisterTrip);
        fb_location = findViewById(R.id.fb_location);
        fb_back = findViewById(R.id.fb_back);
        tv_type = findViewById(R.id.tv_type);
        address = findViewById(R.id.address);
        search = findViewById(R.id.search);

        if (typeLocation.equals("origin")) {
            tv_type.setText("مبدا");
            btn_SendData.setText("تایید مبدا");
        } else {
            tv_type.setText("مقصد");
            btn_SendData.setText("تایید مقصد");
        }

        address.setText(App.address);
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @SuppressLint("UseCompatLoadingForDrawables")
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        UiSettings mUiSettings = mMap.getUiSettings();
        mUiSettings.setZoomControlsEnabled(false);
        mUiSettings.setScrollGesturesEnabled(true);
        mUiSettings.setZoomGesturesEnabled(true);
        mUiSettings.setMyLocationButtonEnabled(false);
        mUiSettings.setIndoorLevelPickerEnabled(false);

        enableMyLocationIfPermitted();

        // default location IRAN
        CameraUpdate center = CameraUpdateFactory.newLatLngZoom(new LatLng(mLat, mLong), 5);
        CameraUpdate zoom = CameraUpdateFactory.zoomTo(5);
        mMap.moveCamera(center);
        mMap.animateCamera(zoom);

        mLat = null;
        mLong = null;

        locationManager = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);
        boolean gps_enabled = false;
        boolean network_enabled = false;

        try {
            gps_enabled = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
        } catch (Exception ignored) {
        }

        try {
            network_enabled = locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
        } catch (Exception ignored) {
        }

        if (MyLocation.isLocationEnable(context, 33)) {

            if (gps_enabled && network_enabled) {

                if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                        != PackageManager.PERMISSION_GRANTED
                        && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION)
                        != PackageManager.PERMISSION_GRANTED) {

                    return;
                }

                Location locationGPS = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);

                if (locationGPS != null) {
                    mLat = locationGPS.getLatitude();
                    mLong = locationGPS.getLongitude();

                    CameraPosition newCamPos = new CameraPosition(new LatLng(mLat, mLong),
                            15,
                            mMap.getCameraPosition().tilt,
                            mMap.getCameraPosition().bearing);
                    mMap.moveCamera(CameraUpdateFactory.newCameraPosition(newCamPos));
                }
            }
        }

        mMap.isMyLocationEnabled();

        mMap.setOnMapClickListener(point -> {
            if (ActivityCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION)
                    != PackageManager.PERMISSION_GRANTED
                    && ActivityCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION)
                    != PackageManager.PERMISSION_GRANTED) {
                return;
            }
            try {
                if (selectLocation != null)
                    selectLocation.remove();
                mMap.setMyLocationEnabled(true);

                float mZoom = mMap.getCameraPosition().zoom;
                if (mZoom < 16)
                    mZoom = 17;

                mLat = point.latitude;
                mLong = point.longitude;

                if (mLat != null && mLong != null && mLat != 0 && mLong != 0) {

                    if (typeLocation.equals("origin")) {
                        mMap.clear();
                        originLatLon = point;
                        App.originLat = (float) point.latitude;
                        App.originLon = (float) point.longitude;
                        originLat = (float) point.latitude;
                        originLon = (float) point.longitude;

                        originMarker = googleMap.addMarker(new MarkerOptions().position(point)
                                .icon(BitmapDescriptorFactory.fromBitmap(MyClass.getResizedBitmap(
                                        MyClass.getBitmapFromVectorDrawable(context, R.drawable.origin)
                                        , 192, 128))).rotation(0));

                        originMarker.showInfoWindow();
                        originMarker.setTag("مبدا");


                    } else if (typeLocation.equals("destination")) {
                        mMap.clear();
                        destinationLatLon = point;
                        App.destinationLat = (float) point.latitude;
                        App.destinationLon = (float) point.longitude;
                        destinationLat = (float) point.latitude;
                        destinationLon = (float) point.longitude;

                        destinationMarker = googleMap.addMarker(new MarkerOptions().position(point)
                                .icon(BitmapDescriptorFactory.fromBitmap(MyClass.getResizedBitmap(
                                        MyClass.getBitmapFromVectorDrawable(context, R.drawable.destination)
                                        , 192, 128))).rotation(0));

                        destinationMarker.showInfoWindow();
                        destinationMarker.setTag("مقصد");

                    }
                    CameraPosition newCamPos = new CameraPosition(new LatLng(mLat, mLong),
                            mZoom,
                            mMap.getCameraPosition().tilt,
                            mMap.getCameraPosition().bearing);
                    mMap.animateCamera(CameraUpdateFactory.newCameraPosition(newCamPos), 1500, null);
                }

            } catch (Exception ignored) {
            }
        });

    }

    private void requestSetLocation() {
        if (typeLocation.equals("origin"))
            callDistance(originLatLon, originLatLon, mMap);
        else if (typeLocation.equals("destination"))
            callDistance(destinationLatLon, destinationLatLon, mMap);
    }

    class secondTask extends TimerTask {
        @Override
        public void run() {
            runOnUiThread(() -> {
                setLocation();
                if (mLat != null) {
                    timer.cancel();
                }
            });
        }
    }

    public void gettingLocation() {
        timer.schedule(new secondTask(), 1000, 1500);
    }

    public void hidePreogressBar() {
        pbRegisterTrip.setVisibility(View.GONE);
        btn_SendData.setVisibility(View.VISIBLE);
    }

    public void setLocation() {
        GpsTracker gpsTracker = new GpsTracker(this);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION)
                        == PackageManager.PERMISSION_GRANTED) {

            float mZoom = mMap.getCameraPosition().zoom;
            if (mZoom < 16)
                mZoom = 17;

            if (selectLocation != null)
                selectLocation.remove();

            double latitude = gpsTracker.getLatitude();
            double longitude = gpsTracker.getLongitude();

            if (latitude != 0 && longitude != 0) {
                mLat = latitude;
                mLong = longitude;

                CameraPosition newCamPos = new CameraPosition(new LatLng(mLat, mLong),
                        mZoom, mMap.getCameraPosition().tilt, mMap.getCameraPosition().bearing);
                mMap.moveCamera(CameraUpdateFactory.newCameraPosition(newCamPos));
            }
        }
    }

    private void enableMyLocationIfPermitted() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION
                    , Manifest.permission.ACCESS_FINE_LOCATION}, LOCATION_PERMISSION_REQUEST_CODE);
        } else if (mMap != null) {
            mMap.setMyLocationEnabled(true);
        }

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                setLocation();
            }
        }
    }

    @Override
    public void onBackPressed() {
        finish();
        timer.cancel();
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
    }
}