package com.rayanandisheh.peysepar.passenger.view.Activity;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Location;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.NumberPicker;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.UiSettings;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.rayanandisheh.peysepar.passenger.R;
import com.rayanandisheh.peysepar.passenger.view.Adapter.AddTripAdapter;
import com.rayanandisheh.peysepar.passenger.helpers.App;
import com.rayanandisheh.peysepar.passenger.helpers.Cache;
import com.rayanandisheh.peysepar.passenger.helpers.PermissionHelper;
import com.rayanandisheh.peysepar.passenger.helpers.PersianAppcompatActivity;
import com.rayanandisheh.peysepar.passenger.helpers.Time;
import com.rayanandisheh.peysepar.passenger.helpers.Toaster;
import com.rayanandisheh.peysepar.passenger.models.TripInsert;
import com.rayanandisheh.peysepar.passenger.models.TripSAD;
import com.rayanandisheh.peysepar.passenger.services.APIClient;
import com.rayanandisheh.peysepar.passenger.services.APIService;
import com.rayanandisheh.peysepar.passenger.services.LocationService;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import ir.hamsaa.persiandatepicker.Listener;
import ir.hamsaa.persiandatepicker.PersianDatePickerDialog;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class InsertTripActivity extends PersianAppcompatActivity implements
        AddTripAdapter.OnItemClickListener, OnMapReadyCallback {

    Context context;
    TextView txtTimePicker;
    Spinner spnReason, spnImportance, spnCarType;
    Button btnRegisterTrip;
    ProgressBar pbRegisterTrip;
    Toolbar toolbar;
    RelativeLayout rlACtextDes;
    LinearLayout rlTextDes;
    AutoCompleteTextView autoCompleteTxtOrigin, autoCompleteTxtDes;
    EditText edtDate, edtEnterNamePassenges, edtCommentAddTrip;
    ImageView imgAddPassengers;
    RecyclerView rvAddPassenges;
    LinearLayoutManager linearLayoutManager;
    AddTripAdapter myRecyclerViewAdapter;
    CardView cvMap;
    LinearLayout LinearPredefined;
    CheckBox chkBoxInService;
    ImageView ivWarningOrigin;
    ImageView ivWarningDes;
    ImageView ivWarningTripReason;
    ImageView ivWarningTripImportance;
    CheckBox chkBxReturn;
    CheckBox chkBxMissionary;
    NumberPicker npHour, npMin;
    Calendar calander;
    private String date;
    private PersianDatePickerDialog picker;
    String numberPickerTime;

    private int iTripS_SAD = -1;
    private int iTripD_SAD = -1;

    private GoogleMap mMap;
    private UiSettings mUiSettings;
    Marker selectLocation;
    Boolean bln_selected = false;
    public static Boolean bln_map = false;
    Double mLat = null;
    Double mLong = null;
    String latLon;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_insert_trip);
        context = this;
        //getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        bindView();
        setSpnReasonData(getSpnReasonData());
        setSpnImportanceData(getImportanceData());
        setOriginDes(getOriginDes());
        setSpnCarType(getSpnTypeCar());

        initializeRecyclerViewAddPassengers();

        if (MainActivity.chooseIcon.equals("Predefined")) {

            cvMap.setVisibility(View.GONE);
            LinearPredefined.setVisibility(View.VISIBLE);

        } else if (MainActivity.chooseIcon.equals("Map")) {
            cvMap.setVisibility(View.VISIBLE);
            LinearPredefined.setVisibility(View.INVISIBLE);

            startService(new Intent(context, LocationService.class));

            SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.FRAGMENT_MAP);
            if (mapFragment != null)
                mapFragment.getMapAsync(this);
        }

        chkBxReturn.setOnCheckedChangeListener((buttonView, isChecked) -> {
            chkBoxInService.setChecked(false);
            chkBxMissionary.setChecked(false);
        });

        chkBoxInService.setOnCheckedChangeListener((v, isChecked) -> {
            chkBxReturn.setChecked(false);
            chkBxMissionary.setChecked(false);
            chkInServiceChecked(isChecked);
        });

        chkBxMissionary.setOnCheckedChangeListener((buttonView, isChecked) -> {
            chkBxReturn.setChecked(false);
            chkBoxInService.setChecked(false);
        });

        edtDate.setOnClickListener(v -> cvCalandarPressed(edtDate));
        btnRegisterTrip.setOnClickListener(v -> getSelectedTime());

        spinnerTripReasonPressed(spnReason);

        spinnerTripImportancePressed(spnImportance);

        autoCompleteTxtDes.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.length() == 0)
                    ivWarningDes.setVisibility(View.VISIBLE);
                else
                    ivWarningDes.setVisibility(View.GONE);
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        autoCompleteTxtOrigin.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.length() == 0)
                    ivWarningOrigin.setVisibility(View.VISIBLE);
                else
                    ivWarningOrigin.setVisibility(View.GONE);

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

    }

    private void bindView() {

        chkBoxInService = findViewById(R.id.chkBxAvailable);
        ivWarningOrigin = findViewById(R.id.ivWarningOrigin);
        ivWarningDes = findViewById(R.id.ivWarningDes);
        ivWarningTripReason = findViewById(R.id.ivWarningTripReason);
        ivWarningTripImportance = findViewById(R.id.ivWarningTripImportance);
        chkBxReturn = findViewById(R.id.chkBxReturn);
        chkBxMissionary = findViewById(R.id.chkBxMissionary);

        toolbar = findViewById(R.id.toolbar_add_trip);
        cvMap = findViewById(R.id.cvMap2);
        LinearPredefined = findViewById(R.id.LinearPredefined);

        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        setTitle("افزودن سفر");

//        txtApplicantName = findViewById(R.id.txtapplicantNameRegisterTrip);
        edtDate = findViewById(R.id.edtDateRegisterTrip);
        edtDate.setText(Time.getNowPersianDate());

//        txtMobile = findViewById(R.id.txtMobileRegisterTrip);
        spnReason = findViewById(R.id.spinnerReason);
        spnImportance = findViewById(R.id.spinnerImportance);
        pbRegisterTrip = findViewById(R.id.pbRegisterTrip);
        btnRegisterTrip = findViewById(R.id.btnRegisterTrip);

        rlTextDes = findViewById(R.id.rlTextDes);
        rlACtextDes = findViewById(R.id.rlACtextDes);

        autoCompleteTxtOrigin = findViewById(R.id.autoCompleteTxtOrigin);
        autoCompleteTxtDes = findViewById(R.id.autoCompleteTxtDes);

        edtEnterNamePassenges = findViewById(R.id.edtEnterNamePassenges);
        imgAddPassengers = findViewById(R.id.imgAdd);
        rvAddPassenges = findViewById(R.id.recyclerViewAddPassengers);


        npHour = findViewById(R.id.npHour);
        npMin = findViewById(R.id.npMin);
        calander = Calendar.getInstance();
        npHour.setMinValue(0);
        npHour.setMaxValue(23);
        npHour.setFormatter(new NumberPicker.Formatter() {
            @Override
            public String format(int i) {
                return String.format("%02d", i);
            }
        });
        npHour.setValue(calander.get(Calendar.HOUR_OF_DAY));


        npMin.setMinValue(0);
        npMin.setMaxValue(59);
        npMin.setFormatter(new NumberPicker.Formatter() {
            @Override
            public String format(int i) {
                return String.format("%02d", i);
            }
        });
        npMin.setValue(calander.get(Calendar.MINUTE));


        spnCarType = findViewById(R.id.spinnerCarType);

        edtCommentAddTrip = findViewById(R.id.edtCommentAddTrip);


    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void initializeRecyclerViewAddPassengers() {
        linearLayoutManager = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);
        myRecyclerViewAdapter = new AddTripAdapter(this);
        myRecyclerViewAdapter.setOnItemClickListener(this);
        rvAddPassenges.setAdapter(myRecyclerViewAdapter);
        rvAddPassenges.setLayoutManager(linearLayoutManager);

        imgAddPassengers.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                String newName = edtEnterNamePassenges.getText().toString();
                if (!newName.equals("")) {
                    if (myRecyclerViewAdapter.getItemCount() > 1) {
                        myRecyclerViewAdapter.add(0, newName);
                        edtEnterNamePassenges.setText("");
                    } else {
                        myRecyclerViewAdapter.add(0, newName);
                        edtEnterNamePassenges.setText("");
                    }
                }
            }
        });
    }

    public List<String> getSpnReasonData() {
        List<String> reasons = new ArrayList<>();
        for (int i = 0; i < App.userInfo.getTripReason().size(); i++)
            reasons.add(App.userInfo.getTripReason().get(i).getStrComment());
        return reasons;
    }

    public void setSpnReasonData(List<String> spnReasonData) {
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(context, android.R.layout.simple_spinner_item, spnReasonData);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spnReason.setAdapter(dataAdapter);
    }

    public List<String> getImportanceData() {
        List<String> importance = new ArrayList<>();
        for (int i = 0; i < App.userInfo.getTripImportance().size(); i++)
            importance.add(App.userInfo.getTripImportance().get(i).getStrComment());
        return importance;
    }

    public void setSpnImportanceData(List<String> importanceData) {
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(context, android.R.layout.simple_spinner_item, importanceData);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spnImportance.setAdapter(dataAdapter);
    }

    public List<String> getOriginDes() {
        List<String> originDes = new ArrayList<String>();
        for (int i = 0; i < App.userInfo.getTripSAD().size(); i++)
            originDes.add(App.userInfo.getTripSAD().get(i).getStrName());
        return originDes;
    }

    public void setOriginDes(List<String> originDes) {
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(context, R.layout.select_dialog_item_custom, originDes);
        autoCompleteTxtOrigin.setThreshold(1);
        autoCompleteTxtOrigin.setAdapter(adapter);
        autoCompleteTxtDes.setThreshold(1);
        autoCompleteTxtDes.setAdapter(adapter);
    }

    public List<String> getSpnTypeCar() {
        List<String> cartype = new ArrayList<>();
        for (int i = 0; i < App.userInfo.getMobileType().size(); i++)
            cartype.add(App.userInfo.getMobileType().get(i).getStrComment());
        return cartype;
    }

    public void setSpnCarType(List<String> spnTypeCar) {
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(context, android.R.layout.simple_spinner_item, spnTypeCar);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spnCarType.setAdapter(dataAdapter);
    }

    public void chkInServiceChecked(boolean chkInServiceisChecked) {

        if (chkInServiceisChecked)
            HideDestination();
        else
            showDestination();
    }

    public void HideDestination() {

        rlACtextDes.setVisibility(View.GONE);
        rlTextDes.setVisibility(View.GONE);
    }

    public void showDestination() {
        rlACtextDes.setVisibility(View.VISIBLE);
        rlTextDes.setVisibility(View.VISIBLE);
    }

    public void cvCalandarPressed(EditText edtDate) {

        final InputMethodManager imm = (InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.showSoftInput(edtDate, InputMethodManager.SHOW_IMPLICIT);

//        PersianCalendar initDate = new PersianCalendar();
//        initDate.setPersianDate(1370, 3, 13);

        picker = new PersianDatePickerDialog(context)
                .setPositiveButtonString("تایید")
                .setNegativeButton("انصراف")
                .setTodayButton("امروز")
                .setTodayButtonVisible(true)
                .setMinYear(1300)
                .setMaxYear(1450)
//                .setMaxYear(PersianDatePickerDialog.THIS_YEAR)
//                .setInitDate(initDate)
                .setActionTextColor(Color.GRAY)
//                .setTypeFace(typeface)
                .setListener(new Listener() {
                    @Override
                    public void onDateSelected(ir.hamsaa.persiandatepicker.util.PersianCalendar persianCalendar) {

//                        date = persianCalendar.getPersianYear() + "/"
//                                + persianCalendar.getPersianMonth() + "/"
//                                + persianCalendar.getPersianDay();

                        date = persianCalendar.getPersianYear() + "/" +
                                (String.valueOf(persianCalendar.getPersianMonth()).length() < 2 ? "0" + persianCalendar.getPersianMonth() : persianCalendar.getPersianMonth()) + "/" +
                                (String.valueOf(persianCalendar.getPersianDay()).length() < 2 ? "0" + persianCalendar.getPersianDay() : persianCalendar.getPersianDay());


//                             Toast.makeText(context, date, Toast.LENGTH_SHORT).show();
                        edtDate.setText(date);
                    }

                    @Override
                    public void onDismissed() {
                    }
                });
        picker.show();

    }

    private void getSelectedTime() {

        if (!autoCompleteTxtOrigin.getText().toString().isEmpty()
                && (!autoCompleteTxtDes.getText().toString().isEmpty() || chkBoxInService.isChecked())) {

            numberPickerTime = (String.format("%s:%s", String.valueOf(npHour.getValue()).length() < 2 ? "0" + npHour.getValue() : npHour.getValue(),
                    String.valueOf(npMin.getValue()).length() < 2 ? "0" + npMin.getValue() : npMin.getValue()));
//            txtTimePicker.setText(numberPickerTime);

            btnPressed(
                    spnReason.getSelectedItemPosition(), spnImportance.getSelectedItemPosition(),
                    spnCarType.getSelectedItemPosition(),
                    autoCompleteTxtOrigin.getText().toString(), autoCompleteTxtDes.getText().toString(),
                    edtDate.getText().toString(), numberPickerTime, chkBoxInService.isChecked(),
                    chkBxReturn.isChecked(), chkBxMissionary.isChecked(), myRecyclerViewAdapter.getList(), edtCommentAddTrip.getText().toString());

        } else {
            if (edtCommentAddTrip.getText().toString().isEmpty()) {
                Toast.makeText(context, "پرکردن فیلد توضیحات سفر الزامی می باشد", Toast.LENGTH_SHORT).show();
            } else
                Toast.makeText(context, "آدرس می بایست مشخص گردد", Toast.LENGTH_SHORT).show();

        }
    }

    public void btnPressed(int spnReason, int spnImportance, int spnCarType, String autoCompleteTxtOrigin,
                           String autoCompleteTxtDes, String edtDate, String numberPickerTime, boolean chkBoxInService,
                           boolean chkBxReturn, boolean chkBxMissionary, String list, String strComment) {

        showProgressBar();
        requestAddTrip(spnReason, spnImportance, spnCarType, autoCompleteTxtOrigin,
                autoCompleteTxtDes, edtDate, numberPickerTime, chkBoxInService, chkBxReturn, chkBxMissionary, list, strComment);

    }

    public void showProgressBar() {
        pbRegisterTrip.setVisibility(View.VISIBLE);
        btnRegisterTrip.setVisibility(View.GONE);
    }

    public void requestAddTrip(int spnReason, int spnImportance, int spnCarType
            , String autoCompleteTxtOrigin, String autoCompleteTxtDes, String edtDate
            , String numberPickerTime, boolean chkBoxInService, boolean chkBxReturn
            , boolean chkBxMissionary, String list, String strComment) {
        TripInsert tripInsert = new TripInsert();
        tripInsert.setTiTripReason((short) App.userInfo.getTripReason().get(spnReason).getTiTripReason());
        tripInsert.setTiTripImportance((short) App.userInfo.getTripImportance().get(spnImportance).getTiTripImportance());
        tripInsert.setMobileType((short) App.userInfo.getMobileType().get(spnCarType).getTiMobileType());

        tripInsert.setStrComment(strComment);

        tripInsert.setStrTripDate(edtDate);
        tripInsert.setStrTripTime(numberPickerTime);

        tripInsert.setbHaveReturn(chkBxReturn);
        tripInsert.setbExclusive(chkBoxInService);
        tripInsert.setbMissionary(chkBxMissionary);

        tripInsert.setStrApplicantMobile(Cache.getString("mobileNumber"));
        tripInsert.setStrPassengersName(list);

        for (TripSAD tripSAD : App.userInfo.getTripSAD()) {
            if (autoCompleteTxtOrigin.equals(tripSAD.getStrName())) {
                tripInsert.setiTripSADSource(tripSAD.getiTripSad());
            }
        }

        if (tripInsert.getiTripSADSource() == -1) {
            noValidOrigin();
            return;
        }

        for (TripSAD tripSAD : App.userInfo.getTripSAD()) {
            if (autoCompleteTxtDes.equals(tripSAD.getStrName())) {
//                tripSAD.getiTripSad();
                tripInsert.setiTripSADDestination(tripSAD.getiTripSad());
            }

        }
        if (!chkBoxInService && tripInsert.getiTripSADDestination() == -1) {
            noValidDes();
            return;
        }

        if (tripInsert.getiTripSADSource() == tripInsert.getiTripSADDestination()) {
            ErrorEqualOriginDestination();
            return;
        }

        APIService apiService = APIClient.getClient().create(APIService.class);
        Call<Integer> call = apiService.InsertTrip(tripInsert, iTripS_SAD, iTripD_SAD,App.Session);
        call.enqueue(new Callback<Integer>() {
            @Override
            public void onResponse(@NotNull Call<Integer> call, @NotNull Response<Integer> response) {
                if (response.code() == 200 && response.body() != null) {
                    tripInsertResult(response.body());
                    App.pursuitCode = response.body();

                } else {
                    tripInsertResult(-4);
                }
            }

            @Override
            public void onFailure(@NotNull Call<Integer> call, @NotNull Throwable t) {
                tripInsertResult(-1);
            }
        });
    }

    public void noValidOrigin() {
        Toaster.shorter("آدرس مبدا می بایست از موارد پیشنهادی انتخاب گردد");
        hidePreogressBar();
    }

    public void hidePreogressBar() {
        pbRegisterTrip.setVisibility(View.GONE);
        btnRegisterTrip.setVisibility(View.VISIBLE);
        stopService(new Intent(context,LocationService.class));
    }

    public void noValidDes() {

        Toaster.shorter("آدرس مقصد می بایست از موارد پیشنهادی انتخاب گردد");
        hidePreogressBar();

    }

    public void ErrorEqualOriginDestination() {
        Toaster.shorter("مبدا و مقصد نباید یکسان انتخاب گردند");
        hidePreogressBar();
    }

    public void tripInsertResult(Integer result) {

        hidePreogressBar();

        if (result == -4) {
            Toaster.shorter(context.getString(R.string.serverFaield));
        } else if (result == -1) {
            Toaster.shorter(context.getString(R.string.connectionFaield));
        } else if (result == 0) {
            Toaster.shorter("سفر شما قبلا ثبت شده است");
        } else if (result == -2) {
            Toaster.shorter("بازه ی زمانی درخواست شما به پایان رسیده است،لطفا در بازه مجاز اقدام به ثبت درخواست نمایید");
        }
        else if (result == 100) {
            Intent intent=new Intent(InsertTripActivity.this, LoginActivity.class);
            startActivity(intent);

        }
        else {
//            Toast.makeText(context, "کد رهگیری شما" + result, Toast.LENGTH_SHORT).show();
            Toaster.shorter("سفر شما با موفقیت ثبت شد");

            context.startActivity(new Intent(context, MainActivity.class));
            ((Activity) context).finish();
        }

    }

    public void spinnerTripReasonPressed(Spinner spnReason) {

        spnReason.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View v, int position, long id) {
                String item = parent.getItemAtPosition(position).toString();
                if (item.equals("انتخاب کنید")) {
                    showIvWarningReason();
                } else {
                    hideIvWarningReason();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

    }

    public void spinnerTripImportancePressed(Spinner spnImportance) {

        spnImportance.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View v, int position, long id) {
                String item = parent.getItemAtPosition(position).toString();
                if (item.equals("انتخاب کنید")) {
                    showIvWarningImportance();
                } else {
                    hideIvWarningImportance();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

    }

    public void showIvWarningReason() {
        ivWarningTripReason.setVisibility(View.VISIBLE);
    }

    public void hideIvWarningReason() {
        ivWarningTripReason.setVisibility(View.GONE);
    }

    public void showIvWarningImportance() {
        ivWarningTripImportance.setVisibility(View.VISIBLE);
    }

    public void hideIvWarningImportance() {
        ivWarningTripImportance.setVisibility(View.GONE);
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        mUiSettings = mMap.getUiSettings();
        mUiSettings.setZoomControlsEnabled(true);
        mUiSettings.setScrollGesturesEnabled(true);
        mUiSettings.setZoomGesturesEnabled(true);
        //mUiSettings.isMapToolbarEnabled();
        mUiSettings.isTiltGesturesEnabled();


        if (ActivityCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            mMap.setMyLocationEnabled(true);
        } else {
            PermissionHelper.RequestPermissionLOCATION(this);
            mMap.setMyLocationEnabled(false);
        }

//        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
//            return;
//        }
//        mMap.setMyLocationEnabled(true);

        CameraPosition newCamPos = new CameraPosition(new LatLng(35.6907, 51.3987),
                12,
                mMap.getCameraPosition().tilt, //use old tilt
                mMap.getCameraPosition().bearing); //use old bearing
        mMap.animateCamera(CameraUpdateFactory.newCameraPosition(newCamPos), 1000, null);

        mLat = null;
        mLong = null;

        mMap.isMyLocationEnabled();



        mMap.setOnMapClickListener(new GoogleMap.OnMapClickListener() {
            @Override
            public void onMapClick(LatLng point) {
                if (ActivityCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                        && ActivityCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    return;
                }
                try {
                    selectLocation.remove();
                    mMap.setMyLocationEnabled(true);
                    float mZoom = mMap.getCameraPosition().zoom;
                    if (mZoom < 16) mZoom = 15;
                    mLat = point.latitude;
                    mLong = point.longitude;


                    CameraPosition newCamPos = new CameraPosition(new LatLng(mLat, mLong),
                            mZoom,
                            mMap.getCameraPosition().tilt, //use old tilt
                            mMap.getCameraPosition().bearing); //use old bearing
                    mMap.animateCamera(CameraUpdateFactory.newCameraPosition(newCamPos), 1500, null);

                    selectLocation = mMap.addMarker(new MarkerOptions()
                            .position(point)
                            .icon(BitmapDescriptorFactory.fromResource(R.drawable.ic_origin_marker))
                            .title("محل انتخابی"));
                } catch (Exception ignored) {
                }
            }
        });

        mMap.setOnMapLongClickListener(new GoogleMap.OnMapLongClickListener() {
            @Override
            public void onMapLongClick(LatLng point) {
            }
        });

        mMap.setOnMyLocationButtonClickListener(new GoogleMap.OnMyLocationButtonClickListener() {
            @Override
            public boolean onMyLocationButtonClick() {
                setLocation();
                return false;
            }
        });

    }


    public void setLocation() {

        try {
            if (selectLocation != null) {
                selectLocation.remove();
            }

            Location location = mMap.getMyLocation();
            mLat = location.getLatitude();
            mLong = location.getLongitude();

            float mZoom = mMap.getCameraPosition().zoom;
            if (mZoom < 16) mZoom = 15;

            CameraPosition newCamPos = new CameraPosition(new LatLng(mLat, mLong),
                    mZoom,
                    mMap.getCameraPosition().tilt, //use old tilt
                    mMap.getCameraPosition().bearing); //use old bearing
            mMap.animateCamera(CameraUpdateFactory.newCameraPosition(newCamPos), 1500, null);

            selectLocation = mMap.addMarker(new MarkerOptions()
                    .position(new LatLng(mLat, mLong))
                    .icon(BitmapDescriptorFactory.fromResource(R.drawable.ic_origin_marker))
                    .title("مبدا"));
        } catch (Exception ignored) {

        }
    }


    @Override
    public void onItemClick(AddTripAdapter.ItemHolder item, int position) {

    }
}
