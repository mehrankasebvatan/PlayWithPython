package com.rayanandisheh.peysepar.passenger.view;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.coordinatorlayout.widget.CoordinatorLayout;

import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.rayanandisheh.peysepar.passenger.R;

public class BottomSheetRequestHelp extends BottomSheetDialogFragment implements View.OnClickListener {

    private static final String TAG = "BottomSheetSelectCustomer";
    private View view;
    private Context context;
    private int id;
    public Activity m_activity;
        private EditText et_address;
//    private TextView txt_map_insertTrip;
    public OnClickSheet onClickSheet;
    private String origin;

    public BottomSheetRequestHelp(Context context, String origin, OnClickSheet onClickSheet) {
        this.context = context;
        this.origin = origin;
        this.onClickSheet = onClickSheet;
    }

    @SuppressLint("InflateParams")
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container
            , @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.bottomsheet_request_help, null);
        if (getDialog().getWindow() != null) {
            getDialog().getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        }
        setViews();
        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        context = getContext();
//        setCancelable(false);

    }

    private void setViews() {
        et_address = view.findViewById(R.id.et_address);
//        txt_map_insertTrip = view.findViewById(R.id.txt_map_insertTrip);

        et_address.setText(origin);
//        txt_normal_insertTrip.setOnClickListener(this);
//        txt_map_insertTrip.setOnClickListener(this);
    }

    public interface OnClickSheet {
        void onClickNormal();

        void onClickMap();
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.txt_normal_insertTrip:
                onClickSheet.onClickNormal();
                dismiss();
                break;
            case R.id.txt_map_insertTrip:
                onClickSheet.onClickMap();
                dismiss();
                break;
        }
    }
}
