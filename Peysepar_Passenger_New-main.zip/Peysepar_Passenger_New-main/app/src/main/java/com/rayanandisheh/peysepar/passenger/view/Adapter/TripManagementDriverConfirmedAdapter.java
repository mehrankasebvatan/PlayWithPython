package com.rayanandisheh.peysepar.passenger.view.Adapter;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.rayanandisheh.peysepar.passenger.R;
import com.rayanandisheh.peysepar.passenger.helpers.Time;
import com.rayanandisheh.peysepar.passenger.models.Trip;
import com.rayanandisheh.peysepar.passenger.view.Activity.MapsActivityTabLayout;

import java.util.List;

public class TripManagementDriverConfirmedAdapter extends RecyclerView.Adapter<TripManagementDriverConfirmedAdapter.ViewHolder> {

    private List<Trip> modelWaitingDriverFragments;
    private Context context;
    String todayDate;

    public interface onClick {
        void cancelWaitingDriverConfirmedAlertTripManagement(int iOfficialTrip, int tiTripStatus);

        void tripsArchive(int iOfficialTrip);
    }

    onClick onClick;

    public TripManagementDriverConfirmedAdapter(List<Trip> modelWaitingDriverFragments, Context context, onClick onClick) {
        this.modelWaitingDriverFragments = modelWaitingDriverFragments;
        this.context = context;
        this.onClick = onClick;
    }

    public void clear() {
        modelWaitingDriverFragments.clear();
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public TripManagementDriverConfirmedAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View viewNewFragment = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_trip_new_fragment1, parent, false);
        return new ViewHolder(viewNewFragment);
    }

    @Override
    public void onBindViewHolder(@NonNull TripManagementDriverConfirmedAdapter.ViewHolder holder, int position) {
        todayDate = Time.getNowPersianDate();
        Trip model = modelWaitingDriverFragments.get(position);
        holder.txt_persuadeCode.setText(String.valueOf(model.getiOfficialTrip()));
        holder.txt_applicantName.setText(model.getStrApplicantName() + " " + model.getStrApplicantFamily());
        holder.txt_tripReason.setText("سفر " + model.getStrTripReason_strComment());
        holder.txt_requestDate.setText(model.getStrTripDate() + " _ " + model.getStrRequestTime());
        holder.txt_supposeDate.setText(model.getStrTripDate() + " _ " + model.getStrTripTime());
        holder.txt_originAddress.setText(model.getStrOriginAddress());
        holder.txt_desAddress.setText(model.getStrDestinationAddress());
//        holder.txt_originAddress.setText(model.getStrOriginName()+" , "+model.getStrOriginAddress());
//        holder.txt_desAddress.setText(model.getStrDestinationName()+" , "+model.getStrDestinationAddress());
//        holder.txt_applicantPhone.setText(model.getStrApplicantMobile());

        try {
            holder.tv_TripImportanceNewFragment.setText(model.getStrTripImportance_strComment());
            if (model.getStrTripImportance_strComment() != null) {
                switch (model.getStrTripImportance_strComment()) {
                    case "عادی":
                        holder.tv_TripImportanceNewFragment.setBackground(ContextCompat.getDrawable(context, R.drawable.shape_circle_normal));
                        holder.tv_TripImportanceNewFragment.setTextColor(context.getResources().getColor(R.color.colorText));
                        break;
                    case "فوری":
                        holder.tv_TripImportanceNewFragment.setBackground(ContextCompat.getDrawable(context, R.drawable.shape_circle_urgent));
                        holder.tv_TripImportanceNewFragment.setTextColor(context.getResources().getColor(R.color.colorOrenge));
                        break;
                    case "خیلی فوری":
                        holder.tv_TripImportanceNewFragment.setBackground(ContextCompat.getDrawable(context, R.drawable.shape_circle_very_urgent));
                        holder.tv_TripImportanceNewFragment.setTextColor(context.getResources().getColor(R.color.colorPink));
                        break;
                }
            }
        } catch (Exception ignored) {
        }
//
        holder.itemView.setOnClickListener(v -> {

            final Dialog dialog = new Dialog(context, android.R.style.Theme_DeviceDefault_Light_Dialog_NoActionBar_MinWidth);
            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
            dialog.setContentView(R.layout.inflate_alertdialog_waitingdriverconfirmation);
            dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));

            RelativeLayout rl_cancle_Driver_confirm = dialog.findViewById(R.id.rl_cancle_Driver_confirm);
            RelativeLayout rl_archive_DrivrConfirm_Trip = dialog.findViewById(R.id.rl_archive_DrivrConfirm_Trip);

            if (model.getStrTripDate().compareTo(todayDate) >= 0) {
                rl_cancle_Driver_confirm.setVisibility(View.VISIBLE);
                rl_archive_DrivrConfirm_Trip.setVisibility(View.GONE);
            } else {
                rl_cancle_Driver_confirm.setVisibility(View.GONE);
                rl_archive_DrivrConfirm_Trip.setVisibility(View.VISIBLE);
            }

//            dialog.setTitle("");

            TextView txtTripReason = dialog.findViewById(R.id.txtTripReasonAlertWaitingDriverTabLayout);
            txtTripReason.setText(model.getStrTripReason_strComment());

            TextView txPersuateCode = dialog.findViewById(R.id.txtPersuateCodeAlertWaitingDriverTabLayout);
            txPersuateCode.setText(String.valueOf(model.getiOfficialTrip()));

            TextView txt_NameFamily = dialog.findViewById(R.id.txt_alertdialogNameFamilyWaitingDriverTablayout);
            txt_NameFamily.setText(model.getStrApplicantName() + " " + model.getStrApplicantFamily());
//                txt_alertdialogNameFamilyNewFragment.setText(model.getStrApplicantName());

            TextView txt_kindOfCar = dialog.findViewById(R.id.txt_DriverkindOfCar);
            txt_kindOfCar.setText(model.getStrMobileType());

            RelativeLayout rlDelete = dialog.findViewById(R.id.rlDeleteInflateAlertWaitingDriverTabLayout);
            rlDelete.setOnClickListener(v1 -> dialog.dismiss());

            TextView txt_ApplicatntPhone = dialog.findViewById(R.id.txt_ApplicantPhoneAlertWaitingDriverTabLayout);
            txt_ApplicatntPhone.setText(model.getStrApplicantMobile());

            TextView txt_origin = dialog.findViewById(R.id.txt_originAlertWaitingDriverTabLayout);
            txt_origin.setText(model.getStrOriginName());
//            txt_origin.setText(model.getStrOriginName() + " , " + model.getStrOriginAddress());

            TextView txt_des = dialog.findViewById(R.id.txt_desAlertWaitingDriverTabLayout);
            txt_des.setText(model.getStrDestinationName());
//            txt_des.setText(model.getStrDestinationName() + " , " + model.getStrDestinationAddress());

            TextView txt_DriverNameFamily = dialog.findViewById(R.id.txt_driverNameFamilyWaitingDriverTablayout);
            txt_DriverNameFamily.setText(model.getStrDriverName());

            TextView txt_driverPhone = dialog.findViewById(R.id.txt_DriverPhoneAlertWaitingDriverTabLayout);
            txt_driverPhone.setText(model.getDriverMobile());

            TextView txt_Comment = dialog.findViewById(R.id.txt_Comment3);
            txt_Comment.setText(model.getStrComment());

            TextView txt_Situation = dialog.findViewById(R.id.txt_Situation3);
            txt_Situation.setText(model.getStrChartName());

            TextView txt_DateAndTime = dialog.findViewById(R.id.txt_DateAndTime3);
            txt_DateAndTime.setText(model.getStrTripDate() + " _ " + model.getStrTripTime());

            TextView txt_Archives_TimePass_DriverConfirmTrip = dialog.findViewById(R.id.txt_Archives_TimePass_DriverConfirmTrip);


            ImageView img = dialog.findViewById(R.id.imgStarAlertWaitingDriverTabLayout);
            switch (model.getStrTripImportance_strComment()) {
                case "عادی":
                    img.setBackground(ContextCompat.getDrawable(context, R.drawable.star1));
                    break;
                case "فوری":
                    img.setBackground(ContextCompat.getDrawable(context, R.drawable.star2));
                    break;
                case "خیلی فوری":
                    img.setBackground(ContextCompat.getDrawable(context, R.drawable.star3));
                    break;
            }

            TextView txt_tripImportance = dialog.findViewById(R.id.txtTripImportanceAlertWaitingDriverTabLayout);
            txt_tripImportance.setText(model.getStrTripImportance_strComment());

            TextView txt_passengers = dialog.findViewById(R.id.txt_passengersAlertWaitingDriverTabLayout);
            txt_passengers.setText(model.getStrPassengers());

            TextView txt_cancel = dialog.findViewById(R.id.tv_dialog_cancel);
            TextView txt_location = dialog.findViewById(R.id.tv_dialog_location);

            txt_cancel.setOnClickListener(v12 -> {
                dialog.dismiss();
                onClick.cancelWaitingDriverConfirmedAlertTripManagement(model.getiOfficialTrip(), model.getTiTripStatus());
//            AlertDialog.Builder dialog2 = new AlertDialog.Builder(context);
//                dialog2.setMessage("آیا از لغو سفر با کد:" + model.getiOfficialTrip() + " مطمئن هستید؟");
//
//                dialog2.setPositiveButton("بله", (dialog1, which) ->
//                        onClick.cancelWaitingDriverConfirmedAlertTripManagement(model.getiOfficialTrip(), model.getTiTripStatus()));
//
//                dialog2.setNegativeButton("خیر", (dialog12, which) -> dialog12.dismiss());
//                dialog2.create().show();
//                dialog.dismiss();
            });

            txt_Archives_TimePass_DriverConfirmTrip.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dialog.dismiss();
                    onClick.tripsArchive(model.getiOfficialTrip());
                }
            });

            txt_location.setOnClickListener(v13 -> {
                Intent intent = new Intent(context, MapsActivityTabLayout.class);
                intent.putExtra("flatSourceTabLayout", model.getfLatSource());
                intent.putExtra("flngSourceTabLayout", model.getfLonSource());
                intent.putExtra("flatDesTabLayout", model.getfLatDestination());
                intent.putExtra("flngDesTabLayout", model.getfLonDestination());
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);
                dialog.dismiss();

            });
            dialog.show();

        });
    }

    @Override
    public int getItemCount() {
        return modelWaitingDriverFragments.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView txt_persuadeCode, txt_applicantName, txt_tripReason, tv_TripImportanceNewFragment,
                txt_requestDate, txt_supposeDate, txt_originAddress, txt_desAddress;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            txt_persuadeCode = itemView.findViewById(R.id.txt_row_txtPersuadeCodeNewFragment);
            txt_applicantName = itemView.findViewById(R.id.txt_row_txtApplicantNameNewFragment);
            txt_tripReason = itemView.findViewById(R.id.txt_row_TripReasonNewFragment);
            txt_requestDate = itemView.findViewById(R.id.txt_row_RequestDateNewFragment);
            txt_supposeDate = itemView.findViewById(R.id.txt_row_supposeDateNewFragment);
            txt_originAddress = itemView.findViewById(R.id.txt_row_originAddressNewFragment);
            txt_desAddress = itemView.findViewById(R.id.txt_row_DesAddressNewFragment);
            tv_TripImportanceNewFragment = itemView.findViewById(R.id.tv_TripImportanceNewFragment);
        }
    }
}
