package com.rayanandisheh.peysepar.passenger.services;

import android.text.Editable;

import android.widget.EditText;

import com.google.android.gms.maps.model.LatLng;
import com.rayanandisheh.peysepar.passenger.models.*;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;
import retrofit2.http.Query;

import java.util.List;

public interface APIService {

    //real
    @POST("RegisterUser")
    Call<Register> RegisterUser(@Body Register register);

    //گرفتن جایگاه های سازمانی
    @POST("GetChart")
    Call<List<Chart>> GetChart();

    @POST("Activate")
    Call<UserInfo> Activate(@Body Register register);

    @POST("Login")
    Call<UserInfo> Login(@Body Register register);

    @POST("SendActivateCode")
    Call<Integer> SendActivateCode(@Body Register register);

    @POST("TripListHistory")
    Call<List<Trip>> TripListHistory(@Body UserInfo userInfo, @Query("strSession") String strSession);

    @POST("InsertTrip2")
    Call<Integer> InsertTrip(@Body TripInsert tripInsert
            , @Query("iTripS_SAD") int iTripS_SAD
            , @Query("iTripD_SAD") int iTripD_SAD
            , @Query("strSession") String strSession);

    @POST("InsertEmdadTrip")
    Call<Integer> InsertEmdadTrip(@Body TripInsert tripInsert
            , @Query("strToken") String strToken
            , @Query("strImei") String strImei);

    @POST("UpdateProfile")
    Call<Register> UpdateProfile(@Body Register register, @Query("strSession") String strSession);

    @POST("EndTrip")
    Call<Integer> endTrip(@Body EndTrip EndTrip, @Query("strSession") String strSession);

    @POST("TripsArchive")
    Call<Integer> TripsArchive(@Body EndTrip trip, @Query("strSession") String strSession);

    @POST("CheckWebServiceAddress")
    Call<Integer> checkWebServiceAddress();

    @POST("CancelTrip")
    Call<Integer> cancelTrip(@Body Trip trip,
                             @Query("strReason") String strReason,
                             @Query("strSession") String strSession);

    @POST("CancelTripByDriver")
    Call<Integer> cancelTripByDriver(@Body Trip trip, @Query("strSession") String strSession);

    @POST("Refresh")
    Call<UserInfo> refresh(@Body UserInfo userInfo);

    @POST("Report")
    Call<Report> report(@Body Report report, @Query("strSession") String strSession);

    @POST("ManageTrip")
    Call<List<Trip>> manageTrip(@Body UserInfo userInfo, @Query("strSession") String strSession);

    @POST("ManageMyPersonelTrip")
    Call<List<Trip>> ManageMyPersonelTrip(@Body UserInfo userInfo, @Query("strSession") String strSession);

    //model related to taaid alert new tablayout
    @POST("ManagmentConfirm")
    Call<Data> managmentConfirm(@Body Trip trip, @Query("strSession") String strSession);

    @POST("DriverList")
    Call<List<DriverInfo>> driverList(@Body UserInfo userInfo, @Query("strSession") String strSession);

    @POST("checkDriverStatus")
    Call<Integer> checkDriverStatus(@Field("driverName") String driverName);

    @POST("AssignDriver")
    Call<Data> assignDriver(@Body AssignDriver assignDriver, @Query("strSession") String strSession);

    @POST("GetTimeDriver")
    Call<List<DriverInfo>> getTimeDriver(@Body UserInfo userInfo, @Query("strSession") String strSession);

    @POST("ChangeScore")
    Call<Data> ChangeScore(@Body Score score);

    @POST("Replacement")
    Call<UserInfo> Replacement(@Body Replace replace);

    @POST("Dashboard")
    Call<Dashboard> Dashboard(@Body Score Score, @Query("strSession") String strSession);

    @POST("News")
    Call<List<News>> news();

    @POST("Shutdown")
    Call<Integer> isTurningOff();

    @POST("GetLastPosition")
    Call<UserInfo> GetLastPosition(@Body Trip trip, @Query("strSession") String strSession);

    @POST("GetTripPath")
    Call<List<Car>> GetTripPath(@Query("iOfficialTrip") int iOfficialTrip);

    @POST("GetCarLive")
    Call<Car> GetCarLive(@Query("strUnitId") String strUnitId);

    @POST("PassengerDashboard")
    Call<Dashboard> PassengerDashboard(@Query("strMobile") String strMobile
            , @Query("strSession") String strSession);

    @POST("CheckVersion")
    Call<MobileVersionCntrol> CheckVersion();

    //shahriar
    @POST("RayanAndishehNasr/Login")
    Call<User> Login(@Body User user);

    @POST("RayanAndishehNasr/Forget")
    Call<Integer> forgot(@Body User user);

    @POST("RayanAndishehNasr/Change")
    Call<Integer> changePass(@Body User user);

    @POST("RayanAndishehNasr/Movement")
    Call<String> locations(@Body Locations location);

    @POST("RayanAndishehNasr/Around")
    Call<List<LatLng>> aroundCars(@Body LatLng latLong);

    @POST("RayanAndishehNasr/Around")
    Call<Integer> feedback(Editable feedback, int rate);

    @POST("PM_GetAndroidVer")
    Call<String> PM_GetAndroidVer(@Query("iPassenger") int iPassenger);

    @POST("ReverseGeocoding")
    Call<Geocoding> ReverseGeocoding(@Body Geocoding geoCode);

    @POST("Peysepar_WhatsUp")
    Call<WhatsUpResponse> Peysepar_WhatsUp(@Body WhatsUpRequest request);

    @POST("MobileDomain")
    Call<List<MobileDomain>> MobileDomain();

    @POST("Geocoding")
    Call<Geocoding> Geocoding(@Body Geocoding geoCode);
}