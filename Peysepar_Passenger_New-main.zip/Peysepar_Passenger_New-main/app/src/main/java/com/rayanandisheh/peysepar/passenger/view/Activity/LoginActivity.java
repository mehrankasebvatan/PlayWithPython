package com.rayanandisheh.peysepar.passenger.view.Activity;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Environment;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatTextView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.firebase.FirebaseApp;
import com.rayanandisheh.peysepar.passenger.BuildConfig;
import com.rayanandisheh.peysepar.passenger.R;
import com.rayanandisheh.peysepar.passenger.customes.mAppCompatActivity;
import com.rayanandisheh.peysepar.passenger.helpers.App;
import com.rayanandisheh.peysepar.passenger.helpers.Cache;
import com.rayanandisheh.peysepar.passenger.helpers.DeviceInfo;
import com.rayanandisheh.peysepar.passenger.helpers.Downloader;
import com.rayanandisheh.peysepar.passenger.helpers.Toaster;
import com.rayanandisheh.peysepar.passenger.helpers.Validate;
import com.rayanandisheh.peysepar.passenger.models.UserInfo;
import com.rayanandisheh.peysepar.passenger.models.WhatsUpRequest;
import com.rayanandisheh.peysepar.passenger.models.WhatsUpResponse;
import com.rayanandisheh.peysepar.passenger.services.APIClient;
import com.rayanandisheh.peysepar.passenger.services.APIService;
import com.rayanandisheh.peysepar.passenger.view.dialog.WhatsUpDialog;

import java.io.File;
import java.text.MessageFormat;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginActivity extends mAppCompatActivity {
    private static final String TAG = "LoginActivity";
    EditText etMobileNumber;
    Button btLogin;
    ProgressBar pbLogin;
    //    TextView tvRegister, tvForgotPassword, tvForgetLoading;
    TextView tvRegister, tvForgetLoading, txtVersionLogin;
    Context context = this;
    CountDownTimer countDownTimer = null;
    ImageView ivWarningMobileLogin;
    PackageInfo pinfo = null;
    String versionName;
    private String IMEI = "";
    int currentVersion = 0;

    AppCompatTextView goToSetting;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        bindViews();

//        view=findViewById(R.id.vHeader);
//        view.setOnClickListener(v -> {
//            context.startActivity(new Intent(context,MainActivity.class));
//        });

        try {
            pinfo = getPackageManager().getPackageInfo(getPackageName(), 0);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
//
        versionName = pinfo.versionName;
        txtVersionLogin.setText(versionName);

        if (App.strResult.equals("-3")) {
            etMobileNumber.setText(App.mobileFirstRunning);

            if (ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED
                    && ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.ACCESS_NOTIFICATION_POLICY) != PackageManager.PERMISSION_GRANTED) {

//                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                requestPermission();
//                }
            } else {
                validateAndLogin();
//            dosomthing();
            }

        } else {
            if (!Cache.getString("mobileNumber").equals("")) {
                etMobileNumber.setText(Cache.getString("mobileNumber"));
            } else {
                etMobileNumber.setText("");
            }
        }

        btLogin.setOnClickListener(v -> {
            if (etMobileNumber.getText().toString().isEmpty()) {
                showErrorZeroMobileNumberLogin();
            } else if (etMobileNumber.getText().toString().equals("305040")) {
                startActivity(new Intent(context, SettingUrlActivity.class));
                finish();
            } else if (!Validate.mobile(etMobileNumber.getText().toString())) {
                showError09MobileNumberLogin();
            } else if (ContextCompat.checkSelfPermission(getApplicationContext()
                    , Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED
                    && ContextCompat.checkSelfPermission(getApplicationContext()
                    , Manifest.permission.ACCESS_NOTIFICATION_POLICY) != PackageManager.PERMISSION_GRANTED) {
//                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                requestPermission();
//                }
            } else {
                validateAndLogin();
//            dosomthing();
            }
        });
    }

    private void bindViews() {
        etMobileNumber = findViewById(R.id.etMobileNumber);
//        etPassword = findViewById(R.id.etPassword);
        btLogin = findViewById(R.id.btLogin);
        pbLogin = findViewById(R.id.pbLogin);
        tvRegister = findViewById(R.id.tvRegister);
//        tvForgotPassword = findViewById(R.id.tvForgotPass);
//        tvForgetLoading = findViewById(R.id.tvForgotPassLoading);
        ivWarningMobileLogin = findViewById(R.id.ivWarningMobileLogin);
        txtVersionLogin = findViewById(R.id.txtVersionLogin);
        goToSetting = findViewById(R.id.goToSetting);

        tvRegister.setOnClickListener(v -> register());
        goToSetting.setOnClickListener(view -> context.startActivity(new Intent(context, SettingUrlActivity.class)));
    }

    public void register() {
        context.startActivity(new Intent(context, RegisterActivity.class));
    }

    public void forgotPass(String mobileNumber) {
        if (Validate.mobile(mobileNumber)) {
            forgot(mobileNumber);
            startForgotLoading();
        } else
            showMobileNumberError(context.getResources().getString(R.string.emptyMobileNumber));
    }

    private void validateAndLogin() {
        App.mobileFirstRunning = etMobileNumber.getText().toString();
        login(etMobileNumber.getText().toString());
    }

    public void startLoading() {
        btLogin.setVisibility(View.GONE);
        pbLogin.setVisibility(View.VISIBLE);
    }

    public void permissionUpdateResult(int result) {
        if (result == 1) {
            update();
        } else {
            showPermissionAlert();
        }
    }

    @SuppressLint("HardwareIds")
    public void login(String mobileNumber) {
        startLoading();
        App.register.setStrMobile(mobileNumber);

        if (Build.VERSION.SDK_INT > 28) {
            IMEI = Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ANDROID_ID);
            App.register.setStrIMEI(IMEI);
        } else
            App.register.setStrIMEI(DeviceInfo.getDeviceIMEI(context));

        FirebaseApp.initializeApp(context);
        String token = Cache.getString("FirebaseToken");
        App.register.setStrToken(token);
//        App.register.setStrToken(FirebaseInstanceId.getInstance().getToken());

        PackageInfo pinfo = null;
        try {
            pinfo = context.getPackageManager().getPackageInfo(context.getPackageName(), 0);
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        assert pinfo != null;
        App.register.setVersionCode(pinfo.versionCode);

        APIService apiService = APIClient.getClient().create(APIService.class);
        Call<UserInfo> call = apiService.Login(App.register);
        call.enqueue(new Callback<UserInfo>() {
            @Override
            public void onResponse(@NonNull Call<UserInfo> call, @NonNull Response<UserInfo> response) {
                if (response.code() == 200) {
                    App.userInfo = response.body();
                    Cache.setString("logo",response.body().getStrLogo());
                    assert App.userInfo != null;
                    Cache.setString("photo", App.userInfo.getImgLink());
                    assert response.body() != null;
                    App.mobileNumber_inActiveUser = mobileNumber;
                    App.Session = response.body().getStrSession();
                    App.mapMode = response.body().getiSAndDBaseCurrentLoc();

                    Cache.setString("peyseparDomain", response.body().getStrComment_strMbileDomain());
                    loginResult(response.body().getResult());
                    Log.d(TAG, "Session: " + response.body().getStrSession());

                } else
                    loginResult(-1);
            }

            @Override
            public void onFailure(@NonNull Call<UserInfo> call, @NonNull Throwable t) {
                loginResult(-5);
            }
        });
    }

    public void loginResult(int result) {
        stopLoading();
        switch (result) {
//            case -4:
//                //same IMEI & diffrent mobilePhone
//                if (App.userInfo.getStrMobile() != null)
//                    App.periviousMobileNum = App.userInfo.getStrMobile();
//                if (CheckSmsPermissionGranted()) {
////                    ShowDialog(App.userInfo.strComment);
//                    context.startActivity(new Intent(context, ActivationActivity.class));
//                    Toaster.longer(App.userInfo.strComment);
//                    ((Activity) context).finish();
//                }
//                break;
            case 1:
                getWhatsUP();
                break;
            case 0:
                context.startActivity(new Intent(context, RegisterActivity.class));
                ((Activity) context).finish();
                break;
            case -1:
                Toaster.shorter(App.userInfo.strComment);
                break;
            case -2:
//                if (CheckSmsPermissionGranted()) {
                App.diffrentIMEI = false;
                context.startActivity(new Intent(context, ActivationActivity.class));
                Toaster.longer(context.getString(R.string.validateYourNumber));
                ((Activity) context).finish();
//                }
                break;
            case -3:
                Toaster.shorter(App.userInfo.strComment);
                setEdtMobile_inActiveUser();
                break;
            case -5:
                Toaster.shorter(context.getString(R.string.connectionFaield));
                break;
            default:
                break;
        }

    }

    private void getWhatsUP() {
        WhatsUpRequest request = new WhatsUpRequest();
        request.setiPassenger(App.userInfo.getiPassenger());
        request.setStrAppVersion(BuildConfig.VERSION_NAME);
        request.setStrFullName(App.userInfo.getStrName() + " " + App.userInfo.getStrFamily());
        APIClient.getClient().create(APIService.class).Peysepar_WhatsUp(request).enqueue(new Callback<WhatsUpResponse>() {
            @Override
            public void onResponse(Call<WhatsUpResponse> call, Response<WhatsUpResponse> response) {
                if (response != null && response.isSuccessful() && response.body() != null) {
                    if (response.body().getiResult() == 1) {
                        showUpdateDialog(response.body());
                        Log.d("whatsup", response.body().getiResult() + "");
                    } else {
                        goToMainActivity();
                    }
                } else {
                    goToMainActivity();
                }
            }

            @Override
            public void onFailure(Call<WhatsUpResponse> call, Throwable t) {
                goToMainActivity();
            }
        });
    }

    private void showUpdateDialog(WhatsUpResponse whatsUpResponse) {
        WhatsUpDialog dialog = new WhatsUpDialog(this, whatsUpResponse);
        dialog.show();
    }

    private void goToMainActivity() {
        context.startActivity(new Intent(context, MainActivity.class));
        ((Activity) context).finish();
        cacheUser();
    }

    public void cacheUser() {
        Log.i("TAG", "cacheUser: 111111");
        Cache.setString("mobileNumber", App.register.getStrMobile());
//        Cache.setInt("versionCode",App.register.getVersionCode());
        Cache.setString("IMEI", App.register.getStrIMEI());
//        Cache.setString("Token",App.register.getStrToken());
    }

    public void forgot(String mobileNumber) {
        App.user.setMobileNumber(mobileNumber);
        APIService apiService = APIClient.getClient().create(APIService.class);
        Call<Integer> call = apiService.forgot(App.user);
        call.enqueue(new Callback<Integer>() {
            @Override
            public void onResponse(@NonNull Call<Integer> call, @NonNull Response<Integer> response) {
                if (response.code() == 200 && response.body() != null)
                    forgotResult(response.body());
                else
                    forgotResult(-4);
            }

            @Override
            public void onFailure(@NonNull Call<Integer> call, @NonNull Throwable t) {
                forgotResult(-5);
            }
        });
    }

    public void forgotResult(int result) {
        switch (result) {
            case -5:
                stopForgotLoading();
                Toaster.shorter(context.getString(R.string.connectionFaield));
                break;
            case -4:
                stopForgotLoading();
                Toaster.shorter(context.getString(R.string.serverFaield));
                break;
            case 0:
                //  : check for after validate what happen
                context.startActivity(new Intent(context, ActivationActivity.class));
                Toaster.longer(context.getString(R.string.validateYourNumber));
                break;
            case 1:
                context.startActivity(new Intent(context, ChangePasswordActivity.class));
                cacheUser();
                break;
            default:
                break;
        }
    }

//    public boolean CheckSmsPermissionGranted() {
//        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECEIVE_SMS) != PackageManager.PERMISSION_GRANTED) {
//            requestReceveSMS_ReadSMSPermmision();
//        } else {
//            return true;
//        }
//
//        return false;
//    }

//    public void checkUpdatePermission() {
//        permissionUpdateResult(
//                (ContextCompat.checkSelfPermission(App.context, Manifest.permission.WRITE_EXTERNAL_STORAGE)
//                        != PackageManager.PERMISSION_GRANTED) ? -1 : 1);
//    }

    public void update() {

        File toInstall = new File(Environment.getExternalStorageDirectory(),
                "Download/" + context.getResources().getString(R.string.app_name) + ".apk");
        if (toInstall.exists()) {
            toInstall.delete();
        }
//        new DownloadManager().DownloadUpdateApp(context);
        new Downloader().DownloadUpdateApp(context);
    }

    public void requestPermission() {
        ActivityCompat.requestPermissions((Activity) context
                , new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
    }

//    private void requestReceveSMS_ReadSMSPermmision() {
////        ActivityCompat.requestPermissions((Activity) context
////                , new String[]{Manifest.permission.RECEIVE_SMS, Manifest.permission.READ_SMS}, 1235);
//        ActivityCompat.requestPermissions((Activity) context
//                , new String[]{Manifest.permission.RECEIVE_SMS}, 1235);
//    }

    public void stopLoading() {
        pbLogin.setVisibility(View.GONE);
        btLogin.setVisibility(View.VISIBLE);
    }

    public void startForgotLoading() {
//        tvForgotPassword.setVisibility(View.GONE);
        tvForgetLoading.setVisibility(View.VISIBLE);
        if (countDownTimer != null)
            countDownTimer.cancel();
        countDownTimer = new CountDownTimer(60000, 1000) {
            public void onTick(long millisUntilFinished) {
                tvForgetLoading.setText(MessageFormat.format("{0} {1} {2}", getString(R.string.after), millisUntilFinished / 1000, getString(R.string.secends)));
            }

            public void onFinish() {
                stopForgotLoading();
            }
        }.start();
    }

    public void stopForgotLoading() {
        tvForgetLoading.setVisibility(View.GONE);
//        tvForgotPassword.setVisibility(View.VISIBLE);
    }

    public void showMobileNumberError(String string) {
        etMobileNumber.setError(string);
        etMobileNumber.requestFocus();
    }

    public void showError09MobileNumberLogin() {
        etMobileNumber.setError("شماره موبایل صحیح نمیباشد");
    }

    public void showErrorZeroMobileNumberLogin() {
        etMobileNumber.setError("وارد کردن شماره موبایل الزامیست");
    }

    public void showErrorNotCorrectMobilePhoneLogin() {
        etMobileNumber.setError("شماره موبایل وارد شده صحیح نمی باشد");
    }

    public void setEdtMobile_inActiveUser() {
        etMobileNumber.setText(App.mobileNumber_inActiveUser);
    }

    public void ShowDialog(String strComment) {
        final Dialog dialog = new Dialog(context);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.login_dialog);

        TextView txtStrComment = dialog.findViewById(R.id.txtStrComment);
        TextView txtRegister = dialog.findViewById(R.id.txtRegister);
        TextView txtIgnor = dialog.findViewById(R.id.txtIgnor);
        TextView txtLogin = dialog.findViewById(R.id.txtLogin);

        txtStrComment.setText(strComment);

        txtLogin.setOnClickListener(v -> {
            //بره تو صفحه ای که شماره قبلی رو باید وارد کنه
            gotoActivation(context);
            dialog.dismiss();
        });

        txtRegister.setOnClickListener(v -> {
            //بفرسته تو صفحه ثبت نام
            gotoRegister(context);
            dialog.dismiss();
        });

        txtIgnor.setOnClickListener(v -> dialog.dismiss());

        dialog.show();
    }

    public void gotoActivation(Context context) {
        App.diffrentIMEI = true;
        context.startActivity(new Intent(context, ActivationActivity.class));
    }

    public void gotoRegister(Context context) {
        context.startActivity(new Intent(context, RegisterActivity.class));
    }

    public void showForceUpdate() {
        androidx.appcompat.app.AlertDialog.Builder dialog = new androidx.appcompat.app.AlertDialog.Builder(context);
        dialog.setMessage(R.string.forceUpdateAvailable);
        dialog.setPositiveButton(R.string.update, (dialog1, which) -> updateFromBazar(context));
//        dialog.setPositiveButton(R.string.update, (dialog1, which) -> showStorageAccessDialog());
        dialog.setNegativeButton(R.string.exit, (dialog12, which) -> exitApplication());
        dialog.setCancelable(false);
        dialog.show();
    }

    public void updateFromBazar(Context context) {
        String url = "https://cafebazaar.ir/app/com.rayanandisheh.peysepar.customer";
        Intent i = new Intent(Intent.ACTION_VIEW);
        i.setData(Uri.parse(url));
        context.startActivity(i);
    }

    public void showPermissionAlert() {
        androidx.appcompat.app.AlertDialog.Builder dialog = new androidx.appcompat.app.AlertDialog.Builder(context);
        dialog.setMessage(R.string.externalStorageAccess);
        dialog.setPositiveButton(R.string.accessPermission, (dialog13, which) -> requestPermission());
        dialog.setNegativeButton(R.string.cancel, (dialog14, which) -> dialog14.dismiss());
        dialog.show();
    }

    private void exitApplication() {
        context.startActivity(new Intent(Intent.ACTION_MAIN).
                addCategory(Intent.CATEGORY_HOME).
                setFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        App.isRun = false; // for don't start location service onDestroy
        android.os.Process.killProcess(android.os.Process.myPid());
        ((Activity) context).finish();
    }

//    private void showStorageAccessDialog() {
//        androidx.appcompat.app.AlertDialog.Builder dialog1 = new androidx.appcompat.app.AlertDialog.Builder(context);
//        dialog1.setMessage("جهت به روز رسانی برنامه لازم است دسترسی به حافظه ذخیره سازی موبایل وجود داشته باشد");
//        dialog1.setPositiveButton("تأیید", (dialog2, which) -> checkUpdatePermission());
//        dialog1.setCancelable(false);
//        dialog1.show();
//    }

    @Override
    protected void onResume() {
        super.onResume();
        if (!App.modeChanged) {
            App.modeChanged = true;
            ((Activity) context).finish();
            context.startActivity(new Intent(context, LoginActivity.class).setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP));
        }
    }

//    @Override
//    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions
//            , @NonNull int[] grantResults) {
//        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
//
//        Log.i(TAG, "onRequestPermissionsResult: requestCode " + requestCode);
//
//        switch (requestCode) {
//            case 4:
//                if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
//                    validateAndLogin();
//
////                    dosomthing();
//                } else {
//                    showAccessPermissionDialog();
//                }
//                break;
//
//            case 1235:
//                if (grantResults[1] == PackageManager.PERMISSION_GRANTED) {
//                    startActivity(new Intent(context, ActivationActivity.class));
////                    dosomthing();
//                }
//                break;
//
//            case 5:
//                showAccessNotificationPermissionDialog();
//                break;
//        }
//    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions
            , @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        Log.i(TAG, "onRequestPermissionsResult: requestCode " + requestCode);
//        if (requestCode == RE) {
//        }
        switch (requestCode) {
            case 4:
//                if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                validateAndLogin();

//                    dosomthing();
//                } else {
                showAccessPermissionDialog();
//                }
                break;

//            case 1235:
////                if (grantResults[1] == PackageManager.PERMISSION_GRANTED) {
//                    startActivity(new Intent(context, ActivationActivity.class));
////                    dosomthing();
////                }
//                break;

            case 5:
                showAccessNotificationPermissionDialog();
                break;
        }
    }

    private void showAccessNotificationPermissionDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("عدم اجازه دسترسي");
        builder.setMessage(R.string.accessDeniedMessage);
        builder.setPositiveButton("برو به تنظيمات", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

//                Intent intent = new Intent();
//                intent.setAction("android.settings.APP_NOTIFICATION_SETTINGS");
//
////for Android 5-7
//
//                intent.putExtra("app_package", getPackageName());
//                intent.putExtra("app_uid", getApplicationInfo().uid);
//
//// for Android 8 and above
//                intent.putExtra("android.provider.extra.APP_PACKAGE", getPackageName());
//
//                startActivity(intent);

                startActivity(new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"));

            }
        });
        builder.create().show();
    }

    private void showAccessPermissionDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("عدم اجازه دسترسی");
        builder.setMessage(R.string.accessDeniedMessage);
        builder.setPositiveButton("برو به تنظیمات", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Intent intent = new Intent();
                intent.setAction(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                Uri uri = Uri.fromParts("package", getPackageName(), null);
                intent.setData(uri);
                startActivity(intent);
            }
        });
        builder.create().show();
    }

}