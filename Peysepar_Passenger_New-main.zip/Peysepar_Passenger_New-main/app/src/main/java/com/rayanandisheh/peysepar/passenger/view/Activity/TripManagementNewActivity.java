package com.rayanandisheh.peysepar.passenger.view.Activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.rayanandisheh.peysepar.passenger.R;
import com.rayanandisheh.peysepar.passenger.helpers.App;
import com.rayanandisheh.peysepar.passenger.helpers.PersianAppcompatActivity;
import com.rayanandisheh.peysepar.passenger.helpers.Toaster;
import com.rayanandisheh.peysepar.passenger.models.Data;
import com.rayanandisheh.peysepar.passenger.models.EndTrip;
import com.rayanandisheh.peysepar.passenger.models.Trip;
import com.rayanandisheh.peysepar.passenger.models.UserInfo;
import com.rayanandisheh.peysepar.passenger.services.APIClient;
import com.rayanandisheh.peysepar.passenger.services.APIService;
import com.rayanandisheh.peysepar.passenger.view.Adapter.TripManagementCancelAdapter;
import com.rayanandisheh.peysepar.passenger.view.Adapter.TripManagementConfirmedAdapter;
import com.rayanandisheh.peysepar.passenger.view.Adapter.TripManagementDriverConfirmedAdapter;
import com.rayanandisheh.peysepar.passenger.view.Adapter.TripManagementNewAdapter;
import com.rayanandisheh.peysepar.passenger.view.Adapter.TripManagementRunningAdapter;
import com.rayanandisheh.peysepar.passenger.view.dialog.DialogConfirmCancelTtrip;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;

import jp.wasabeef.recyclerview.adapters.AlphaInAnimationAdapter;
import jp.wasabeef.recyclerview.adapters.ScaleInAnimationAdapter;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.rayanandisheh.peysepar.passenger.helpers.App.userInfo;

public class TripManagementNewActivity extends PersianAppcompatActivity {
    Context context;
    private static final String TAG = "TripManagementNewActiviy";
    Spinner spn_tripManagementNew;
    ImageView img_arrowBack, img_noItem;
    ProgressBar pb;
    SwipeRefreshLayout swpRefresh;
    RecyclerView recyclerView;
    public static int spnPosition = 0;
    int position;
    //private int section;
    TripManagementNewAdapter adapterNewTrip;
    TripManagementConfirmedAdapter adapterConfirmed;
    TripManagementDriverConfirmedAdapter adapterDriverConfirmed;
    TripManagementRunningAdapter adapterRunning;
    TripManagementCancelAdapter adapterCancel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trip_management_new);
        context = this;
        //getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        bindView();


//        edtDateFrom.setText(Time.getNowPersianDate());
//        edtDateTo.setText(Time.getNowPersianDate());
//
//        edtDateFrom.setOnClickListener(v -> presenter.edtDatePressed(true));
//        edtDateTo.setOnClickListener(v -> presenter.edtDatePressed(false));

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this
                , R.array.trip_management, android.R.layout.simple_spinner_item);

        if (userInfo.getConfirmTrip() && userInfo.getManageTrip()) {
            adapter = ArrayAdapter.createFromResource(this, R.array.trip_management, android.R.layout.simple_spinner_item);
        } else if (userInfo.getConfirmTrip()) {
            adapter = ArrayAdapter.createFromResource(this, R.array.trip_ConfirmManagement, android.R.layout.simple_spinner_item);
        } else if (userInfo.getManageTrip()) {
            adapter = ArrayAdapter.createFromResource(this, R.array.trip_onlyManagement, android.R.layout.simple_spinner_item);
        }

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spn_tripManagementNew.setAdapter(adapter);

        spn_tripManagementNew.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (userInfo.getConfirmTrip() && userInfo.getManageTrip()) {
                    spnSelected(parent, view, position, id);
                } else if (userInfo.getConfirmTrip()) {
                    spnSelectedConfirmTrip(parent, view, position, id);
                } else if (userInfo.getManageTrip()) {
                    spnSelectedOnlyManagement(parent, view, position, id);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        viewLoded(spn_tripManagementNew.getSelectedItemPosition());

        img_arrowBack.setOnClickListener(v -> imgArrowBackPressed());

//        rl_search.setOnClickListener(v -> presenter.rl_searchPressed(spn_tripManagementNew.getSelectedItemPosition(),
//                edtDateFrom.getText().toString(),edtDateTo.getText().toString()));

        swpRefresh.setOnRefreshListener(() -> swpRefreshPressed(spn_tripManagementNew.getSelectedItemPosition()));
    }

    private void bindView() {
        spn_tripManagementNew = findViewById(R.id.spn_tripManagementNew);
        img_arrowBack = findViewById(R.id.img_arrowbackTripManagementNew);
        img_noItem = findViewById(R.id.img_noItemTripManagementNew);
        pb = findViewById(R.id.pbTripManagementNew);
        recyclerView = findViewById(R.id.rv_tripManagementNew);
        swpRefresh = findViewById(R.id.swp_tripManagegmentNew);
    }

    public void ShowSwpRefresh() {
        swpRefresh.setRefreshing(true);
    }

    public void HideSwpRefresh() {
        swpRefresh.setRefreshing(false);
    }

    public void showImg_noItem() {
        img_noItem.setVisibility(View.VISIBLE);
    }

    public void hideImg_noItem() {
        img_noItem.setVisibility(View.GONE);
    }

    public void setAdapter(int position) {
        if (position == 0) {
            adapterNewTrip = new TripManagementNewAdapter(App.listNewTripManagementNew, context, new TripManagementNewAdapter.onClick() {
                @Override
                public void cancelNewAlertTripManagement(int iOfficialTrip, int status) {
                    cancelNewAlertTripManagement1(iOfficialTrip, status);
                }

                @Override
                public void confirmNewAlertTripManagement(int iOfficialTrip) {
                    confirmNewAlertTripManagement1(iOfficialTrip);
                }

                @Override
                public void tripsArchive(int iOfficialTrip) {
                    tripsArchive1(iOfficialTrip);
                }
            });
            recyclerView.setLayoutManager(new LinearLayoutManager(context));
            AlphaInAnimationAdapter alphaAdapter = new AlphaInAnimationAdapter(adapterNewTrip);
            recyclerView.setAdapter(new ScaleInAnimationAdapter(alphaAdapter));
        } else if (position == 1) {
            adapterConfirmed = new TripManagementConfirmedAdapter(App.listConfirmedTripManagementNew, context, new TripManagementConfirmedAdapter.onClick() {
                @Override
                public void cancelConfirmedTripAlertTripManagement(int iOfficialTrip, int tiTripStatus) {
                    cancelConfirmedTripAlertTripManagement1(iOfficialTrip, tiTripStatus);
                }

                @Override
                public void onClick(Trip trip) {
                }

                @Override
                public void tripsArchive(int iOfficialTrip) {
                    tripsArchive1(iOfficialTrip);
                }
            });
            recyclerView.setLayoutManager(new LinearLayoutManager(context));
            AlphaInAnimationAdapter alphaAdapter = new AlphaInAnimationAdapter(adapterConfirmed);
            recyclerView.setAdapter(new ScaleInAnimationAdapter(alphaAdapter));
        } else if (position == 2) {
            adapterDriverConfirmed = new TripManagementDriverConfirmedAdapter(App.listWaitingDriverConfirmTripManagementNew
                    , context, new TripManagementDriverConfirmedAdapter.onClick() {
                @Override
                public void cancelWaitingDriverConfirmedAlertTripManagement(int iOfficialTrip, int tiTripStatus) {
                    cancelWaitingDriverConfirmedAlertTripManagement1(iOfficialTrip, tiTripStatus);
                }

                @Override
                public void tripsArchive(int iOfficialTrip) {
                    tripsArchive1(iOfficialTrip);
                }
            });
            recyclerView.setLayoutManager(new LinearLayoutManager(context));
            AlphaInAnimationAdapter alphaAdapter = new AlphaInAnimationAdapter(adapterDriverConfirmed);
            recyclerView.setAdapter(new ScaleInAnimationAdapter(alphaAdapter));
        } else if (position == 3) {
            adapterRunning = new TripManagementRunningAdapter(App.listRunningTripManagementNew, context);
            recyclerView.setLayoutManager(new LinearLayoutManager(context));
            AlphaInAnimationAdapter alphaAdapter = new AlphaInAnimationAdapter(adapterRunning);
            recyclerView.setAdapter(new ScaleInAnimationAdapter(alphaAdapter));
        } else if (position == 4) {
            adapterCancel = new TripManagementCancelAdapter(App.listCanceledTripManagementNew, context, new TripManagementCancelAdapter.onClick() {
                @Override
                public void confirm_CancelTripAlert(int iOfficialTrip) {
                    confirm_CancelTripAlert1(iOfficialTrip);
                }

                @Override
                public void tripsArchive(int iOfficialTrip) {
                    tripsArchive1(iOfficialTrip);
                }
            });
            recyclerView.setLayoutManager(new LinearLayoutManager(context));
            AlphaInAnimationAdapter alphaAdapter = new AlphaInAnimationAdapter(adapterCancel);
            recyclerView.setAdapter(new ScaleInAnimationAdapter(alphaAdapter));
        }
    }

    public void setBtnVisibility() {
    }

    public void requesrListNewTrips(int position) {
        if (userInfo.getConfirmTrip() && userInfo.getManageTrip()) {
            if (position == 0) {//جدید
                userInfo.setType(0);
            } else if (position == 1) {//تایید شده
                userInfo.setType(1);
            } else if (position == 2) {//منتظر تایید راننده
                userInfo.setType(2);
            } else if (position == 3) {//در حال اجرا
                userInfo.setType(6);
            } else if (position == 4) {  //لغو شده
                userInfo.setType(8);
            }
        } else if (userInfo.getConfirmTrip()) {
            if (position == 0) {//جدید
                userInfo.setType(0);
            } else if (position == 1) { //سفرهای پیشین پرسنل من
//                userInfo.setType(8);
            }
        } else if (userInfo.getManageTrip()) {
            if (position == 0) {//تایید شده
                userInfo.setType(1);
            } else if (position == 1) {//منتظر تایید راننده
                userInfo.setType(2);
            } else if (position == 2) {//در حال اجرا
                userInfo.setType(6);
            } else if (position == 3) {//لغو شده
                userInfo.setType(8);
            }
        }

        APIService apiService = APIClient.getClient().create(APIService.class);
        Call<List<Trip>> call = apiService.manageTrip(userInfo,App.Session);
        call.enqueue(new Callback<List<Trip>>() {
            @Override
            public void onResponse(@NotNull Call<List<Trip>> call, @NotNull Response<List<Trip>> response) {
                if (response.code() == 200) {
                    if (position == 0) { //new Trip
                        App.newTripManagementSuccess = false;
//                        App.listNewTabLayoutTrip = response.body();
                        App.listNewTripManagementNew = response.body();
                        if (App.listNewTripManagementNew != null) {
                            loadDataResult(1, position);
                        } else {
                            loadDataResult(0, position);
                        }

                    } else if (position == 1) { //confirmedTrip
                        App.confirmedTripManagementSuccess = false;
                        App.listConfirmedTripManagementNew = response.body();
                        if (App.listConfirmedTripManagementNew != null) {
                            loadDataResult(1, position);
                        } else {
                            loadDataResult(0, position);
                        }

                    } else if (position == 2) { // waiting driver confirmed
                        App.waitingDriverConfirmTripManagementSuccess = false;
                        App.listWaitingDriverConfirmTripManagementNew = response.body();
                        if (App.listWaitingDriverConfirmTripManagementNew != null) {
                            loadDataResult(1, position);
                        } else {
                            loadDataResult(0, position);
                        }

                    } else if (position == 3) {  //runnuing trip
                        App.RunningTripManagementSuccess = false;
                        App.listRunningTripManagementNew = response.body();
                        if (App.listRunningTripManagementNew != null) {
                            loadDataResult(1, position);
                        } else {
                            loadDataResult(0, position);
                        }

                    } else if (position == 4) {
                        App.CanceledTripManagementSuccess = false;
                        App.listCanceledTripManagementNew = response.body();
                        if (App.listCanceledTripManagementNew != null) {
                            loadDataResult(1, position);
                        } else {
                            loadDataResult(0, position);
                        }
                    }
                } else {
                    loadDataResult(-4, position);
                }
            }

            @Override
            public void onFailure(Call<List<Trip>> call, Throwable t) {
                loadDataResult(-5, position);
            }
        });
    }

    public void requestCancelNewAlertTripManagement(int iOfficialTrip, int position, int tiTripStatus, String strReason) {
        Trip trip = new Trip();
        trip.setiOfficialTrip(iOfficialTrip);
        trip.setTiTripStatus(tiTripStatus);

        APIService apiService = APIClient.getClient().create(APIService.class);
        Call<Integer> call = apiService.cancelTrip(trip, strReason,App.Session);

        call.enqueue(new Callback<Integer>() {
            @Override
            public void onResponse(@NotNull Call<Integer> call, Response<Integer> response) {
                if (response.code() == 200) {
                    cencelNewTripAlertResult(response.body(), position);
                } else {
                    cencelNewTripAlertResult(-4, position);
                }
            }

            @Override
            public void onFailure(@NotNull Call<Integer> call, @NotNull Throwable t) {
                cencelNewTripAlertResult(-5, position);
            }
        });
    }

    public void requestConfirmNewAlertTripManagement(int iOfficialTrip, int position) {
        Trip trip = new Trip();
        trip.setiOfficialTrip(iOfficialTrip);

        APIService apiService = APIClient.getClient().create(APIService.class);
        Call<Data> call = apiService.managmentConfirm(trip,App.Session);
        call.enqueue(new Callback<Data>() {
            @Override
            public void onResponse(@NotNull Call<Data> call, @NotNull Response<Data> response) {
                if (response.code() == 200) {
                    App.data = response.body();
                    assert response.body() != null;
                    confirmNewTripAlertResult(response.body().getResult(), position);
                } else {
                    confirmNewTripAlertResult(-4, position);
                }
            }

            @Override
            public void onFailure(@NotNull Call<Data> call, @NotNull Throwable t) {
                confirmNewTripAlertResult(-5, position);
            }
        });
    }

    public void requestCancelConfirmedTripAlertTripManagement(int iOfficialTrip, int position
            , int tiTripStatus, String strReason) {

        Trip trip = new Trip();
        trip.setiOfficialTrip(iOfficialTrip);
        trip.setTiTripStatus(tiTripStatus);

        APIService apiService = APIClient.getClient().create(APIService.class);
        Call<Integer> call = apiService.cancelTrip(trip, strReason,App.Session);

        call.enqueue(new Callback<Integer>() {
            @Override
            public void onResponse(@NotNull Call<Integer> call, @NotNull Response<Integer> response) {
                if (response.code() == 200 && response.body() != null) {
                    cencelConfirmTripAlertResult(response.body(), position);
                } else {
                    cencelConfirmTripAlertResult(-4, position);
                }
            }

            @Override
            public void onFailure(@NotNull Call<Integer> call, @NotNull Throwable t) {
                cencelConfirmTripAlertResult(-5, position);
            }
        });
    }

    public void requestCancelWaitingDriverConfirmedAlertTripManagement(int iOfficialTrip, int position
            , int tiTripStatus, String strReason) {
        Trip trip = new Trip();
        trip.setiOfficialTrip(iOfficialTrip);
        trip.setTiTripStatus(tiTripStatus);

        APIService apiService = APIClient.getClient().create(APIService.class);
        Call<Integer> call = apiService.cancelTrip(trip, strReason,App.Session);

        call.enqueue(new Callback<Integer>() {
            @Override
            public void onResponse(@NotNull Call<Integer> call, @NotNull Response<Integer> response) {
                if (response.code() == 200 && response.body() != null) {
                    cencelWaitinDriverConfirmTripAlertResult(response.body(), position);
                } else {
                    cencelWaitinDriverConfirmTripAlertResult(-4, position);
                }
            }

            @Override
            public void onFailure(@NotNull Call<Integer> call, @NotNull Throwable t) {
                cencelWaitinDriverConfirmTripAlertResult(-5, position);
            }
        });
    }

    public void requestCancelTripConfim(int iOfficialTrip, int position) {
        Trip trip = new Trip();
        trip.setiOfficialTrip(iOfficialTrip);

        APIService apiService = APIClient.getClient().create(APIService.class);
        Call<Integer> call = apiService.cancelTripByDriver(trip,App.Session);
        call.enqueue(new Callback<Integer>() {
            @Override
            public void onResponse(@NotNull Call<Integer> call, @NotNull Response<Integer> response) {
                if (response.code() == 200 && response.body() != null) {
                    cencelTripAlertConfirmResult(response.body(), position);
                } else {
                    cencelTripAlertConfirmResult(-1, position);
                }
            }

            @Override
            public void onFailure(@NotNull Call<Integer> call, @NotNull Throwable t) {
                cencelTripAlertConfirmResult(-5, position);
            }
        });
    }

    public void tripsArchive1(int iOfficialTrip) {

        EndTrip trip = new EndTrip();
        trip.setiOfficialTrip(iOfficialTrip);

        APIService apiService = APIClient.getClient().create(APIService.class);
        Call<Integer> call = apiService.TripsArchive(trip,App.Session);
        call.enqueue(new Callback<Integer>() {
            @Override
            public void onResponse(@NotNull Call<Integer> call, @NotNull Response<Integer> response) {
                if (response.code() == 200 && response.body() != null) {
                    tripsArchiveResult(response.body());
                    requesrListNewTrips(spnPosition);
                } else {
                    tripsArchiveResult(-2);
                }
            }

            @Override
            public void onFailure(@NotNull Call<Integer> call, @NotNull Throwable t) {
                tripsArchiveResult(-1);
            }
        });

    }

    public void viewLoded(int spnPosition) {
//        position=spnPosition;
    }

    public void cancelNewAlertTripManagement1(int iOfficialTrip, int tiTripStatus) {
        FragmentManager manager = getSupportFragmentManager();
        Fragment frag = manager.findFragmentByTag("dialogConfirm");
        if (frag != null) {
            manager.beginTransaction().remove(frag).commit();
        }
        DialogConfirmCancelTtrip dialogConfirm = new DialogConfirmCancelTtrip(
                "آیا از لغو سفر با کد: " + iOfficialTrip + " مطمئن هستید؟", (des) -> {
            ShowSwpRefresh();
            requestCancelNewAlertTripManagement(iOfficialTrip, position, tiTripStatus, des);
        });
        dialogConfirm.show(manager, "DialogConfirmCancelTtrip");
    }

    public void confirmNewAlertTripManagement1(int iOfficialTrip) {
        ShowSwpRefresh();
        requestConfirmNewAlertTripManagement(iOfficialTrip, position);
    }

    public void cancelConfirmedTripAlertTripManagement1(int iOfficialTrip, int tiTripStatus) {
        FragmentManager manager = getSupportFragmentManager();
        Fragment frag = manager.findFragmentByTag("dialogConfirm");
        if (frag != null) {
            manager.beginTransaction().remove(frag).commit();
        }
        DialogConfirmCancelTtrip dialogConfirm = new DialogConfirmCancelTtrip(
                "آیا از لغو سفر با کد: " + iOfficialTrip + " مطمئن هستید؟", (des) -> {
            ShowSwpRefresh();
            requestCancelNewAlertTripManagement(iOfficialTrip, position, tiTripStatus, des);
        });
        dialogConfirm.show(manager, "DialogConfirmCancelTtrip");

//        ShowSwpRefresh();
//        requestCancelConfirmedTripAlertTripManagement(iOfficialTrip, position, tiTripStatus);
    }

    public void cancelWaitingDriverConfirmedAlertTripManagement1(int iOfficialTrip, int tiTripStatus) {
        FragmentManager manager = getSupportFragmentManager();
        Fragment frag = manager.findFragmentByTag("dialogConfirm");
        if (frag != null) {
            manager.beginTransaction().remove(frag).commit();
        }
        DialogConfirmCancelTtrip dialogConfirm = new DialogConfirmCancelTtrip(
                "آیا از لغو سفر با کد: " + iOfficialTrip + " مطمئن هستید؟", (des) -> {
            ShowSwpRefresh();
            requestCancelNewAlertTripManagement(iOfficialTrip, position, tiTripStatus, des);
        });
        dialogConfirm.show(manager, "DialogConfirmCancelTtrip");

//        ShowSwpRefresh();
//        requestCancelWaitingDriverConfirmedAlertTripManagement(iOfficialTrip, position, tiTripStatus);
    }

    public void confirm_CancelTripAlert1(int iOfficialTrip) {
        ShowSwpRefresh();
        requestCancelTripConfim(iOfficialTrip, position);
    }

    public void cencelTripAlertConfirmResult(int result, int position) {
        HideSwpRefresh();
        if (result == 1) {
            Toaster.shorter("سفر با موفقیت تأیید مجدد شد");
            ShowSwpRefresh();
            requesrListNewTrips(position);
//            ((Activity)context).finish();
        } else if (result == 0) {
            Toaster.shorter("شما قادر به تأیید مجدد سفر نیستید");
        } else if (result == -1) {
            Toaster.shorter(context.getString(R.string.serverFaield));
        } else if (result == -5) {
            Toaster.shorter(context.getString(R.string.connectionFaield));
        } else if (result == 100) {
            Intent intent = new Intent(TripManagementNewActivity.this, LoginActivity.class);
            startActivity(intent);
        }
    }

    public void cencelWaitinDriverConfirmTripAlertResult(int result, int position) {
        HideSwpRefresh();
        if (result == -4) {
            Toaster.shorter(context.getString(R.string.serverFaield));
        } else if (result == -5) {
            Toaster.shorter(context.getString(R.string.connectionFaield));
        } else if (result == 100) {
            Intent intent = new Intent(TripManagementNewActivity.this, LoginActivity.class);
            startActivity(intent);

        } else {
            Toaster.shorter("سفر شما با موفقیت لغو گردید");
            //to update list
            requesrListNewTrips(position);
        }
    }

    public void updateList(int position) {
        HideSwpRefresh();
        spnPosition = position;
        requesrListNewTrips(position);
    }

    public void cencelConfirmTripAlertResult(int result, int position) {
        HideSwpRefresh();
        if (result == -4) {
            Toaster.shorter(context.getString(R.string.serverFaield));
        } else if (result == -5) {
            Toaster.shorter(context.getString(R.string.connectionFaield));
        } else if (result == 100) {
            Intent intent = new Intent(TripManagementNewActivity.this, LoginActivity.class);
            startActivity(intent);

        } else {
            Toaster.shorter("سفر شما با موفقیت لغو گردید");
            //to update list
            requesrListNewTrips(position);
        }
    }

    public void confirmNewTripAlertResult(int result, int position) {
        HideSwpRefresh();
        if (result == 1) {
            Toaster.shorter(App.data.getMessage());
            ShowSwpRefresh();

            //to update list
            requesrListNewTrips(position);

        } else if (result == -2) {
            Toaster.shorter(App.data.getMessage());
        } else if (result == -1) {
            Toaster.shorter(App.data.getMessage());
        } else if (result == -5) {
            Toaster.shorter(context.getString(R.string.connectionFaield));
        } else if (result == 100) {
            Intent intent = new Intent(TripManagementNewActivity.this, LoginActivity.class);
            startActivity(intent);
        }
    }

    public void cencelNewTripAlertResult(int result, int position) {
        HideSwpRefresh();
        if (result == -4) {
            Toaster.shorter(context.getString(R.string.serverFaield));
        } else if (result == -5) {
            Toaster.shorter(context.getString(R.string.connectionFaield));
        } else if (result == 1) {
            Toaster.shorter("سفر شما با موفقیت لغو گردید");
            //to update list
            requesrListNewTrips(position);
        } else if (result == -1) {
            Toaster.shorter(context.getString(R.string.serverFaield));
        } else if (result == 100) {
            Intent intent = new Intent(TripManagementNewActivity.this, LoginActivity.class);
            startActivity(intent);
        }
    }

    public void spnSelected(AdapterView<?> parent, View view1, int position1, long id) {
        spnPosition = position1;
        if (position1 == 0) {// جدید
            ShowSwpRefresh();
            requesrListNewTrips(position1);
            position = position1;
        } else if (position1 == 1) {//تایید شده
            ShowSwpRefresh();
            requesrListNewTrips(position1);
            setBtnVisibility();
            position = position1;
        } else if (position1 == 2) {//منتظر تایید راننده
            ShowSwpRefresh();
            requesrListNewTrips(position1);
            position = position1;
        } else if (position1 == 3) {// در حال اجر
            ShowSwpRefresh();
            requesrListNewTrips(position1);
            position = position1;
        } else if (position1 == 4) {// لغو شده
            ShowSwpRefresh();
            requesrListNewTrips(position1);
            position = position1;
        } else if (position1 == 5) {// سفرهای پیشین پرسنل من
            startActivity(new Intent(getApplicationContext(), TripsBeforeMyStaffActivity.class));
            finish();
        }
    }

    public void spnSelectedConfirmTrip(AdapterView<?> parent, View view1, int position1, long id) {
        spnPosition = position1;
        if (position1 == 0) {//جدید
            ShowSwpRefresh();
            requesrListNewTrips(position1);
            position = position1;
        } else if (position1 == 1) {// سفرهای پیشین پرسنل من
            startActivity(new Intent(getApplicationContext(), TripsBeforeMyStaffActivity.class));
            finish();
        }
    }

    public void spnSelectedOnlyManagement(AdapterView<?> parent, View view1, int position1, long id) {
        spnPosition = position1;
        if (position1 == 0) {//تایید شده
            ShowSwpRefresh();
            requesrListNewTrips(position1);
            setBtnVisibility();
            position = position1;
        } else if (position1 == 1) {//منتظر تایید راننده
            ShowSwpRefresh();
            requesrListNewTrips(position1);
            position = position1;
        } else if (position1 == 2) {//در حال اجر
            ShowSwpRefresh();
            requesrListNewTrips(position1);
            position = position1;
        } else if (position1 == 3) { // لغو شده
            ShowSwpRefresh();
            requesrListNewTrips(position1);
            position = position1;

        }
    }

    public void loadDataResult(int result, int position) {
        HideSwpRefresh();
        if (result == -5) {
            Toaster.shorter(context.getString(R.string.connectionFaield));
        }else if(result==100){
            Intent intent = new Intent(TripManagementNewActivity.this, LoginActivity.class);
            startActivity(intent);
        }
        else if (result == -4) {
            Toaster.shorter(context.getString(R.string.serverFaield));
        } else if (result == 0) {
            showImg_noItem();
        } else if (result == 1) {

            setAdapter(position);
//           view.hideImg_noItem();
            if (position == 0) { // newTrip
                if (App.listNewTripManagementNew.size() > 0) {
//                    Toast.makeText(context, App.data.getMessage(), Toast.LENGTH_SHORT).show();
                    hideImg_noItem();
                } else
                    showImg_noItem();
            } else if (position == 1) {  //confirmTrip
                if (App.listConfirmedTripManagementNew.size() > 0)
                    hideImg_noItem();
                else
                    showImg_noItem();
            } else if (position == 2) {  //driverConfirmTrip
                if (App.listWaitingDriverConfirmTripManagementNew.size() > 0)
                    hideImg_noItem();
                else
                    showImg_noItem();
            } else if (position == 3) {  //runningTrip
                if (App.listRunningTripManagementNew.size() > 0)
                    hideImg_noItem();
                else
                    showImg_noItem();
            } else if (position == 4) {  //cancelTrip
                if (App.listCanceledTripManagementNew.size() > 0)
                    hideImg_noItem();
                else
                    showImg_noItem();
            }
        }
    }

    public void swpRefreshPressed(int position) {
        requesrListNewTrips(position);
    }

    public void imgArrowBackPressed() {
        ((Activity) context).finish();
    }

    public void tripsArchiveResult(int result) {
        if (result == 1) {
            Toaster.longer("سفر شما بایگانی شد");
        } else if (result == -1)
            Toaster.shorter(context.getString(R.string.connectionFaield));
        else if (result == -2)
            Toaster.shorter(context.getString(R.string.serverFaield));
        else if (result == 100) {
            Intent intent=new Intent(TripManagementNewActivity.this, LoginActivity.class);
            startActivity(intent);

        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateList(spn_tripManagementNew.getSelectedItemPosition());
    }
}
