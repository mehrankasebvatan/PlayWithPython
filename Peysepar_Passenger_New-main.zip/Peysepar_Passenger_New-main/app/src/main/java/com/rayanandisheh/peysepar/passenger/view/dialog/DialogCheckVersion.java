package com.rayanandisheh.peysepar.passenger.view.dialog;

import android.annotation.SuppressLint;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

import com.rayanandisheh.peysepar.passenger.R;
import com.rayanandisheh.peysepar.passenger.helpers.EnumTypeVersion;

public class DialogCheckVersion extends DialogFragment implements View.OnClickListener {
    private static final String TAG = "DialogCheckVersion";
    private View view;
    private final String title;
    private final OnClickDialogFinalOrderRegister onClickDialogFinalOrderRegister;
    private EnumTypeVersion enumTypeVersion;

    public interface OnClickDialogFinalOrderRegister {
        void onClick();

        void onCancel();
    }

    public DialogCheckVersion(String title, EnumTypeVersion enumTypeVersion
            , OnClickDialogFinalOrderRegister onClickDialogFinalOrderRegister) {
        this.title = title;
        this.enumTypeVersion = enumTypeVersion;
        this.onClickDialogFinalOrderRegister = onClickDialogFinalOrderRegister;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container
            , @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.dialog_check_version, container, false);
        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        if (enumTypeVersion == EnumTypeVersion.MIN_VALID_VERSION)
            setCancelable(false);
        else
            setCancelable(true);

        getViews();
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
    }

    public void onResume() {
        // Store access variables for window and blank point
        getDialog().getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        getDialog().getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        getDialog().getWindow().getAttributes().windowAnimations = R.style.DialogAnimation;

        Window window = getDialog().getWindow();
        WindowManager.LayoutParams wlp = window.getAttributes();
        wlp.gravity = Gravity.BOTTOM;
        wlp.flags = WindowManager.LayoutParams.FLAG_DIM_BEHIND;
        window.setAttributes(wlp);
        super.onResume();
    }

    @SuppressLint("ClickableViewAccessibility")
    private void getViews() {
        Button btn_dialog_sumbit = view.findViewById(R.id.btn_dialog_sumbit);
        Button btn_dialog_cancel = view.findViewById(R.id.btn_dialog_cancel);
        TextView tv_dialog = view.findViewById(R.id.tv_dialog);

        tv_dialog.setText(title);

        btn_dialog_sumbit.setOnClickListener(this);
        btn_dialog_cancel.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.btn_dialog_sumbit) {
            onClickDialogFinalOrderRegister.onClick();
            dismiss();
        }
        if (v.getId() == R.id.btn_dialog_cancel) {
            onClickDialogFinalOrderRegister.onCancel();
            dismiss();
        }
    }

}

