package com.rayanandisheh.peysepar.passenger.view.Adapter;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import com.rayanandisheh.peysepar.passenger.view.fragment.TripCanceledFragment;
import com.rayanandisheh.peysepar.passenger.view.fragment.TripConfirmedFragment;
import com.rayanandisheh.peysepar.passenger.view.fragment.TripDashboardFragment;
import com.rayanandisheh.peysepar.passenger.view.fragment.TripDriverConfirmedFragment;
import com.rayanandisheh.peysepar.passenger.view.fragment.TripNewFragment;
import com.rayanandisheh.peysepar.passenger.view.fragment.TripRunningFragment;

public class PageAdapter extends FragmentPagerAdapter {

    private int numOfTabs;

    public PageAdapter(FragmentManager fm, int numOfTabs) {
        super(fm);
        this.numOfTabs = numOfTabs;
    }

    @Override
    public Fragment getItem(int position) {
        switch (position) {
            case 0:
                return new TripNewFragment();

            case 1:
                return new TripConfirmedFragment();

            case 2:
                return new TripDriverConfirmedFragment();

            case 3:
                return new TripRunningFragment();

            case 4:
                return new TripCanceledFragment();

            case 5:
                return new TripDashboardFragment();

            default:
                return null;
        }
    }

    @Override
    public int getCount() {
        return numOfTabs;
    }
}