package com.rayanandisheh.peysepar.passenger.view.Activity;

import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

import com.rayanandisheh.peysepar.passenger.R;
import com.vansuita.pickimage.bundle.PickSetup;
import com.vansuita.pickimage.dialog.PickImageDialog;

public class PassengerProfActivity extends AppCompatActivity  {
    private static final String TAG = "PassengerProfActivity";

//    Context context = this;
//    TextView txtMobileProfile, tvProfilePic, txtSelectedPositionName, txtOrgPosition;
//    RoundedImageView ivProfilePic;
//    Bitmap bmProfile;
//    EditText edtNameProfile, edtFamilyProfile, edtNationalIDProfile, edtOptionalOrigin;
//    //    RadioGroup radioGroup;
//    RadioButton rbMan;
//    Button btn;
//    ProgressBar pb;
//    ImageView ivWarningProfileName, ivWarningProfileFamily, ivWarningProfileNcode;
//    RelativeLayout rlChoosePermanentOrigin;
//
//    CheckBox chkProfile;
//    Toolbar toolbar;
//    public static final int PICK_IMAGE = 1;
//    public static final int MY_REQUEST_CODE = 3;
//    BroadcastReceiver mBroadcastReceiverProfile = new BroadcastReceiver() {
//        @Override
//        public void onReceive(Context context, Intent intent) {
////            receivedBroadcast(intent);
//        }
//    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_passenger_prof);
        ImageView img = findViewById(R.id.jjjjjj);
        //getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                Toast.makeText(PassengerProfActivity.this, "sjfdlksjdf",
//                        Toast.LENGTH_SHORT).show();

                PickImageDialog.build(new PickSetup()).show(PassengerProfActivity.this);

            }
        });

//        bindView();

//        try {
//            String pic = App.userInfo.getImgLink();
//            Picasso.get().load(pic).placeholder(R.drawable.ic_account).
//                    error(R.drawable.ic_account).
//                    fit().
//                    memoryPolicy(MemoryPolicy.NO_CACHE, MemoryPolicy.NO_STORE).
//                    networkPolicy(NetworkPolicy.NO_CACHE, NetworkPolicy.NO_STORE).
//                    into(ivProfilePic);
//        } catch (Exception ignore) {
//        }

//        ivProfilePic.setOnClickListener(v -> {
//            choosePic("تصویر پروفایل");
//        });
    }

//    private void choosePic(String title) {
//        PickImageDialog.build(new PickSetup()).show(this);
//        PickImageDialog.build(new PickSetup())
//                .setOnPickResult(new IPickResult() {
//                    @Override
//                    public void onPickResult(PickResult r) {
//                        //TODO: do what you have to...
//                    }
//                })
//                .setOnPickCancel(new IPickCancel() {
//                    @Override
//                    public void onCancelClick() {
//                        //TODO: do what you have to if user clicked cancel
//                    }
//                }).show(getSupportFragmentManager());
//    }

//    private void bindView() {

//        toolbar = findViewById(R.id.toolbar_profile1);
//        setSupportActionBar(toolbar);
//        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
//        getSupportActionBar().setDisplayShowHomeEnabled(true);
//        getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
//        setTitle("پروفایل");

//        btn = findViewById(R.id.btnProfile1);
//        pb = findViewById(R.id.pbProfile1);
//        edtNameProfile = findViewById(R.id.edtNameProfile1);
//        edtFamilyProfile = findViewById(R.id.edtFamilyProfile1);
//        edtNationalIDProfile = findViewById(R.id.edtNationalIDProfile1);
//        rbMan = findViewById(R.id.rbMan1);
//        txtMobileProfile = findViewById(R.id.txtMobileProfile1);
//        ivProfilePic = findViewById(R.id.newimg);
//        tvProfilePic = findViewById(R.id.txtprofilepicture1);
//        ivWarningProfileName = findViewById(R.id.ivWarningProfileName1);
//        ivWarningProfileFamily = findViewById(R.id.ivWarningProfileFamily1);
//        ivWarningProfileNcode = findViewById(R.id.ivWarningProfileNcode1);
//        rlChoosePermanentOrigin = findViewById(R.id.rlChoosePermanentOrigin1);
//        txtSelectedPositionName = findViewById(R.id.txtSelectedPositionName1);
//        edtOptionalOrigin = findViewById(R.id.edtOptionalOrigin1);
//        chkProfile = findViewById(R.id.chkProfile1);
//        txtOrgPosition = findViewById(R.id.txtOrgPosition1);

//    }

//    @Override
//    public void onPickResult(PickResult r) {
//        Log.d(TAG, "onPickResult: ");
//    }
}
