package com.rayanandisheh.peysepar.passenger.models;

import com.google.gson.annotations.SerializedName;

public class News {

    @SerializedName("iNews")
    private int iNews ;
    @SerializedName("strContent")
    private String strContent ;
    @SerializedName("strTitle")
    private String strTitle ;
    @SerializedName("strDateTime")
    private String strDateTime ;
    @SerializedName("bVisit")
    private boolean bVisit ;
    @SerializedName("bArchive")
    private boolean bArchive ;
    @SerializedName("strValidDate")
    private String strValidDate ;
    @SerializedName("bImportance")
    private boolean bImportance ;
    @SerializedName("url")
    private String url ;


    public int getiNews() {
        return iNews;
    }

    public void setiNews(int iNews) {
        this.iNews = iNews;
    }

    public String getStrContent() {
        return strContent;
    }

    public void setStrContent(String strContent) {
        this.strContent = strContent;
    }

    public String getStrTitle() {
        return strTitle;
    }

    public void setStrTitle(String strTitle) {
        this.strTitle = strTitle;
    }

    public String getStrDateTime() {
        return strDateTime;
    }

    public void setStrDateTime(String strDateTime) {
        this.strDateTime = strDateTime;
    }

    public boolean isbVisit() {
        return bVisit;
    }

    public void setbVisit(boolean bVisit) {
        this.bVisit = bVisit;
    }

    public boolean isbArchive() {
        return bArchive;
    }

    public void setbArchive(boolean bArchive) {
        this.bArchive = bArchive;
    }

    public String getStrValidDate() {
        return strValidDate;
    }

    public void setStrValidDate(String strValidDate) {
        this.strValidDate = strValidDate;
    }

    public boolean isbImportance() {
        return bImportance;
    }

    public void setbImportance(boolean bImportance) {
        this.bImportance = bImportance;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
