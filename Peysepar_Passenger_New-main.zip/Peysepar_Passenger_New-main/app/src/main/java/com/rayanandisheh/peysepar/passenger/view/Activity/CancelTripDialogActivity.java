package com.rayanandisheh.peysepar.passenger.view.Activity;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.view.WindowManager;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import com.rayanandisheh.peysepar.passenger.R;
import com.rayanandisheh.peysepar.passenger.helpers.App;
import com.rayanandisheh.peysepar.passenger.helpers.Cache;
import com.rayanandisheh.peysepar.passenger.helpers.PersianAppcompatActivity;
import com.rayanandisheh.peysepar.passenger.models.Register;
import com.rayanandisheh.peysepar.passenger.models.UserInfo;
import com.rayanandisheh.peysepar.passenger.services.APIClient;
import com.rayanandisheh.peysepar.passenger.services.APIService;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CancelTripDialogActivity extends PersianAppcompatActivity {

    Context context = this;

    @SuppressLint("LongLogTag")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cancel_trip_dialog);
        //getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        androidx.appcompat.app.AlertDialog.Builder dialog1 = new androidx.appcompat.app.AlertDialog.Builder(context);
        dialog1.setMessage("کدسفر : " + App.notifModel.getiOfficialTrip() + "\n \n" + App.notifModel.getMessage());
        if (App.notifModel.getType().equals("ManageRequest")) {
            dialog1.setPositiveButton("تأیید", (dialog2, which) -> setFinish());
        } else
            dialog1.setPositiveButton("تأیید", (dialog2, which) -> finish());
        dialog1.setCancelable(false);
        dialog1.show();

    }

    private void setFinish() {

        if (App.IsRun) {
            startActivity(new Intent(context, TripManagementNewActivity.class));
        } else
            startActivity(new Intent(context, SplashActivity.class));
    }

    @SuppressLint({"HardwareIds", "MissingPermission"})
    public String getDeviceIMEI() {

        String deviceUniqueIdentifier = null;
        TelephonyManager tm = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
        if (null != tm) {
//            if (ActivityCompat.checkSelfPermission(context, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED)
            if (ActivityCompat.checkSelfPermission(context, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED)

                ActivityCompat.requestPermissions((Activity) context, new String[]{Manifest.permission.READ_PHONE_STATE}, 3);
            else
                deviceUniqueIdentifier = tm.getDeviceId();
            if (null == deviceUniqueIdentifier || 0 == deviceUniqueIdentifier.length())
                deviceUniqueIdentifier = "0";
        }
        return deviceUniqueIdentifier;
    }

    private void request(Register register) {
        APIService apiService = APIClient.getClient().create(APIService.class);
        Call<UserInfo> call = apiService.Login(register);
        call.enqueue(new Callback<UserInfo>() {
            @Override
            public void onResponse(@NonNull Call<UserInfo> call, @NonNull Response<UserInfo> response) {
                if (response.code() == 200) {
                    App.userInfo = response.body();
                    App.register.setStrMobile(register.getStrMobile());
                    Cache.setString("logo",response.body().getStrLogo());
                    assert response.body() != null;
                } else
                    Toast.makeText(context, "خطا در برقراری ارتباط با سرور", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onFailure(@NonNull Call<UserInfo> call, @NonNull Throwable t) {
                Toast.makeText(context, "لطفا از اتصال دستگاه خود به اینترنت مطمئن شوید", Toast.LENGTH_SHORT).show();
            }
        });
    }


}

