package com.rayanandisheh.peysepar.passenger.view.Activity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.util.Log;
import android.view.WindowManager;

import androidx.appcompat.app.AppCompatActivity;

import com.rayanandisheh.peysepar.passenger.R;
import com.rayanandisheh.peysepar.passenger.helpers.Cache;

public class InternetCheckActivity extends AppCompatActivity {

    private static final String TAG = "InternetCheckActivity";
    private CheckNetwork checkNetwork;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_internet_check);
        //getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE)
    }

    @Override
    protected void onStart() {
        super.onStart();
        checkNetwork = new CheckNetwork();
        registerReceiver(checkNetwork, new IntentFilter("android.net.conn.CONNECTIVITY_CHANGE"));
    }

    @Override
    protected void onStop() {
        unregisterReceiver(checkNetwork);
        super.onStop();
    }

    private class CheckNetwork extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {
            ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
            NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
            boolean isConnected = networkInfo != null && networkInfo.isConnectedOrConnecting();

            if(isConnected){
//                Toast.makeText(context, "اینترنت وصل است", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(InternetCheckActivity.this, SplashActivity.class));
                finish();

            }else{
//                Toast.makeText(context, "لطفا اتصال دستگاه  به اینترنت را چک کنید", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
