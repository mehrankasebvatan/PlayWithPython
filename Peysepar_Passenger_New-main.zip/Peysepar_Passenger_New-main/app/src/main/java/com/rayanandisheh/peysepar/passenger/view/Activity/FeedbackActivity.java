package com.rayanandisheh.peysepar.passenger.view.Activity;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.RatingBar;

import com.rayanandisheh.peysepar.passenger.R;
import com.rayanandisheh.peysepar.passenger.customes.mAppCompatActivity;
import com.rayanandisheh.peysepar.passenger.helpers.Toaster;

public class FeedbackActivity extends mAppCompatActivity  {

    Context context;
    Button btFeedback;
    ProgressBar pbFeedback;
    RatingBar ratingBar;
    EditText etFeedback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feedback);
        //getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        bindViews();
        context = this;
    }

    private void bindViews() {
        context = this;
        btFeedback = findViewById(R.id.btFeedback);
        pbFeedback = findViewById(R.id.pbFeedback);
        ratingBar = findViewById(R.id.ratingBar);
        etFeedback = findViewById(R.id.etFeedback);

        btFeedback.setOnClickListener(v -> submit(etFeedback.getText(), ratingBar.getRating()));
    }

    public void showLoading() {
        btFeedback.setVisibility(View.GONE);
        pbFeedback.setVisibility(View.VISIBLE);
    }

    public void stopLoading() {
        pbFeedback.setVisibility(View.GONE);
        btFeedback.setVisibility(View.VISIBLE);
    }

    public void submitFeedback(Editable feedback, int rate) {
//        APIService apiService = APIClient.getClient().create(APIService.class);
//        Call<Integer> call = apiService.feedback(feedback, rate);
//        call.enqueue(new Callback<Integer>() {
//            @Override
//            public void onResponse(@NonNull Call<Integer> call, @NonNull Response<Integer> response) {
//                if (response.code() == 200)
//                    presenter.feedbackResult(response.body());
//                else
//                    presenter.feedbackResult(-4);
//            }
//
//            @Override
//            public void onFailure(@NonNull Call<Integer> call, @NonNull Throwable t) {
//                presenter.feedbackResult(-5);
//            }
//        });
    }

    public void submit(Editable feedback, float rating) {
        showLoading();
        submitFeedback(feedback, (int) (rating * 20));
    }

    public void feedbackResult(int result) {
        stopLoading();
        switch (result) {
            case -5:
                Toaster.shorter(context.getString(R.string.connectionFaield));
                break;
            case -4:
                Toaster.shorter(context.getString(R.string.serverFaield));
                break;
            case 1:
                Toaster.shorter(context.getString(R.string.successfullySubmited));
                ((Activity) context).finish();
                break;
            default:
                break;
        }
    }
}
