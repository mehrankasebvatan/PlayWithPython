package com.rayanandisheh.peysepar.passenger.view.Activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RatingBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.cardview.widget.CardView;

import com.rayanandisheh.peysepar.passenger.R;
import com.rayanandisheh.peysepar.passenger.helpers.App;
import com.rayanandisheh.peysepar.passenger.helpers.PersianAppcompatActivity;
import com.rayanandisheh.peysepar.passenger.helpers.Time;
import com.rayanandisheh.peysepar.passenger.helpers.Toaster;
import com.rayanandisheh.peysepar.passenger.models.Trip;
import com.rayanandisheh.peysepar.passenger.services.APIClient;
import com.rayanandisheh.peysepar.passenger.services.APIService;

import org.jetbrains.annotations.NotNull;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class OKdriverActivity extends PersianAppcompatActivity {

    Context context = this;
    TextView
            txtPursuitCode_currntDtls, txtTripStatus_currntDtls, txtRequestDate_Time_currntDtls, txtPassengerNames_currntDtls,
            txtSupposedDate_Time_currntDtls, txtOriginName_currntDtls, txtDesName_currntDtls, txtReasonImportance_currntDtls,
            txtVehicleType_currentTrip, txtTripType_currntDtls, txtEmptyCommentCurrentTripDetail,
            txtComment_currntDtls, txtDriverName_currentTrip, txtCarModel_currntDtls,
            txtArrivingTimeCalculate_currntDtls, txtTripPreparationTime_currntDtls, txtStartTripTime_currntDtls,
            txtFinishTripDateTime_currntDtls, txtTripDurationTime_currntDtls, txt1_NPlate_crntDtls, txt2_NPlate_crntDtls,
            txt3_NPlate_crntDtls, txt4_NPlate_crntDtls, txtImportance_currentTripDetail1, txtCarName_currntDtls1;


    RatingBar rate_currntDtls;
    ImageView imgStar, imgCall;
    RelativeLayout rlCancelTrip, rlTripType;
    Button btnCancelCurrentTripDetails;
    ProgressBar pbCancelCurrentTripDetails;
    LinearLayout llDriverName, llCarType, linearOkdriver;
    CardView cvDriverInfo_currntDtls, cvDateTime__currntDtls;
    //no need to make it new
    Trip model = new Trip();
    int cancelTripResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_okdriver2);

        bindView();
        //getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE)

        if (App.model2.getiOfficialTrip() != 0) {
            model = App.model2;
        }
        try {

            txtPursuitCode_currntDtls.setText(String.valueOf(model.getiOfficialTrip()));
            txtTripStatus_currntDtls.setText(model.getStrOfficialStatus_strComment());
            if (model.getStrRequestTime().trim() != null && model.getStrRequestDate() != null)
                txtRequestDate_Time_currntDtls.setText(model.getStrRequestTime().trim() + " - " + model.getStrRequestDate());
            txtPassengerNames_currntDtls.setText(model.getStrPassengers());
            txtSupposedDate_Time_currntDtls.setText(model.getStrTripTime() + " - " + model.getStrTripDate());
            txtOriginName_currntDtls.setText(model.getStrOriginAddress());
            txtDesName_currntDtls.setText(model.getStrDestinationAddress());
            txtReasonImportance_currntDtls.setText(model.getStrTripReason_strComment() + " - " + model.getStrTripImportance_strComment());
            //todo below should be model.getStrMobile(savari sangin....)
            txtVehicleType_currentTrip.setText(model.getStrMobileType());
        }catch (Exception ignored){

        }

        cvDateTime__currntDtls.setVisibility(View.GONE);

//        if (model.getStrRedy4TrimpTime() == null || model.getStrFinishDate() == null || model.getStrTrimpFinishTime() == null){
//            cvDateTime__currntDtls.setVisibility(View.GONE);
//        }else
//            cvDateTime__currntDtls.setVisibility(View.VISIBLE);

        if (model.isbExclusive() || model.isbHaveReturn() || model.isbMission()) {
            rlTripType.setVisibility(View.VISIBLE);
        } else
            rlTripType.setVisibility(View.GONE);


        if (model.isbHaveReturn())
            txtTripType_currntDtls.setText("دارای برگشت");
        else if (model.isbExclusive())
            txtTripType_currntDtls.setText("در اختیار");
        else if (model.isbMission())
            txtTripType_currntDtls.setText("ماموریتی");


        if (model.getStrComment().length() != 0)
            txtComment_currntDtls.setText(model.getStrComment());
        else
            txtEmptyCommentCurrentTripDetail.setText("-");

        txtDriverName_currentTrip.setText(model.getStrDriverName());
        txtCarModel_currntDtls.setText(model.getStrMobileType());
//        txtArrivingTimeCalculate_currntDtls.setText(model.getStrEstRedy4TrimpTime());
        txtTripPreparationTime_currntDtls.setText(model.getStrRedy4TrimpTime());
        txtStartTripTime_currntDtls.setText(model.getStrTripTime());
        txtFinishTripDateTime_currntDtls.setText(model.getStrFinishDate() + "-" + model.getStrTrimpFinishTime());
        txtImportance_currentTripDetail1.setText(model.getStrTripImportance_strComment());

        txtCarName_currntDtls1.setText(model.getStrGPSType_strComment());

        if (model.getStrTrimTimeEstimate() != null)
            txtTripDurationTime_currntDtls.setText(Time.minutesToHours(model.getStrTrimTimeEstimate()));

        else
            txtTripDurationTime_currntDtls.setText("0" + " " + "دقیقه");


        if (model.getStrEstRedy4TrimpTime() != null)
            txtArrivingTimeCalculate_currntDtls.setText(Time.minutesToHours(model.getStrEstRedy4TrimpTime()));
        else
            txtArrivingTimeCalculate_currntDtls.setText("0" + " " + "دقیقه");


        rate_currntDtls.setRating(model.getiSatisfication() / 20);


        switch (model.getStrTripImportance_strComment()) {
            case "عادی":
                imgStar.setImageDrawable(getResources().getDrawable(R.drawable.star1));
                break;
            case "فوری":
                imgStar.setImageDrawable(getResources().getDrawable(R.drawable.star2));
                break;
            case "خیلی فوری":
                imgStar.setImageDrawable(getResources().getDrawable(R.drawable.star3));
                break;
        }

        if (model.getTiTripStatus() == 0 || model.getTiTripStatus() == 1 || model.getTiTripStatus() == 2 || model.getTiTripStatus() == 3)
            rlCancelTrip.setVisibility(View.VISIBLE);
        else if (model.getTiTripStatus() == 5 || model.getTiTripStatus() == 6 || model.getTiTripStatus() == 7)
            rlCancelTrip.setVisibility(View.GONE);


        if (model.getTiTripStatus() == 0 || model.getTiTripStatus() == 1) {
            cvDriverInfo_currntDtls.setVisibility(View.GONE);
        } else {
            cvDriverInfo_currntDtls.setVisibility(View.VISIBLE);
        }

        if (model.getTiTripStatus() != 0 && model.getTiTripStatus() != 1) {
            //numberPlate
            String numberPlate = model.getStrVehicleNo();
            txt1_NPlate_crntDtls.setText(numberPlate.substring(0, 2));
            txt2_NPlate_crntDtls.setText(numberPlate.substring(3, 4));
            txt3_NPlate_crntDtls.setText(numberPlate.substring(5, 8));
            txt4_NPlate_crntDtls.setText(numberPlate.substring(11));
        }

        btnCancelCurrentTripDetails.setOnClickListener(v -> {
            AlertDialog.Builder dialog = new AlertDialog.Builder(context);
            dialog.setMessage("آیا از لغو سفر با کد:" + model.getiOfficialTrip() + " مطمئن هستید؟");
            dialog.setPositiveButton("بله", (dialog1, which) -> btnCanceledPressed(model));
            dialog.setNegativeButton("خیر", (dialog12, which) -> dialog12.dismiss());
            dialog.create().show();
        });

        imgCall.setOnClickListener(v -> btnCallPressed(model.getDriverMobile()));

    }

    private void btnCallPressed(String driverMobile) {

        Intent intent = new Intent(Intent.ACTION_DIAL);
        intent.setData(Uri.parse("tel:" + driverMobile));
        context.startActivity(intent);
    }

    private void bindView() {

        txtPursuitCode_currntDtls = findViewById(R.id.txtPursuitCode_currntDtls1);
        txtTripStatus_currntDtls = findViewById(R.id.txtTripStatus_currntDtls1);
        txtRequestDate_Time_currntDtls = findViewById(R.id.txtRequestDate_Time_currntDtls1);
        txtPassengerNames_currntDtls = findViewById(R.id.txtPassengerNames_currntDtls1);
        txtSupposedDate_Time_currntDtls = findViewById(R.id.txtSupposedDate_Time_currntDtls1);
        txtOriginName_currntDtls = findViewById(R.id.txtOriginName_currntDtls1);
        txtDesName_currntDtls = findViewById(R.id.txtDesName_currntDtls1);
        txtReasonImportance_currntDtls = findViewById(R.id.txtReasonImportance_currntDtls1);
        txtVehicleType_currentTrip = findViewById(R.id.txtVehicleType_currentTrip1);
        txtTripType_currntDtls = findViewById(R.id.txtTripType_currntDtls1);
        txtEmptyCommentCurrentTripDetail = findViewById(R.id.txtEmptyCommentCurrentTripDetail1);
        txtComment_currntDtls = findViewById(R.id.txtComment_currntDtls1);
        txtDriverName_currentTrip = findViewById(R.id.txtDriverName_currentTrip1);
//        txtNumberPlate_currntDtls = findViewById(R.id.txtNumberPlate_currntDtls);
        txtCarModel_currntDtls = findViewById(R.id.txtCarModel_currntDtls1);
        txtArrivingTimeCalculate_currntDtls = findViewById(R.id.txtArrivingTimeCalculate_currntDtls1);
        txtTripPreparationTime_currntDtls = findViewById(R.id.txtTripPreparationTime_currntDtls1);
        txtStartTripTime_currntDtls = findViewById(R.id.txtStartTripTime_currntDtls1);
        txtFinishTripDateTime_currntDtls = findViewById(R.id.txtFinishTripDateTime_currntDtls1);
        txtTripDurationTime_currntDtls = findViewById(R.id.txtTripDurationTime_currntDtls1);
        txt1_NPlate_crntDtls = findViewById(R.id.txt1_NPlate_crntDtls1);
        txt2_NPlate_crntDtls = findViewById(R.id.txt2_NPlate_crntDtls1);
        txt3_NPlate_crntDtls = findViewById(R.id.txt3_NPlate_crntDtls1);
        txt4_NPlate_crntDtls = findViewById(R.id.txt4_NPlate_crntDtls1);

        rate_currntDtls = findViewById(R.id.rate_currntDtls1);
        rlCancelTrip = findViewById(R.id.rlCancelTrip1);
        btnCancelCurrentTripDetails = findViewById(R.id.btnCancelCurrentTripDetails1);
        pbCancelCurrentTripDetails = findViewById(R.id.pbCancelCurrentTripDetails1);
        llDriverName = findViewById(R.id.llDriverName1);
        llCarType = findViewById(R.id.llCarType1);
        imgStar = findViewById(R.id.imgStar_currentTripDetail1);
        imgCall = findViewById(R.id.imgCall_currntDtls1);
        cvDriverInfo_currntDtls = findViewById(R.id.cvDriverInfo_currntDtls1);
        cvDateTime__currntDtls = findViewById(R.id.cvDateTime__currntDtls1);
        rlTripType = findViewById(R.id.rlTripType_currntDtls1);
        txtImportance_currentTripDetail1 = findViewById(R.id.txtImportance_currentTripDetail1);

        txtCarName_currntDtls1 = findViewById(R.id.txtCarName_currntDtls1);
    }

    private void btnCanceledPressed(Trip model) {

        APIService apiService = APIClient.getClient().create(APIService.class);
        Call<Integer> call = apiService.cancelTrip(model, "",App.Session);

        call.enqueue(new Callback<Integer>() {
            @Override
            public void onResponse(Call<Integer> call, Response<Integer> response) {
                if (response.code() == 200 && response.body() != null) {
                    hideProgressBar();
                    cancelTripResult = response.body();
                    if (cancelTripResult == 1) {
                        Toaster.shorter("سفر با موفقیت لغو شد");
                        ((Activity) context).finish();
                    } else if (cancelTripResult == 0) {
                        Toaster.shorter("شما قادر به لغو سفر نیستید");
                    }
                } else if (cancelTripResult == -1) {
                    Toaster.shorter(context.getString(R.string.serverFaield));
                }
                else if (cancelTripResult == 100) {
                        Intent intent=new Intent(OKdriverActivity.this, LoginActivity.class);
                        startActivity(intent);
                }

            }

            @Override
            public void onFailure(@NotNull Call<Integer> call, Throwable t) {
                Toaster.shorter(context.getString(R.string.connectionFaield));

            }
        });
    }

    public void showProgressBar() {
        pbCancelCurrentTripDetails.setVisibility(View.VISIBLE);
        btnCancelCurrentTripDetails.setVisibility(View.GONE);
    }

    public void hideProgressBar() {
        pbCancelCurrentTripDetails.setVisibility(View.GONE);
        btnCancelCurrentTripDetails.setVisibility(View.VISIBLE);
    }

}

