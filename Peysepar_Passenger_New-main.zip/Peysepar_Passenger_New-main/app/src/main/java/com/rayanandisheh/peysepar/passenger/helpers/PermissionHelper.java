package com.rayanandisheh.peysepar.passenger.helpers;

import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import androidx.core.app.ActivityCompat;
import com.marcoscg.easypermissions.EasyPermissions;


public class PermissionHelper {

    static String[] permissions = {
            EasyPermissions.ACCESS_FINE_LOCATION,
            EasyPermissions.ACCESS_COARSE_LOCATION,
            EasyPermissions.WRITE_EXTERNAL_STORAGE,
            EasyPermissions.READ_PHONE_STATE};

    public static void RequestPermission(Activity activity){
        int requestCode = 0;
        EasyPermissions.requestPermissions(activity, permissions, requestCode);
    }


    public static Boolean CheckPermission(Context context) {

        Boolean BlnPermission = true;
        for (int i = 0; i < permissions.length; i++) {
            String permission = permissions[i];

            if (ActivityCompat.checkSelfPermission(context,permission) != PackageManager.PERMISSION_GRANTED) {
                BlnPermission = false;
            }
        }

        return  BlnPermission;
    }



    public static void RequestPermissionLOCATION(Activity activity){
        int requestCode = 1;
         String[] permissions = {
                EasyPermissions.ACCESS_FINE_LOCATION,
                EasyPermissions.ACCESS_COARSE_LOCATION};
        EasyPermissions.requestPermissions(activity, permissions, requestCode);
    }

    public static Boolean CheckPermissionLOCATION(Context context) {
        Boolean BlnPermission = true;
            String permission = EasyPermissions.ACCESS_FINE_LOCATION;
            if (ActivityCompat.checkSelfPermission(context,permission) != PackageManager.PERMISSION_GRANTED) {
                BlnPermission = false;
            }
        return  BlnPermission;
    }


    public static void RequestPermissionREAD_PHONE_STATE(Activity activity){
        int requestCode =2;
        String[] permissions = {
                EasyPermissions.READ_PHONE_STATE};
        EasyPermissions.requestPermissions(activity, permissions, requestCode);
    }

    public static Boolean CheckPermissionREAD_PHONE_STATE(Context context) {
        Boolean BlnPermission = true;
        String permission = EasyPermissions.READ_PHONE_STATE;
        if (ActivityCompat.checkSelfPermission(context,permission) != PackageManager.PERMISSION_GRANTED) {
            BlnPermission = false;
        }
        return  BlnPermission;
    }




    public static void RequestPermissionWRITE_EXTERNAL_STORAGE(Activity activity){
        int requestCode =3;
        String[] permissions = {
                EasyPermissions.WRITE_EXTERNAL_STORAGE};
        EasyPermissions.requestPermissions(activity, permissions, requestCode);
    }

    public static Boolean CheckPermissionWRITE_EXTERNAL_STORAGE(Context context) {
        Boolean BlnPermission = true;
        String permission = EasyPermissions.WRITE_EXTERNAL_STORAGE;
        if (ActivityCompat.checkSelfPermission(context,permission) != PackageManager.PERMISSION_GRANTED) {
            BlnPermission = false;
        }
        return  BlnPermission;
    }
}
