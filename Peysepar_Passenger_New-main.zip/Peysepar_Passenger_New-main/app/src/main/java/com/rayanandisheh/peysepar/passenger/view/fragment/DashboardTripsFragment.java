package com.rayanandisheh.peysepar.passenger.view.fragment;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.rayanandisheh.peysepar.passenger.R;
import com.rayanandisheh.peysepar.passenger.helpers.App;
import com.rayanandisheh.peysepar.passenger.helpers.MyValueFormatter;
import com.rayanandisheh.peysepar.passenger.helpers.Time;
import com.rayanandisheh.peysepar.passenger.helpers.Toaster;
import com.rayanandisheh.peysepar.passenger.models.Dashboard;
import com.rayanandisheh.peysepar.passenger.services.APIClient;
import com.rayanandisheh.peysepar.passenger.services.APIService;
import com.rayanandisheh.peysepar.passenger.view.Activity.LoginActivity;
import com.rayanandisheh.peysepar.passenger.view.Activity.TripManagementNewActivity;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DashboardTripsFragment extends Fragment {
    Context context;

    BarChart chart;
    ArrayList<BarEntry> BARENTRY;
    ArrayList<String> BarEntryLabels;
    BarDataSet Bardataset;
    BarData BARDATA;

    SwipeRefreshLayout swp_refresh;

    TextView txtTotalRunningCarCount, txtTotalReadyCarsCount, txtTotalKMDashboard, txtTotalTripTimeDashboard;

    public DashboardTripsFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(@NotNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_dashboard_trips, container, false);

        context = getContext();
        bindView(view);
        viewLoaded();

        return view;
    }

    private void bindView(View view) {
        chart = view.findViewById(R.id.chartDashboardTripFragment);
        swp_refresh = view.findViewById(R.id.swp_refreshDashboardTripFragment);
    }

    public void AddValuesToBarEntryLabels() {
        BarEntryLabels.add("ثبت شده");
        BarEntryLabels.add("تایید");
        BarEntryLabels.add("اختصاص راننده");
        BarEntryLabels.add("لغو شده");
        BarEntryLabels.add("پایان یافته");
    }

    public void AddValuesToBARENTRY() {
        BARENTRY.add(new BarEntry(App.dashboard.getCountInsertTrip(), 0));
        BARENTRY.add(new BarEntry(App.dashboard.getCountConfirmTrip(), 1));
        BARENTRY.add(new BarEntry(App.dashboard.getCountAssignDriverTrip(), 2));
        BARENTRY.add(new BarEntry(App.dashboard.getCountCanceledTrip(), 3));
        BARENTRY.add(new BarEntry(App.dashboard.getCountEndedTrip(), 4));
    }

    public void requestLoadingDashboardInfos() {
        App.score.setStrDate(Time.getNowPersianDate());
        App.score.setiMobileDomain(App.userInfo.getiMobileDomain());

        APIService apiService = APIClient.getClient().create(APIService.class);
        Call<Dashboard> call = apiService.Dashboard(App.score,App.Session);
        call.enqueue(new Callback<Dashboard>() {
            @Override
            public void onResponse(@NotNull Call<Dashboard> call, @NotNull Response<Dashboard> response) {
                if (response.code() == 200 && response.body() != null) {
                    App.dashboard = response.body();
                    dashboardTripResult(response.body().getResult());
                } else {
                    dashboardTripResult(-4);
                }
            }

            @Override
            public void onFailure(@NotNull Call<Dashboard> call, @NotNull Throwable t) {
                dashboardTripResult(-5);
            }
        });
    }

    public void showSwpRefresh() {
        swp_refresh.setRefreshing(true);
    }

    public void hideSwipRefresh() {
        swp_refresh.setRefreshing(false);
    }

    public void ResultOK() {
//        chart = findViewById(R.id.chart);
        BARENTRY = new ArrayList<>();

        BarEntryLabels = new ArrayList<String>();
        AddValuesToBARENTRY();
        AddValuesToBarEntryLabels();
        Bardataset = new BarDataSet(BARENTRY, "Projects");
        BARDATA = new BarData(BarEntryLabels, Bardataset);
        int[] colors = new int[]{
                Color.argb(255, 79, 129, 189) //blue
                , Color.argb(255, 155, 187, 89)   //green
                , Color.argb(255, 128, 100, 162)   // violet
                , Color.argb(255, 192, 80, 77)     //red
                , Color.argb(255, 66, 152, 175)   //blue_green mixed
                , Color.argb(255, 221, 157, 157)    //pink
                , Color.argb(255, 219, 132, 61)    //orange
                , Color.argb(255, 66, 152, 175)};     //blue_green mixed
        Bardataset.setColors(colors);

        chart.setData(BARDATA);
        chart.animateY(500);
        chart.setDescription("");
        chart.getLegend().setEnabled(false);
        chart.setDoubleTapToZoomEnabled(false);

//        chart.setDrawBorders(false);


        XAxis xAxis = chart.getXAxis();
        xAxis.setLabelsToSkip(0);
        //Typeface font = Typeface.createFromAsset(getContext().getAssets(), "IRANSansMobile.ttf");
        //xAxis.setTypeface(font);
        xAxis.setTextSize(11f);
        xAxis.setTextColor(Color.argb(255, 0, 51, 102));
        xAxis.setEnabled(true);

        YAxis yAxisRight = chart.getAxisRight();
        yAxisRight.setDrawLabels(false);
        yAxisRight.setEnabled(false);

        YAxis yAxisLeft = chart.getAxisLeft();
        yAxisLeft.setEnabled(false);
        chart.getAxisLeft().setDrawGridLines(false);
        chart.getXAxis().setDrawGridLines(false);
        BARDATA.setValueFormatter(new MyValueFormatter());
    }

    public void viewLoaded() {
        showSwpRefresh();
        requestLoadingDashboardInfos();
    }


    public void dashboardTripResult(int result) {
        hideSwipRefresh();
        if (result == -4) {
            Toaster.shorter(context.getString(R.string.serverFaield));
        } else if (result == -5) {
            Toaster.shorter(context.getString(R.string.connectionFaield));
        } else if (result == 1) {

            ResultOK();
        } else if (result == 100) {
            Intent intent = new Intent(getActivity(), LoginActivity.class);
            startActivity(intent);

        } else {
            Toast.makeText(context, App.dashboard.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

}
