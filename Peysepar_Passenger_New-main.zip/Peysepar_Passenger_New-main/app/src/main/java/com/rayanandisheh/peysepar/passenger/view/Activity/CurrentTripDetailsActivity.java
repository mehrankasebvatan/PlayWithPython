package com.rayanandisheh.peysepar.passenger.view.Activity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RatingBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.cardview.widget.CardView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;

import com.google.android.gms.maps.model.LatLng;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.rayanandisheh.peysepar.passenger.R;
import com.rayanandisheh.peysepar.passenger.helpers.App;
import com.rayanandisheh.peysepar.passenger.helpers.PersianAppcompatActivity;
import com.rayanandisheh.peysepar.passenger.helpers.Time;
import com.rayanandisheh.peysepar.passenger.helpers.Toaster;
import com.rayanandisheh.peysepar.passenger.models.Trip;
import com.rayanandisheh.peysepar.passenger.models.UserInfo;
import com.rayanandisheh.peysepar.passenger.services.APIClient;
import com.rayanandisheh.peysepar.passenger.services.APIService;

import org.jetbrains.annotations.NotNull;

import java.util.TimerTask;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CurrentTripDetailsActivity extends PersianAppcompatActivity {
    private static final String TAG = "CurrentTripDetailsActiv";
    Context context;

    TextView
            txtPursuitCode_currntDtls, txtTripStatus_currntDtls, txtRequestDate_Time_currntDtls, txtPassengerNames_currntDtls,
            txtSupposedDate_Time_currntDtls, txtOriginName_currntDtls, txtDesName_currntDtls, txtReasonImportance_currntDtls,
            txtVehicleType_currentTrip, txtTripType_currntDtls,
            txtComment_currntDtls, txtDriverName_currentTrip, txtCarModel_currntDtls,
            txtArrivingTimeCalculate_currntDtls, txtTripPreparationTime_currntDtls, txtStartTripTime_currntDtls,
            txtFinishTripDateTime_currntDtls, txtTripDurationTime_currntDtls, txt1_NPlate_crntDtls, txt2_NPlate_crntDtls,
            txt3_NPlate_crntDtls, txt4_NPlate_crntDtls, txtImportance_currentTripDetai, txtCarKind_currntDtls, txtCarName_currntDtls;

    RatingBar rate_currntDtls;
    FloatingActionButton fabCall_currntDtls, fabDriverLocation;
    ImageView imgStar;
    RelativeLayout rlTripType;
    Button btnCancelCurrentTripDetails;
    ProgressBar pbCancelCurrentTripDetails;
    LinearLayout llCarType;
    ConstraintLayout clHeader, cly_currentTripDetail_bt;
    CardView cvDriverInfo_currntDtls, cvDateTime__currntDtls;
    //no need to make it new
    Trip model = new Trip();

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_current_trip_details1);

        context = this;
        bindView();
        //getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        Bundle mbundle = getIntent().getExtras();
        if (mbundle != null) {
            model = mbundle.getParcelable("MyModel");
            assert model != null;
            App.iOfficialTrip = model.getiOfficialTrip();
            //TODO _> یادم باشه تایمر رو که ران میکنم، وقتی فرم رو بست ، تایمررو هم از کاربندازم،ول نکنم به امون خدا

            txtPursuitCode_currntDtls.setText(String.valueOf(model.getiOfficialTrip()));
            txtTripStatus_currntDtls.setText(model.getStrOfficialStatus_strComment());
            if (model != null && model.getStrRequestTime() != null && model.getStrRequestDate() != null) {
                txtRequestDate_Time_currntDtls.setText(model.getStrRequestTime().trim() + " - " + model.getStrRequestDate());
            }
            txtPassengerNames_currntDtls.setText(model.getStrPassengers());
            txtSupposedDate_Time_currntDtls.setText(model.getStrTripTime() + " - " + model.getStrTripDate());
            txtOriginName_currntDtls.setText(model.getStrOriginAddress());
            txtDesName_currntDtls.setText(model.getStrDestinationAddress());
            txtReasonImportance_currntDtls.setText(model.getStrTripReason_strComment() + " - " + model.getStrTripImportance_strComment());
            //todo below should be model.getStrMobile(savari sangin....)
            txtVehicleType_currentTrip.setText(model.getStrMobileType());

            txtCarName_currntDtls.setText(model.getStrGPSType_strComment());

            if (model.isbExclusive() || model.isbHaveReturn() || model.isbMission()) {
                rlTripType.setVisibility(View.VISIBLE);
            } else
                rlTripType.setVisibility(View.GONE);

            if (model.isbHaveReturn())
                txtTripType_currntDtls.setText("دارای برگشت");
            else if (model.isbExclusive())
                txtTripType_currntDtls.setText("در اختیار");
            else if (model.isbMission())
                txtTripType_currntDtls.setText("ماموریتی");


            if (model != null && model.getStrComment() != null && model.getStrComment().length() != 0)
                txtComment_currntDtls.setText(model.getStrComment());
            else
                txtComment_currntDtls.setText("-");

            txtDriverName_currentTrip.setText(model.getStrDriverName());
            txtCarModel_currntDtls.setText(model.getStrMobileType());
//            txtArrivingTimeCalculate_currntDtls.setText(model.getStrEstRedy4TrimpTime());
            txtTripPreparationTime_currntDtls.setText(model.getStrRedy4TrimpTime());
            txtStartTripTime_currntDtls.setText(model.getStrTripTime());
            txtFinishTripDateTime_currntDtls.setText(model.getStrFinishDate() + "-" + model.getStrTrimpFinishTime());

            txtImportance_currentTripDetai.setText(model.getStrTripImportance_strComment());

            if (model.getStrTrimTimeEstimate() != null)
                txtTripDurationTime_currntDtls.setText(Time.minutesToHours(model.getStrTrimTimeEstimate()));

            else
                txtTripDurationTime_currntDtls.setText("0" + " " + "دقیقه");

            //TODO FOR DRIVER ARRIVE TIME
            if (model.getStrEstRedy4TrimpTime() != null) {
                txtArrivingTimeCalculate_currntDtls.setText(model.getStrEstRedy4TrimpTime());
            } else
                txtArrivingTimeCalculate_currntDtls.setText("0" + " " + "دقیقه");

            rate_currntDtls.setRating(model.getiSatisfication() / 20);

            if (model != null && model.getStrTripImportance_strComment() != null) {
                switch (model.getStrTripImportance_strComment()) {
                    case "عادی":
                        txtImportance_currentTripDetai.setBackground(ContextCompat.getDrawable(context, R.drawable.shape_circle_normal));
                        txtImportance_currentTripDetai.setTextColor(context.getResources().getColor(R.color.colorText));
                        break;
                    case "فوری":
                        txtImportance_currentTripDetai.setBackground(ContextCompat.getDrawable(context, R.drawable.shape_circle_urgent));
                        txtImportance_currentTripDetai.setTextColor(context.getResources().getColor(R.color.colorOrenge));
                        break;
                    case "خیلی فوری":
                        txtImportance_currentTripDetai.setBackground(ContextCompat.getDrawable(context, R.drawable.shape_circle_very_urgent));
                        txtImportance_currentTripDetai.setTextColor(context.getResources().getColor(R.color.colorPink));
                        break;
                }
            }

            if (model.getTiTripStatus() == 3 || model.getTiTripStatus() == 5)
                fabDriverLocation.setVisibility(View.VISIBLE);
            else
                fabDriverLocation.setVisibility(View.GONE);

            // hide and show cancel's Button
            if (model.getTiTripStatus() == 0 || model.getTiTripStatus() == 1 || model.getTiTripStatus() == 2
                    || model.getTiTripStatus() == 3 || model.getTiTripStatus() == 5) {
                btnCancelCurrentTripDetails.setVisibility(View.VISIBLE);
                cly_currentTripDetail_bt.setVisibility(View.VISIBLE);
            } else if (model.getTiTripStatus() == 6 || model.getTiTripStatus() == 7) {
                btnCancelCurrentTripDetails.setVisibility(View.GONE);
                cly_currentTripDetail_bt.setVisibility(View.GONE);
            }


//        // hide driverName && hide carType while trip status is not confirm by driver
//        if (model.getTiTripStatus() == 0 || model.getTiTripStatus() == 1 || model.getTiTripStatus() == 2) {
//            llDriverName.setVisibility(View.GONE);
//            llCarType.setVisibility(View.GONE);
//        } else if (model.getTiTripStatus() == 3 || model.getTiTripStatus() == 5 || model.getTiTripStatus() == 6) {
//            llDriverName.setVisibility(View.VISIBLE);
//            llCarType.setVisibility(View.VISIBLE);
//        }

            if (model.getTiTripStatus() == 0 || model.getTiTripStatus() == 1) {
                cvDriverInfo_currntDtls.setVisibility(View.GONE);
            } else {
                cvDriverInfo_currntDtls.setVisibility(View.VISIBLE);

                //numberPlate
                String numberPlate = model.getStrVehicleNo();
                try {
                    txt1_NPlate_crntDtls.setText(numberPlate.substring(0, 2));
                    txt2_NPlate_crntDtls.setText(numberPlate.substring(3, 4));
                    txt3_NPlate_crntDtls.setText(numberPlate.substring(5, 8));
                    txt4_NPlate_crntDtls.setText(numberPlate.substring(11));
                } catch (Exception ignored) {
                }
            }

            if (model.getTiTripStatus() == 7) {
                cvDateTime__currntDtls.setVisibility(View.VISIBLE);
            } else {
                cvDateTime__currntDtls.setVisibility(View.GONE);
            }

            fabDriverLocation.setOnClickListener(v -> ShowDriverLocation(context));

            btnCancelCurrentTripDetails.setOnClickListener(v -> {
                Toaster.shorter("دکمه را نگه دارید");
            });

            btnCancelCurrentTripDetails.setOnLongClickListener(v -> {
                AlertDialog.Builder dialog = new AlertDialog.Builder(context);
                dialog.setMessage("آیا از لغو سفر با کد:" + model.getiOfficialTrip() + " مطمئن هستید؟");
                dialog.setPositiveButton("بله", (dialog1, which) -> btnCanceledPressed(model));
                dialog.setNegativeButton("خیر", (dialog12, which) -> dialog12.dismiss());
                dialog.create().show();
                return true;
            });

            fabCall_currntDtls.setOnClickListener(v -> btnCallPressed(model.getDriverMobile()));
        }
    }

    class secondTask extends TimerTask {
        @Override
        public void run() {
            sendRequest();
        }
    }

    private void sendRequest() {
        try {
            getDriverLocation(context, model.getiOfficialTrip());

        } catch (Exception ignored) {
            Log.e("DriverLocation", "sendRequest: " + ignored.toString());
        }
    }

    private void bindView() {
        txtPursuitCode_currntDtls = findViewById(R.id.txtPursuitCode_currntDtls);
        txtTripStatus_currntDtls = findViewById(R.id.txtTripStatus_currntDtls);
        txtRequestDate_Time_currntDtls = findViewById(R.id.txtRequestDate_Time_currntDtls);
        txtPassengerNames_currntDtls = findViewById(R.id.txtPassengerNames_currntDtls);
        txtSupposedDate_Time_currntDtls = findViewById(R.id.txtSupposedDate_Time_currntDtls);
        txtOriginName_currntDtls = findViewById(R.id.txtOriginName_currntDtls);
        txtDesName_currntDtls = findViewById(R.id.txtDesName_currntDtls);
        txtReasonImportance_currntDtls = findViewById(R.id.txtReasonImportance_currntDtls);
        txtVehicleType_currentTrip = findViewById(R.id.txtVehicleType_currentTrip);
        txtTripType_currntDtls = findViewById(R.id.txtTripType_currntDtls);
        txtComment_currntDtls = findViewById(R.id.txtComment_currntDtls);
        txtDriverName_currentTrip = findViewById(R.id.txtDriverName_currentTrip);
//        txtNumberPlate_currntDtls = findViewById(R.id.txtNumberPlate_currntDtls);
        txtCarModel_currntDtls = findViewById(R.id.txtCarModel_currntDtls);
        txtArrivingTimeCalculate_currntDtls = findViewById(R.id.txtArrivingTimeCalculate_currntDtls);
        txtTripPreparationTime_currntDtls = findViewById(R.id.txtTripPreparationTime_currntDtls);
        txtStartTripTime_currntDtls = findViewById(R.id.txtStartTripTime_currntDtls);
        txtFinishTripDateTime_currntDtls = findViewById(R.id.txtFinishTripDateTime_currntDtls);
        txtTripDurationTime_currntDtls = findViewById(R.id.txtTripDurationTime_currntDtls);
        txt1_NPlate_crntDtls = findViewById(R.id.txt1_NPlate_crntDtls);
        txt2_NPlate_crntDtls = findViewById(R.id.txt2_NPlate_crntDtls);
        txt3_NPlate_crntDtls = findViewById(R.id.txt3_NPlate_crntDtls);
        txt4_NPlate_crntDtls = findViewById(R.id.txt4_NPlate_crntDtls);

        rate_currntDtls = findViewById(R.id.rate_currntDtls);
        btnCancelCurrentTripDetails = findViewById(R.id.btnCancelCurrentTripDetails);
        pbCancelCurrentTripDetails = findViewById(R.id.pbCancelCurrentTripDetails);
        llCarType = findViewById(R.id.llCarType);
        imgStar = findViewById(R.id.imgStar_currentTripDetail);
        fabCall_currntDtls = findViewById(R.id.fabCall_currntDtls);
        fabDriverLocation = findViewById(R.id.fabDriverLocation);
        cvDriverInfo_currntDtls = findViewById(R.id.cvDriverInfo_currntDtls);
        clHeader = findViewById(R.id.clHeader);
        cly_currentTripDetail_bt = findViewById(R.id.cly_currentTripDetail_bt);
        cvDateTime__currntDtls = findViewById(R.id.cvDateTime__currntDtls);
        rlTripType = findViewById(R.id.rlTripType_currntDtls);
        txtImportance_currentTripDetai = findViewById(R.id.txtImportance_currentTripDetai);

        txtCarKind_currntDtls = findViewById(R.id.txtCarKind_currntDtls);
        txtCarName_currntDtls = findViewById(R.id.txtCarName_currntDtls);
    }

    public void showProgressBar() {
        pbCancelCurrentTripDetails.setVisibility(View.VISIBLE);
        btnCancelCurrentTripDetails.setVisibility(View.GONE);
    }

    public void hideProgressBar() {
        pbCancelCurrentTripDetails.setVisibility(View.GONE);
        btnCancelCurrentTripDetails.setVisibility(View.VISIBLE);
    }

    public void cancelTripRequest(Trip iOfficialTrip) {

        APIService apiService = APIClient.getClient().create(APIService.class);
        Call<Integer> call = apiService.cancelTrip(iOfficialTrip, "", App.Session);

        call.enqueue(new Callback<Integer>() {
            @Override
            public void onResponse(@NotNull Call<Integer> call, @NotNull Response<Integer> response) {
                if (response.code() == 200) {
                    cencelTripResult(response.body());
                } else {
                    cencelTripResult(-1);
                }
            }

            @Override
            public void onFailure(@NotNull Call<Integer> call, @NotNull Throwable t) {
                cencelTripResult(-5);
            }
        });
    }

    public void btnCallPressed(String driverMobile) {
        Intent intent = new Intent(Intent.ACTION_DIAL);
        intent.setData(Uri.parse("tel:" + driverMobile));
//        intent.setData(Uri.parse("tel:09372112652"));
        context.startActivity(intent);
    }

    public void getDriverLocation(Context context, int iOfficialTrip) {
        // Request For Getting Driver Location
        Trip trip = new Trip();
        trip.setiOfficialTrip(iOfficialTrip);
        APIService apiService = APIClient.getClient().create(APIService.class);
        Call<UserInfo> call = apiService.GetLastPosition(trip, App.Session);
        call.enqueue(new Callback<UserInfo>() {
            @Override
            public void onResponse(@NotNull Call<UserInfo> call, @NotNull Response<UserInfo> response) {
                if (response.code() == 200 && response.body() != null) {
                    resultOfDriverLocation(response.body());
                } else
                    resultOfDriverLocation(response.body());
            }

            @Override
            public void onFailure(@NotNull Call<UserInfo> call, @NotNull Throwable t) {
                Toaster.shorter("خطا در اتصال اینترنت");
            }
        });
    }

    public void btnCanceledPressed(Trip iOfficialTrip) {
        showProgressBar();
        cancelTripRequest(iOfficialTrip);
    }

    public void cencelTripResult(Integer cancelTripResult) {
        hideProgressBar();
        if (cancelTripResult == 1) {
            Toaster.shorter("سفر با موفقیت لغو شد");
            ((Activity) context).finish();
        } else if (cancelTripResult == 0) {
            Toaster.shorter("شما قادر به لغو سفر نیستید");
        } else if (cancelTripResult == -1) {
            Toaster.shorter(context.getString(R.string.serverFaield));
        } else if (cancelTripResult == -5) {
            Toaster.shorter(context.getString(R.string.connectionFaield));
        } else if (cancelTripResult == 100) {
            Intent intent = new Intent(CurrentTripDetailsActivity.this, LoginActivity.class);
            startActivity(intent);
        }
    }

//    public void btnCallPressed(String driverMobile) {
//        btnCallPressed(driverMobile);
//    }

//    public void getDriverLocation(Context context, int iOfficialTrip) {
//        getDriverLocation(context, iOfficialTrip);
//    }

    public void resultOfDriverLocation(UserInfo body) {
        switch (body.getResult()) {
            case 100:
                Intent intent = new Intent(CurrentTripDetailsActivity.this, LoginActivity.class);
                startActivity(intent);
            case 1:
                App.driverLocation = new LatLng(body.getfLat(), body.getfLon());
                break;
            case 0:
                Toaster.shorter(body.getStrComment());
                break;
            default:
                Toaster.shorter(body.getStrComment());
                break;
        }
    }

    public void ShowDriverLocation(Context context) {
        Bundle mbundle = new Bundle();
        mbundle.putString("unitId", model.getStrUnitIdDriver());
        Intent mintent = new Intent(context, DriverLocationActivity.class);
        mintent.putExtras(mbundle);
        context.startActivity(mintent);
    }
}
