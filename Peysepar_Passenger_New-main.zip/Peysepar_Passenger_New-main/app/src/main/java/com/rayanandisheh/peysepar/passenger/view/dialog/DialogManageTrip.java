package com.rayanandisheh.peysepar.passenger.view.dialog;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.DialogFragment;

import com.rayanandisheh.peysepar.passenger.R;
import com.rayanandisheh.peysepar.passenger.models.Trip;
import com.rayanandisheh.peysepar.passenger.view.Activity.AssignDriverActivity;
import com.rayanandisheh.peysepar.passenger.view.Activity.MapsActivityTabLayout;

public class DialogManageTrip extends DialogFragment implements View.OnClickListener {
    private static final String TAG = "DialogConfirm";
    private Context context;
    private View view;
    private final String title;
    private EditText et_description;
    private final OnClickDialogFinalOrderRegister onClickDialogFinalOrderRegister;
    private TextView tv_dialog_reason;
    private TextView tv_dialog_codeTrip;
    private TextView tv_dialog_name;
    private TextView tv_dialog_mobile;
    private TextView tv_dialog_guest;
    private TextView tv_dialog_origin;
    private TextView tv_dialog_distination;
    private TextView tv_dialog_carType;
    private TextView tv_dialog_discription;
    private TextView tv_dialog_Organ_position;
    private TextView tv_dialog_date;
    private TextView tv_dialog_importance;

    private Trip trip;

    public DialogManageTrip(Context context,String title, Trip trip, OnClickDialogFinalOrderRegister onClickDialogFinalOrderRegister) {
        this.context = context;
        this.title = title;
        this.trip = trip;
        this.onClickDialogFinalOrderRegister = onClickDialogFinalOrderRegister;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container
            , @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.dialog_confirm_cancel_trip, container, false);
        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        setCancelable(true);
        getViews();

        Log.i(TAG, "onViewCreated: " + title);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
    }

    public void onResume() {
        // Store access variables for window and blank point
        getDialog().getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        getDialog().getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        getDialog().getWindow().getAttributes().windowAnimations = R.style.DialogAnimation;

        Window window = getDialog().getWindow();
        WindowManager.LayoutParams wlp = window.getAttributes();
        wlp.gravity = Gravity.BOTTOM;
        wlp.flags = WindowManager.LayoutParams.FLAG_DIM_BEHIND;
        window.setAttributes(wlp);
        super.onResume();
    }

    @SuppressLint("ClickableViewAccessibility")
    private void getViews() {
        tv_dialog_reason = view.findViewById(R.id.tv_dialog_reason);
        tv_dialog_codeTrip = view.findViewById(R.id.tv_dialog_codeTrip);
        tv_dialog_name = view.findViewById(R.id.tv_dialog_name);
        tv_dialog_mobile = view.findViewById(R.id.tv_dialog_mobile);
        tv_dialog_guest = view.findViewById(R.id.tv_dialog_guest);
        tv_dialog_origin = view.findViewById(R.id.tv_dialog_origin);
        tv_dialog_distination = view.findViewById(R.id.tv_dialog_distination);
        tv_dialog_carType = view.findViewById(R.id.tv_dialog_carType);
        tv_dialog_discription = view.findViewById(R.id.tv_dialog_discription);
        tv_dialog_Organ_position = view.findViewById(R.id.tv_dialog_Organ_position);
        tv_dialog_date = view.findViewById(R.id.tv_dialog_date);
        tv_dialog_importance = view.findViewById(R.id.tv_dialog_importance);


        ImageView img_dialog_close = view.findViewById(R.id.img_dialog_close);
        TextView tv_dialog_confirm = view.findViewById(R.id.tv_dialog_confirm);
        TextView tv_dialog_assignDriver = view.findViewById(R.id.tv_dialog_assignDriver);
        TextView tv_dialog_location = view.findViewById(R.id.tv_dialog_location);
        TextView tv_dialog_archive = view.findViewById(R.id.tv_dialog_archive);
        TextView tv_dialog_cancel = view.findViewById(R.id.tv_dialog_cancel);

        try {
            tv_dialog_importance.setText(trip.getStrTripImportance_strComment());
            if (trip.getStrTripImportance_strComment() != null) {
                switch (trip.getStrTripImportance_strComment()) {
                    case "عادی":
                        tv_dialog_importance.setBackground(ContextCompat.getDrawable(context, R.drawable.shape_circle_normal));
                        tv_dialog_importance.setTextColor(context.getResources().getColor(R.color.colorText));
                        break;
                    case "فوری":
                        tv_dialog_importance.setBackground(ContextCompat.getDrawable(context, R.drawable.shape_circle_urgent));
                        tv_dialog_importance.setTextColor(context.getResources().getColor(R.color.colorOrenge));
                        break;
                    case "خیلی فوری":
                        tv_dialog_importance.setBackground(ContextCompat.getDrawable(context, R.drawable.shape_circle_very_urgent));
                        tv_dialog_importance.setTextColor(context.getResources().getColor(R.color.colorPink));
                        break;
                }
            }
        } catch (Exception ignored) {
        }

//        if (trip.getStrTripDate().compareTo(todayDate) >= 0) {
//            rl_confirm_Trip.setVisibility(View.VISIBLE);
//            rl_Cancle_Trip.setVisibility(View.GONE);
//        } else {
//            rl_confirm_Trip.setVisibility(View.GONE);
//            rl_Cancle_Trip.setVisibility(View.VISIBLE);
//        }

        tv_dialog_reason.setText(trip.getStrTripReason_strComment());
        tv_dialog_codeTrip.setText(String.valueOf(trip.getiOfficialTrip()));
        tv_dialog_name.setText(trip.getStrApplicantName() + " " + trip.getStrApplicantFamily());
        tv_dialog_carType.setText(trip.getStrMobileType());

//        RelativeLayout rlDelete = view.findViewById(R.id.rlDeleteInflateAlertConfirmedTabLayout);
//        rlDelete.setOnClickListener(v1 -> dismiss());

        tv_dialog_mobile.setText(trip.getStrApplicantMobile());
        tv_dialog_origin.setText(trip.getStrOriginName());
        tv_dialog_distination.setText(trip.getStrDestinationName());
        tv_dialog_discription.setText(trip.getStrComment());
        tv_dialog_Organ_position.setText(trip.getStrChartName());
        tv_dialog_date.setText(trip.getStrTripDate() + " _ " + trip.getStrTripTime());
        tv_dialog_guest.setText(trip.getStrPassengers());
        tv_dialog_importance.setText(trip.getStrTripImportance_strComment());

        tv_dialog_confirm.setOnClickListener(this);
        tv_dialog_assignDriver.setOnClickListener(this);
        tv_dialog_location.setOnClickListener(this);
        tv_dialog_archive.setOnClickListener(this);
        tv_dialog_cancel.setOnClickListener(this);
        img_dialog_close.setOnClickListener(this);
    }

    public interface OnClickDialogFinalOrderRegister {
        void onConfirm(String des);

        void onAssignDriver(String des);

        void onLocation(String des);

        void onArchive(int iOfficialTrip);

        void onCancel(int iOfficialTrip, int iTripStatus);
    }

    @SuppressLint("NonConstantResourceId")
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.tv_dialog_confirm:
                onClickDialogFinalOrderRegister.onConfirm("");
                break;
            case R.id.tv_dialog_assignDriver:
                Intent intent1 = new Intent(context, AssignDriverActivity.class);
                intent1.putExtra("iOfficialTrip", trip.getiOfficialTrip());
                intent1.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent1);
                dismiss();
                onClickDialogFinalOrderRegister.onAssignDriver("");
                break;
            case R.id.tv_dialog_location:
                Intent intent = new Intent(context, MapsActivityTabLayout.class);
                intent.putExtra("flatSourceTabLayout", trip.getfLatSource());
                intent.putExtra("flngSourceTabLayout", trip.getfLonSource());
                intent.putExtra("flatDesTabLayout", trip.getfLatDestination());
                intent.putExtra("flngDesTabLayout", trip.getfLonDestination());
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);
                dismiss();
                onClickDialogFinalOrderRegister.onLocation("");
                break;
            case R.id.tv_dialog_archive:
                dismiss();
                onClickDialogFinalOrderRegister.onArchive(trip.getiOfficialTrip());
                break;
            case R.id.tv_dialog_cancel:
                dismiss();
                onClickDialogFinalOrderRegister.onCancel(trip.getiOfficialTrip(), trip.getTiTripStatus());
                break;
            case R.id.img_dialog_close:
                dismiss();
                break;
        }
    }
}

