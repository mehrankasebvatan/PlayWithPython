package com.rayanandisheh.peysepar.passenger.view.Adapter;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.rayanandisheh.peysepar.passenger.R;
import com.rayanandisheh.peysepar.passenger.models.Trip;
import com.rayanandisheh.peysepar.passenger.view.Activity.MapsActivityTabLayout;

import java.util.List;

public class TripManagementRunningAdapter extends RecyclerView.Adapter<TripManagementRunningAdapter.ViewHolder> {

    private List<Trip> modelRunningFragments;
    Context context;

    public TripManagementRunningAdapter(List<Trip> modelRunningFragments, Context context) {
        this.modelRunningFragments = modelRunningFragments;
        this.context = context;
    }

    public void clear() {
        modelRunningFragments.clear();
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public TripManagementRunningAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int typeView) {
        View viewNewFragment = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_trip_new_fragment1, parent, false);
        return new ViewHolder(viewNewFragment);
    }

    @Override
    public void onBindViewHolder(@NonNull TripManagementRunningAdapter.ViewHolder holder, int position) {

        Trip model = modelRunningFragments.get(position);
        holder.txt_persuadeCode.setText(String.valueOf(model.getiOfficialTrip()));
        holder.txt_applicantName.setText(model.getStrApplicantName() + " " + model.getStrApplicantFamily());
        holder.txt_tripReason.setText("سفر " + model.getStrTripReason_strComment());
        holder.txt_requestDate.setText(model.getStrTripDate() + " _ " + model.getStrRequestTime());
        holder.txt_supposeDate.setText(model.getStrTripDate() + " _ " + model.getStrTripTime());
        holder.txt_originAddress.setText(model.getStrOriginAddress());
        holder.txt_desAddress.setText(model.getStrDestinationAddress());
//        holder.txt_originAddress.setText(model.getStrOriginName()+" , "+model.getStrOriginAddress());
//        holder.txt_desAddress.setText(model.getStrDestinationName()+" , "+model.getStrDestinationAddress());
//        holder.txt_applicantPhone.setText(model.getStrApplicantMobile());

        try {
            holder.tv_TripImportanceNewFragment.setText(model.getStrTripImportance_strComment());
            if (model.getStrTripImportance_strComment() != null) {
                switch (model.getStrTripImportance_strComment()) {
                    case "عادی":
                        holder.tv_TripImportanceNewFragment.setBackground(ContextCompat.getDrawable(context, R.drawable.shape_circle_normal));
                        holder.tv_TripImportanceNewFragment.setTextColor(context.getResources().getColor(R.color.colorText));
                        break;
                    case "فوری":
                        holder.tv_TripImportanceNewFragment.setBackground(ContextCompat.getDrawable(context, R.drawable.shape_circle_urgent));
                        holder.tv_TripImportanceNewFragment.setTextColor(context.getResources().getColor(R.color.colorOrenge));
                        break;
                    case "خیلی فوری":
                        holder.tv_TripImportanceNewFragment.setBackground(ContextCompat.getDrawable(context, R.drawable.shape_circle_very_urgent));
                        holder.tv_TripImportanceNewFragment.setTextColor(context.getResources().getColor(R.color.colorPink));
                        break;
                }
            }
        } catch (Exception ignored) {
        }

        holder.itemView.setOnClickListener(v -> {

            final Dialog dialog = new Dialog(context, android.R.style.Theme_DeviceDefault_Light_Dialog_NoActionBar_MinWidth);
            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
            dialog.setContentView(R.layout.inflate_alertdialog_runningtablayout);
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
            dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);

            TextView txtTripReason = dialog.findViewById(R.id.txtTripReasonAlertRunningTabLayout);
            txtTripReason.setText(model.getStrTripReason_strComment());

            TextView txPersuateCode = dialog.findViewById(R.id.txtPersuateCodeAlertRunningTabLayout);
            txPersuateCode.setText(String.valueOf(model.getiOfficialTrip()));

            TextView txt_NameFamily = dialog.findViewById(R.id.txt_applicantNameFamilyRunningTablayout);
            txt_NameFamily.setText(model.getStrApplicantName() + " " + model.getStrApplicantFamily());
//                txt_alertdialogNameFamilyNewFragment.setText(model.getStrApplicantName());

            TextView txt_kindOfCar = dialog.findViewById(R.id.txt_RunningkindOfCar);
            txt_kindOfCar.setText(model.getStrMobileType());

            RelativeLayout rlDelete = dialog.findViewById(R.id.rlDeleteAlertRunningTabLayout);
            rlDelete.setOnClickListener(v1 -> dialog.dismiss());

            TextView txt_ApplicatntPhone = dialog.findViewById(R.id.txt_ApplicantPhoneAlertRunningTabLayout);
            txt_ApplicatntPhone.setText(model.getStrApplicantMobile());


            TextView txt_driverNameFamily = dialog.findViewById(R.id.txt_DriverNameFamilyAlertRunningTablayout);
            txt_driverNameFamily.setText(model.getStrDriverName());


            TextView txt_driverPhone = dialog.findViewById(R.id.txt_DriverPhoneAlertRunningTabLayout);
            txt_driverPhone.setText(model.getDriverMobile());


            TextView txt_origin = dialog.findViewById(R.id.txt_originAlertRunningTabLayout);
            txt_origin.setText(model.getStrOriginName());

            TextView txt_des = dialog.findViewById(R.id.txt_desAlertRunningTabLayout);
            txt_des.setText(model.getStrDestinationName());


            TextView txt_passengers = dialog.findViewById(R.id.txt_passengersAlertRunningTabLayout);
            txt_passengers.setText(model.getStrPassengers());

            TextView txt_Comment = dialog.findViewById(R.id.txt_Comment4);
            txt_Comment.setText(model.getStrComment());

            TextView txt_Situation = dialog.findViewById(R.id.txt_Situation4);
            txt_Situation.setText(model.getStrChartName());

            TextView txt_DateAndTime = dialog.findViewById(R.id.txt_DateAndTime4);
            txt_DateAndTime.setText(model.getStrTripDate() + " _ " + model.getStrTripTime());

            ImageView img = dialog.findViewById(R.id.imgStarAlertRunningTabLayout);
            switch (model.getStrTripImportance_strComment()) {
                case "عادی":
                    img.setBackground(ContextCompat.getDrawable(context, R.drawable.star1));
                    break;
                case "فوری":
                    img.setBackground(ContextCompat.getDrawable(context, R.drawable.star2));
                    break;
                case "خیلی فوری":
                    img.setBackground(ContextCompat.getDrawable(context, R.drawable.star3));
                    break;
            }

            TextView txt_tripImportance = dialog.findViewById(R.id.txtTripImportanceAlertRunningTabLayout);
            txt_tripImportance.setText(model.getStrTripImportance_strComment());


            TextView txt_location = dialog.findViewById(R.id.txt_location_alertRunningTabLayout);
            txt_location.setOnClickListener(v12 -> {
                Intent intent = new Intent(context, MapsActivityTabLayout.class);
                intent.putExtra("flatSourceTabLayout", model.getfLatSource());
                intent.putExtra("flngSourceTabLayout", model.getfLonSource());
                intent.putExtra("flatDesTabLayout", model.getfLatDestination());
                intent.putExtra("flngDesTabLayout", model.getfLonDestination());
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);
                dialog.dismiss();

            });

            dialog.show();
        });
    }

    @Override
    public int getItemCount() {
        return modelRunningFragments.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView txt_persuadeCode, txt_applicantName, txt_tripReason, tv_TripImportanceNewFragment,
                txt_requestDate, txt_supposeDate, txt_originAddress, txt_desAddress;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            txt_persuadeCode = itemView.findViewById(R.id.txt_row_txtPersuadeCodeNewFragment);
            txt_applicantName = itemView.findViewById(R.id.txt_row_txtApplicantNameNewFragment);
            txt_tripReason = itemView.findViewById(R.id.txt_row_TripReasonNewFragment);
            txt_requestDate = itemView.findViewById(R.id.txt_row_RequestDateNewFragment);
            txt_supposeDate = itemView.findViewById(R.id.txt_row_supposeDateNewFragment);
            txt_originAddress = itemView.findViewById(R.id.txt_row_originAddressNewFragment);
            txt_desAddress = itemView.findViewById(R.id.txt_row_DesAddressNewFragment);
            tv_TripImportanceNewFragment = itemView.findViewById(R.id.tv_TripImportanceNewFragment);
        }
    }
}
