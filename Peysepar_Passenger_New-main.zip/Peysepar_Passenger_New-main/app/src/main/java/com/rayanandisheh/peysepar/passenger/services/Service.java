package com.rayanandisheh.peysepar.passenger.services;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;
import androidx.core.app.ActivityCompat;
import androidx.appcompat.app.AlertDialog;

import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.rayanandisheh.peysepar.passenger.R;
import com.rayanandisheh.peysepar.passenger.helpers.App;

public class Service extends android.app.Service {

    private static final String TAG = Service.class.getSimpleName();
    public Context context = this;
    WindowManager windowManager;
    View mView;
    //    String TAG = "isScreen";
    LinearLayout linearDialog;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        showDialog(intent.getStringExtra("msg"));
        return super.onStartCommand(intent, flags, startId);
    }

    @SuppressLint("SetTextI18n")
    public void showDialog(String msg) {

        wakeUpScreen();

        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
//            LayoutInflater layoutInflater = (LayoutInflater) this.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
//            mView = layoutInflater.inflate(R.layout.popup, linearDialog);
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
            if (ActivityCompat.checkSelfPermission(context, Manifest.permission.SYSTEM_ALERT_WINDOW)
                    != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission
                    (context, Manifest.permission.SYSTEM_ALERT_WINDOW) != PackageManager.PERMISSION_GRANTED) {
                showNotificationDialog();
            } else
                wakeUpScreen();
        } else {
            showNotificationDialog();
        }
    }

    private void wakeUpScreen() {
        // Wake up screen
        PowerManager powerManager = (PowerManager) context.getSystemService(Context.POWER_SERVICE);
        boolean isScreenOn;
        if (Build.VERSION.SDK_INT >= 20) {
            isScreenOn = powerManager.isInteractive();
        } else {
            isScreenOn = powerManager.isScreenOn();
        }
        if (!isScreenOn) {
            @SuppressLint("InvalidWakeLockTag") PowerManager.WakeLock wl = powerManager.newWakeLock(PowerManager.FULL_WAKE_LOCK | PowerManager.ACQUIRE_CAUSES_WAKEUP | PowerManager.ON_AFTER_RELEASE, "MH24_SCREENLOCK");
            wl.acquire(2000);
            @SuppressLint("InvalidWakeLockTag") PowerManager.WakeLock wl_cpu = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "MH24_SCREENLOCK");
            wl_cpu.acquire(2000);
        }
    }


    public void showNotificationDialog() {

        mView = View.inflate(getApplicationContext(), R.layout.popup, null);
        mView.setTag(TAG);
        linearDialog = mView.findViewById(R.id.linearDialog);

        TextView txt_dialog = mView.findViewById(R.id.txt_dialog);
        Button btn_dialog = mView.findViewById(R.id.btn_dialog);
//        btn_dialog.setVisibility(View.GONE);
        Typeface tf = Typeface.createFromAsset(getAssets(), "IRANSansMobile.ttf");
        txt_dialog.setTypeface(tf);
        txt_dialog.setText("کدسفر : " + App.notifModel.getiOfficialTrip() + "\n \n" + App.notifModel.getMessage());
        btn_dialog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                context.stopService(new Intent(context, Service.class));
                linearDialog.setVisibility(View.GONE);
                onDestroy();
//                    startActivity(new Intent(context, TripManagementNewActivity.class));
            }
        });

        final WindowManager.LayoutParams mLayoutParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.TYPE_SYSTEM_ERROR,
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                        | WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
                        | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
                        | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
                PixelFormat.RGBA_8888);

        windowManager.addView(mView, mLayoutParams);
        windowManager.updateViewLayout(mView, mLayoutParams);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
//        windowManager.removeView(mView);
    }
}
