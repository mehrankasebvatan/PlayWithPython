package com.rayanandisheh.peysepar.passenger.view.Adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.rayanandisheh.peysepar.passenger.R;
import com.rayanandisheh.peysepar.passenger.helpers.App;
import com.rayanandisheh.peysepar.passenger.helpers.Toaster;
import com.rayanandisheh.peysepar.passenger.models.Trip;
import com.rayanandisheh.peysepar.passenger.view.Activity.CurrentTripDetailsActivity;
import com.rayanandisheh.peysepar.passenger.view.Activity.SignatureActivity;
import com.rayanandisheh.peysepar.passenger.view.Activity.ZoomImageActivity;

import java.util.List;

import static com.rayanandisheh.peysepar.passenger.view.Activity.ZoomImageActivity.STR_BITMAP;

public class CurrentTripAdapter extends RecyclerView.Adapter<CurrentTripAdapter.ViewHolder> {
    private static final String TAG = "CurrentTripAdapter";
    private List<Trip> modelFrCurrentTrip;
    private Context context;

    public CurrentTripAdapter(List<Trip> modelFrCurrentTrip, Context context) {
        this.modelFrCurrentTrip = modelFrCurrentTrip;
        this.context = context;
    }

    public void setModelFrCurrentTrip(List<Trip> modelFrCurrentTrip) {
        this.modelFrCurrentTrip = modelFrCurrentTrip;
        notifyDataSetChanged();
    }

    //for clearingd data when use swipeRefresh
    public void clear() {
        modelFrCurrentTrip.clear();
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int i) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_current_trip1, parent, false);
        return new ViewHolder(view);
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Trip model = modelFrCurrentTrip.get(position);

        Log.i("TAG", "onBindViewHolder: getStrUnitId " + model.getStrUnitIdDriver());
//        holder.txt_startPoint.setText(model.getStrOriginName());
//        holder.txt_destination.setText(model.getStrDestinationName());
        holder.txt_startPoint.setText(model.getStrOriginAddress());
        holder.txt_destination.setText(model.getStrDestinationAddress());

        holder.txt_date.setText(model.getStrTripDate() + " - " + model.getStrTripTime());
        holder.row_tripStatus.setText(model.getStrOfficialStatus_strComment());
        holder.row_startpoint_TripCode.setText(String.valueOf(model.getiOfficialTrip()));
        if (model.getStrDriverName() == null || model.getStrDriverName().equals("")) {
            holder.txt_driver_name.setText("راننده اختصاص نیافته");
        } else
            holder.txt_driver_name.setText(model.getStrDriverName());

        holder.row_tripImportance.setText(model.getStrTripImportance_strComment());
        if (model.getStrTripImportance_strComment() != null) {
            switch (model.getStrTripImportance_strComment()) {
                case "عادی":
                    holder.row_tripImportance.setBackground(ContextCompat.getDrawable(context
                            , R.drawable.shape_circle_normal));
                    holder.row_tripImportance.setTextColor(context.getResources().getColor(R.color.colorText));
                    break;
                case "فوری":
                    holder.row_tripImportance.setBackground(ContextCompat.getDrawable(context
                            , R.drawable.shape_circle_urgent));
                    holder.row_tripImportance.setTextColor(context.getResources().getColor(R.color.colorOrenge));
                    break;
                case "خیلی فوری":
                    holder.row_tripImportance.setBackground(ContextCompat.getDrawable(context
                            , R.drawable.shape_circle_very_urgent));
                    holder.row_tripImportance.setTextColor(context.getResources().getColor(R.color.colorPink));
                    break;
            }
        }

        //todo url driverImage
        if (model.getImageDriver() != null && !model.getImageDriver().equals("")) {
            byte[] decodedString = Base64.decode(model.getImageDriver(), Base64.DEFAULT);
            Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
            Glide.with(context).load(decodedByte).into(holder.img_driver);
        }
//        Glide.with(context).load(url).into(holder.img_driver);

        holder.itemView.setOnClickListener(v -> {
//            SignatureActivity.model = model;
            if (model.getTiTripStatus() == 7) {
                App.notifModel = null;
                Bundle nbundle = new Bundle();
                nbundle.putParcelable("signature", model);
                Intent nintent = new Intent(context, SignatureActivity.class);
                nintent.putExtras(nbundle);
                context.startActivity(nintent);
                Log.i(TAG, "onBindViewHolder: SignatureActivity");
//                Intent intent = new Intent(context, SignatureActivity.class);
//                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//                context.startActivity(intent);
            } else {
//                CurrentTripDetailsActivity.model = model;
//                Intent intent = new Intent(context, CurrentTripDetailsActivity.class);
//                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//                context.startActivity(intent);

                Bundle mbundle = new Bundle();
                mbundle.putParcelable("MyModel", model);
//                mbundle.putString("unitId", model.getStrUnitIdDriver());
                Intent mintent = new Intent(context, CurrentTripDetailsActivity.class);
                mintent.putExtras(mbundle);
                context.startActivity(mintent);
            }
        });

        holder.img_driver.setOnClickListener(v -> {
            if (model.getImageDriver().isEmpty()) {
                Toaster.longer("راننده ای اختصاص داده نشده");
            } else {
                Intent intent = new Intent(context, ZoomImageActivity.class);
                intent.putExtra("image", model.getImageDriver());
                intent.putExtra("typeImage", STR_BITMAP);
                context.startActivity(intent);
            }
        });
    }

    public String NumToPersion(String a) {
        String[] pNum = new String[]{"۰", "۱", "۲", "۳", "۴", "۵", "۶", "۷", "۸", "۹"};
        a = a.replace("0", pNum[0]);
        a = a.replace("1", pNum[1]);
        a = a.replace("2", pNum[2]);
        a = a.replace("3", pNum[3]);
        a = a.replace("4", pNum[4]);
        a = a.replace("5", pNum[5]);
        a = a.replace("6", pNum[6]);
        a = a.replace("7", pNum[7]);
        a = a.replace("8", pNum[8]);
        a = a.replace("9", pNum[9]);
        return a;
    }

    @Override
    public int getItemCount() {
        if (modelFrCurrentTrip != null) {
            return modelFrCurrentTrip.size();
        }
        return 0;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView txt_driver_name, txt_startPoint, txt_destination, txt_date, row_tripStatus, row_startpoint_TripCode, row_tripImportance;
        ImageView img_driver;
        CardView row_history_cv;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            row_startpoint_TripCode = itemView.findViewById(R.id.row_startpoint_TripCode);
            row_history_cv = itemView.findViewById(R.id.row_currentTrip_cv);
            txt_driver_name = itemView.findViewById(R.id.row_driverNameCurrentTrip);
            txt_startPoint = itemView.findViewById(R.id.row_startpoint_CurrentTrip);
            txt_destination = itemView.findViewById(R.id.row_destination_currentTrip);
            img_driver = itemView.findViewById(R.id.img_row_current);
            row_tripStatus = itemView.findViewById(R.id.row_tripStatus_currentTrip);
            txt_date = itemView.findViewById(R.id.row_date_currentTrip);
            row_tripImportance = itemView.findViewById(R.id.row_tripImportance);
        }
    }
}

