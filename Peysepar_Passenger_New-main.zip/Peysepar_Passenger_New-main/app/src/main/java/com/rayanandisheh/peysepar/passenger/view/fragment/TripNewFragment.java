package com.rayanandisheh.peysepar.passenger.view.fragment;


import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import android.widget.ImageView;
import android.widget.ProgressBar;

import com.rayanandisheh.peysepar.passenger.R;
import com.rayanandisheh.peysepar.passenger.helpers.App;
import com.rayanandisheh.peysepar.passenger.helpers.Time;
import com.rayanandisheh.peysepar.passenger.helpers.Toaster;
import com.rayanandisheh.peysepar.passenger.models.Data;
import com.rayanandisheh.peysepar.passenger.models.Trip;
import com.rayanandisheh.peysepar.passenger.services.APIClient;
import com.rayanandisheh.peysepar.passenger.services.APIService;
import com.rayanandisheh.peysepar.passenger.view.Activity.LoginActivity;
import com.rayanandisheh.peysepar.passenger.view.Activity.TripManagementNewActivity;
import com.rayanandisheh.peysepar.passenger.view.Adapter.TripNewFragmentAdapter;

import java.util.List;

import jp.wasabeef.recyclerview.adapters.AlphaInAnimationAdapter;
import jp.wasabeef.recyclerview.adapters.ScaleInAnimationAdapter;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * A simple {@link Fragment} subclass.
 */
public class TripNewFragment extends Fragment {
    Context context;

    ProgressBar progressBarNewTabLayout;
    RecyclerView recyclerView;
    SwipeRefreshLayout swp_newTabLayout;
    TripNewFragmentAdapter adapter;
    ImageView img_noItem;

/////////////////////////////////

//    List<ModelTestNewFragment> modelTestNewFragments=new ArrayList<>();

//////////////////////////////////

    public TripNewFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_trip_new, container, false);

        context = getContext();
        bindView(view);

        viewLoaded();

        swp_newTabLayout.setOnRefreshListener(() -> swpNewTabLayoutPressed());

        /////////////////////////////////////////////
//        adapter=new TripManagementNewAdapter(modelTestNewFragments,context, (Presenter) presenter);
//        recyclerView.setLayoutManager(new LinearLayoutManager(context));
////        recyclerView.setAdapter(adapter);
//        AlphaInAnimationAdapter alphaAdapter = new AlphaInAnimationAdapter(adapter);
//        recyclerView.setAdapter(new ScaleInAnimationAdapter(alphaAdapter));

//        sendDataToRecyclerNewFragment();

        //////////////////////////////////////////////////

        return view;
    }

    private void bindView(View view) {
        recyclerView = view.findViewById(R.id.rv_newFragment);
        progressBarNewTabLayout = view.findViewById(R.id.progressBarNewTabLayout);
        img_noItem = view.findViewById(R.id.img_noIconNewTabLayout);
        swp_newTabLayout = view.findViewById(R.id.swp_newTabLayout);
    }

    public void showSwipeRefresh() {
        swp_newTabLayout.setRefreshing(true);
//        Toast.makeText(context, "new", Toast.LENGTH_SHORT).show();
    }

    public void hideImg_noItem() {
        img_noItem.setVisibility(View.GONE);
    }

    public void showImg_noItem() {
        img_noItem.setVisibility(View.VISIBLE);
    }

    public void hideSwipeRefresh() {
        swp_newTabLayout.setRefreshing(false);
    }

    public void setAdapter() {
//        adapter = new TripManagementNewAdapter(App.listHistoryTrip,context);
        adapter = new TripNewFragmentAdapter(App.listNewTabLayoutTrip, context, new TripNewFragmentAdapter.OnClick() {
            @Override
            public void confirmNewTripManagement(int iOfficialTrip) {
                confirmNewAlertTabLayoutTripManagement(iOfficialTrip);
            }

            @Override
            public void cancelNewTripManagement(int iOfficialTrip) {
                cancelNewAlertTabLayoutTripManagement(iOfficialTrip);
            }
        });
        recyclerView.setLayoutManager(new LinearLayoutManager(context));
        AlphaInAnimationAdapter alphaAdapter = new AlphaInAnimationAdapter(adapter);
        recyclerView.setAdapter(new ScaleInAnimationAdapter(alphaAdapter));
    }

    @Override
    public void onResume() {
        super.onResume();
        swpNewTabLayoutPressed();
    }

    public void requesrListNewTabLayout() {

        if (App.dateFromTripManagement.equals("") && App.dateToTripManagement.equals("")) {
            App.userInfo.setDateFrom(Time.getNowPersianDate());
            App.userInfo.setDateTo(Time.getNowPersianDate());
        } else if (!App.dateFromTripManagement.equals("") && !App.dateToTripManagement.equals("")) {
            App.userInfo.setDateFrom(App.dateFromTripManagement);
            App.userInfo.setDateTo(App.dateToTripManagement);
        } else if (!App.dateFromTripManagement.equals("") && App.dateToTripManagement.equals("")) {
            App.userInfo.setDateFrom(App.dateFromTripManagement);
            App.userInfo.setDateTo(Time.getNowPersianDate());
        } else if (App.dateFromTripManagement.equals("") && !App.dateToTripManagement.equals("")) {
            App.userInfo.setDateFrom(Time.getNowPersianDate());
            App.userInfo.setDateTo(App.dateToTripManagement);
        }


        App.userInfo.setType(2);

        APIService apiService = APIClient.getClient().create(APIService.class);
        Call<List<Trip>> call = apiService.manageTrip(App.userInfo,App.Session);
        call.enqueue(new Callback<List<Trip>>() {
            @Override
            public void onResponse(Call<List<Trip>> call, Response<List<Trip>> response) {
                if (response.code() == 200) {
                    App.newTabLayoutListSuccess = false;

                    App.listNewTabLayoutTrip = response.body();
                    if (App.listNewTabLayoutTrip != null) {
                        loadDataResult(1);
                    } else {
                        loadDataResult(0);
                    }
                } else {
                    loadDataResult(-4);
                }
            }

            @Override
            public void onFailure(Call<List<Trip>> call, Throwable t) {
                loadDataResult(-5);
            }
        });
    }

    public void requestCancelNewAlertTabLayoutTripManagement(int iOfficialTrip) {

        Trip trip = new Trip();
        trip.setiOfficialTrip(iOfficialTrip);

        APIService apiService = APIClient.getClient().create(APIService.class);
        Call<Integer> call = apiService.cancelTrip(trip, "",App.Session);

        call.enqueue(new Callback<Integer>() {
            @Override
            public void onResponse(Call<Integer> call, Response<Integer> response) {
                if (response.code() == 200) {
                    cencelTripAlertNewTabLayoutResult(response.body());
                } else {
                    cencelTripAlertNewTabLayoutResult(-4);
                }
            }

            @Override
            public void onFailure(Call<Integer> call, Throwable t) {
                cencelTripAlertNewTabLayoutResult(-5);
            }
        });
    }

    public void requestConfirmNewAlertTabLayoutTripManagement(int iOfficialTrip) {
        Trip trip = new Trip();
        trip.setiOfficialTrip(iOfficialTrip);

        APIService apiService = APIClient.getClient().create(APIService.class);
        Call<Data> call = apiService.managmentConfirm(trip,App.Session);
        call.enqueue(new Callback<Data>() {
            @Override
            public void onResponse(Call<Data> call, Response<Data> response) {
                if (response.code() == 200) {
                    App.data = response.body();
                    confirmTripAlertNewTabLayoutResult(response.body().getResult());
                } else {
                    confirmTripAlertNewTabLayoutResult(-4);
                }
            }

            @Override
            public void onFailure(Call<Data> call, Throwable t) {
                confirmTripAlertNewTabLayoutResult(-5);
            }
        });

    }

    public void viewLoaded() {

        if (App.newTabLayoutListSuccess) {
            showSwipeRefresh();
            requesrListNewTabLayout();

        } else if (App.listNewTabLayoutTrip.size() > 0) {
//            view.setAdapter();
            hideImg_noItem();
        } else if (App.listNewTabLayoutTrip.size() == 0) {
            showImg_noItem();
        }

    }

    public void swpNewTabLayoutPressed() {
        showSwipeRefresh();
        requesrListNewTabLayout();
    }

    public void loadDataResult(int result) {
//        view.stopProgressLoading();
        hideSwipeRefresh();
        if (result == -4)
            Toaster.shorter(context.getString(R.string.serverFaield));
        else if (result == -5)
            Toaster.shorter(context.getString(R.string.connectionFaield));
        else if (result == 0)
            showImg_noItem();
        else if (result == 1) {
            setAdapter();
            hideImg_noItem();
            if (App.listNewTabLayoutTrip.size() > 0)
                hideImg_noItem();
            else
                showImg_noItem();

        }else if(result==100){
            Intent intent = new Intent(getActivity(), LoginActivity.class);
            startActivity(intent);
        }
    }

    public void cancelNewAlertTabLayoutTripManagement(int iOfficialTrip) {
        showSwipeRefresh();
        requestCancelNewAlertTabLayoutTripManagement(iOfficialTrip);
    }

    public void cencelTripAlertNewTabLayoutResult(int result) {
        hideSwipeRefresh();
        if (result == -4) {
            Toaster.shorter(context.getString(R.string.serverFaield));
        } else if (result == -5) {
            Toaster.shorter(context.getString(R.string.connectionFaield));
        }
        else if (result == 100) {
            Intent intent=new Intent(getActivity(), LoginActivity.class);
            startActivity(intent);

        }
        else {
            Toaster.shorter("سفر شما با موفقیت لغو گردید");
            //to update list
            requesrListNewTabLayout();
        }

    }

    public void confirmNewAlertTabLayoutTripManagement(int iOfficialTrip) {
        showSwipeRefresh();
        requestConfirmNewAlertTabLayoutTripManagement(iOfficialTrip);
    }

    public void confirmTripAlertNewTabLayoutResult(int result) {
        hideSwipeRefresh();
        if (result == 1) {
            Toaster.shorter(App.data.getMessage());
            showSwipeRefresh();
            requesrListNewTabLayout();

        } else if (result == -2) {
            Toaster.shorter(App.data.getMessage());
        } else if (result == -1) {
            Toaster.shorter(App.data.getMessage());
        } else if (result == -5) {
            Toaster.shorter(context.getString(R.string.connectionFaield));
        }
        else if (result == 100) {
            Intent intent=new Intent(getActivity(), LoginActivity.class);
            startActivity(intent);
        }
    }

}
