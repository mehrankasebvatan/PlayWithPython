package com.rayanandisheh.peysepar.passenger.helpers;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import androidx.core.content.FileProvider;
import android.util.Log;
import android.widget.Toast;
import com.rayanandisheh.peysepar.passenger.BuildConfig;
import com.rayanandisheh.peysepar.passenger.R;

import java.io.File;

import static android.content.Context.DOWNLOAD_SERVICE;

public class DownloadManager {
//    private long DLid;
//    android.app.DownloadManager downloadManager;
//
//    public void DownloadUpdateApp(Context context) {
//        context.registerReceiver(downloadReceiver, new IntentFilter(android.app.DownloadManager.ACTION_DOWNLOAD_COMPLETE));
//        DLid = DownloadData(context);
//    }
//
//
//    private long DownloadData(Context context) {
//
//        long downloadReference;
//        downloadManager =
//                (android.app.DownloadManager) context.getSystemService(DOWNLOAD_SERVICE);
//        android.app.DownloadManager.Request request =
//// main               new android.app.DownloadManager.Request(Uri.parse(context.getResources().getString(R.string.app_url)));
//                new android.app.DownloadManager.Request(Uri.parse(App.userInfo.getDownloadLinkApp()));
//        request.setTitle(context.getResources().getString(R.string.app_name_persian));
//        request.setDescription(context.getResources().getString(R.string.update));
//        request.setNotificationVisibility(1);
//        request.setNotificationVisibility(android.app.DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
//        request.setMimeType("application/vnd.android.package-archive");
//        request.setVisibleInDownloadsUi(true);
//        request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, context.getResources().getString(R.string.app_name) + ".apk");
//        assert downloadManager != null;
//        downloadReference = downloadManager.enqueue(request);
//        return downloadReference;
//    }
//
//    private BroadcastReceiver downloadReceiver = new BroadcastReceiver() {
//        @Override
//        public void onReceive(Context context, Intent intent) {
//            long referenceId = intent.getLongExtra(android.app.DownloadManager.EXTRA_DOWNLOAD_ID, -1);
////            if (referenceId == DLid) {
////                Uri apkUri = Uri.fromFile(new File(Environment.getExternalStorageDirectory(),
////                        "Download/" + context.getResources().getString(R.string.app_name) + ".apk"));
////                intent = new Intent(Intent.ACTION_VIEW);
////                intent.setDataAndType(apkUri, "application/vnd.android.package-archive");
////                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
////                context.startActivity(intent);
////            }
//
//            if (referenceId == DLid) {
//
//                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
//
//                    try {
//                        File toInstall = new File(Environment.getExternalStorageDirectory(),
//                                "Download/Passenger.apk");
//                        if (toInstall.exists()) {
//                            Uri apkUri = FileProvider.getUriForFile(context, BuildConfig.APPLICATION_ID + ".com.vansuita.pickimage.provider", toInstall);
//                            Intent install = new Intent(Intent.ACTION_VIEW);
//                            install.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
//
//                            install.setDataAndType(apkUri, downloadManager.getMimeTypeForDownloadedFile(DLid));
//                            install.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
//                            context.startActivity(install);
//                        }
//                    } catch (Exception e) {
//                        Log.e("update", "onReceive: " + e.toString());
//                    }
//
//                    Toast.makeText(context, "فایل نصبی با موفقیت در پوشه دانلودهای شما ذخیره شد",
//                            Toast.LENGTH_LONG).show();
//                } else {
//                    Uri apkUri = Uri.fromFile(new File(Environment.getExternalStorageDirectory(),
//                            "Download/Passenger.apk"));
//                    intent = new Intent(Intent.ACTION_VIEW);
//                    intent.setDataAndType(apkUri, "application/vnd.android.package-archive");
//                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//                    context.startActivity(intent);
//                }
//
//            }
//
//        }
//    };
//
//    //file:///storage/emulated/0/Download/PeyseparPassenger.apk

}