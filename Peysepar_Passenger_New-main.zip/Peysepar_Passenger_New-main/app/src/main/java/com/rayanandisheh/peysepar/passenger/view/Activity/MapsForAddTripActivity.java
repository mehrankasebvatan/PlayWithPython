package com.rayanandisheh.peysepar.passenger.view.Activity;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.places.ui.PlaceAutocompleteFragment;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.UiSettings;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.rayanandisheh.peysepar.passenger.R;
import com.rayanandisheh.peysepar.passenger.helpers.App;
import com.rayanandisheh.peysepar.passenger.helpers.Converter;
import com.rayanandisheh.peysepar.passenger.helpers.MyLocation;
import com.rayanandisheh.peysepar.passenger.helpers.PersianAppcompatActivity;
import com.rayanandisheh.peysepar.passenger.helpers.PlaceAPI;
import com.rayanandisheh.peysepar.passenger.helpers.Toaster;
import com.rayanandisheh.peysepar.passenger.view.Adapter.PlacesAutoCompleteAdapter;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.Timer;
import java.util.TimerTask;

import javax.net.ssl.HttpsURLConnection;

import static com.rayanandisheh.peysepar.passenger.helpers.App.modeOfInsert;
import static com.rayanandisheh.peysepar.passenger.helpers.GetDistanceData.callDistance;

public class MapsForAddTripActivity extends PersianAppcompatActivity implements OnMapReadyCallback,
        LocationListener {

    private static final String TAG = "MapsForAddTripActivity";
    Timer timer = new Timer();
    private GoogleMap mMap;
    Marker selectLocation;
    public static Marker originSelectLocation, destintionSelectLocation;
    public static Boolean bln_map = false;
    Double mLat = 33.0;
    Double mLong = 53.0;
    float originLat, originLon, destinationLat, destinationLon;
    public static LatLng originLatLon;
    public static LatLng destinationLatLon;
    FloatingActionButton fab;
    public static boolean checkOriginAddress = true;
    public static boolean checkdestinationAddress = true;
    Activity activity;
    //object
    private FusedLocationProviderClient mFusedLocationProviderClient;
    Context context;
    public static int counter = 0;
    FusedLocationProviderClient mFusedLocationClient;
    LocationManager locationManager;
    private Marker marker2;
    private static final int LOCATION_PERMISSION_REQUEST_CODE = 1;
    PlaceAutocompleteFragment placeAutoComplete;
    EditText edtAddressSearched;
    Button btnSearch;
    String address = "";
    String encodedUrl = "";
    AutoCompleteTextView autoCompleteTextView;
    PlaceAPI nplaceapi = new PlaceAPI();
    double searchLat, searchLng;

    private RadioGroup rg_typeTrip;
    private RadioButton radioTypeButton;
    private RadioButton rb_oneWay;
    private RadioButton rb_roundAndRound;
    private RadioButton rb_available;

    BroadcastReceiver mBroadcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            receivedBroadcast(intent);
        }
    };

    @SuppressLint("MissingPermission")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            //getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE)
            setContentView(R.layout.activity_map_for_add_trip);
            activity = this;
            context = this;
            edtAddressSearched = findViewById(R.id.edtAddressSearched);
            btnSearch = findViewById(R.id.btnSearch);
            fab = findViewById(R.id.fab);
            autoCompleteTextView = findViewById(R.id.autoCompleteTextView);
            autoCompleteTextView.setAdapter(new PlacesAutoCompleteAdapter(context, R.layout.autocomplete_list_item));
            autoCompleteTextView.setVisibility(View.GONE);

//            txtAdrress = findViewById(R.id.txt_adrress);
            SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
            assert mapFragment != null;
            mapFragment.getMapAsync(this);

            MyLocation.getLocation2(context);
//            img_map_location = findViewById(R.id.img_map_location);
        } catch (Exception ignored) {
        }

        btnSearch.setOnClickListener(v -> {
            address = autoCompleteTextView.getText().toString();
            try {
                encodedUrl = URLEncoder.encode(address, "UTF-8");
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
            counter = counter + 1;
            // FOR MAP
            if (App.userInfo.isbEnableGoogleAPI()) {
//                new DataLongOperationAsynchTask().execute(encodedUrl);
                autoCompleteTextView.setText("");
            }
        });

        getingLocation();

        fab.setOnClickListener(view -> {
            addPlace();
            requestSetLocation();
        });
    }

    private void receivedBroadcast(Intent intent) {
        if (intent.getAction().matches("android.intent.action.map_result_ok") ||
                intent.getAction().matches("android.intent.action.map_result_fail")) {
            getExtras(intent.getStringExtra("description"));
        }
    }

    private void getExtras(String start_address) {
        try {

        } catch (Exception ignored) {
//            Toast.makeText(context, "bbbbbbbbbbbbb", Toast.LENGTH_LONG).show();
        }

        try {

            if (!start_address.isEmpty()) {
//                requestAddress.setText(start_address);
            }
        } catch (Exception e) {
//            Toast.makeText(context, "bbbbbbbbbbbbb", Toast.LENGTH_LONG).show();
        }

    }

    private void addPlace() {
        try {

//            getDataFromGoogle(String.valueOf(originLat), String.valueOf(originLon));

            Geocoder geocoder;
            List<Address> addresses = null;

            Locale locale = new Locale("fa");
            Locale.setDefault(locale);
            geocoder = new Geocoder(context, locale);
            String originAddress, destinationAddress;
            try {
                if (originLat == 0 || originLat < 1) {
                    Toast.makeText(context, "مبدا انتخاب نشده است", Toast.LENGTH_SHORT).show();
                    counter = 0;
                    return;
                } else if (destinationLat == 0 || destinationLat < 1) {
                    Toast.makeText(context, "مقصد انتخاب نشده است", Toast.LENGTH_SHORT).show();
                    counter = 1;
                    return;
                } else {
                    addresses = geocoder.getFromLocation(App.originLat, App.originLon, 1);// Here 1 represent max location result to returned, by documents it recommended 1 to 5
                    addresses = geocoder.getFromLocation(App.destinationLat, App.destinationLon, 1);
                }
                originAddress = addresses.get(0).getAddressLine(0);
                destinationAddress = addresses.get(1).getCountryName() + " - " + addresses.get(1).getLocality() + " - " + addresses.get(1).getFeatureName();

            } catch (Exception ignored) {
                originAddress = "";
                destinationAddress = "";
            }

            if (originLat != 0 && destinationLat != 0) {
                App.strOriginAddress = originAddress;
                App.strDestinationAddress = destinationAddress;
                App.originLat = originLat;
                App.originLon = originLon;
                App.destinationLat = destinationLat;
                App.destinationLon = destinationLon;

                Log.i(TAG, "requestAddTrip: originLat " + App.originLat);
                Log.i(TAG, "requestAddTrip: originLon " + App.originLon);
                Log.i(TAG, "requestAddTrip: destinationLat " + App.destinationLat);
                Log.i(TAG, "requestAddTrip: destinationLon " + App.destinationLon);

                bln_map = true;
                if (App.strOriginAddress.equals("") || App.strOriginAddress == null) {
                    checkOriginAddress = false;
                } else if (App.strDestinationAddress.equals("") || App.strDestinationAddress == null)
                    checkdestinationAddress = false;
                try {
                    if (Objects.requireNonNull(addresses).get(0).getLocality() != null && !addresses.get(0).getLocality().equals(""))
                        App.originCityName = addresses.get(0).getLocality();
                    else
                        App.originCityName = "";

                    if (Objects.requireNonNull(addresses).get(1).getLocality() != null && !addresses.get(1).getLocality().equals(""))
                        App.destinationCityName = addresses.get(1).getLocality();
                    else
                        App.destinationCityName = "";

                } catch (Exception ignore) {
                    App.originCityName = "";
                    App.destinationCityName = "";
                }
            }
        } catch (Exception e) {
            e.getClass().getSimpleName();
            Toast.makeText(context, "مکانی انتخاب نشده است - سعی مجدد", Toast.LENGTH_SHORT).show();
        }
    }

    class secondTask extends TimerTask {
        @Override
        public void run() {
            MapsForAddTripActivity.this.runOnUiThread(() -> {
                setLocation();
                if (mLat != null) {
//                    txtAdrress.setVisibility(View.INVISIBLE);
                    timer.cancel();
                }
            });
        }
    }

    public void getingLocation() {
        timer.schedule(new secondTask(), 1000, 1000);
    }

    private void requestSetLocation() {

        //TODO FOR MAP
        if (originLatLon != null && destinationLatLon != null
                && originSelectLocation != null && destintionSelectLocation != null) {
//            if (App.userInfo.isbEnableGoogleAPI())
            callDistance(originLatLon, destinationLatLon, mMap);
            modeOfInsert = "Map";
            startActivity(new Intent(context, AddTripWithMapActivity.class));
            finish();
            counter = 0;
        } else
            Toaster.longer("موقعیت مبدا و مقصد را مشخص کنید");

    }

    @Override
    protected void onResume() {
        super.onResume();
        IntentFilter iff = new IntentFilter();
        iff.addAction("android.intent.action.map_result_ok");
        iff.addAction("android.intent.action.map_result_fail");
        try {
            context.registerReceiver(mBroadcastReceiver, iff);
        } catch (IllegalArgumentException ignore) {
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        UiSettings mUiSettings = mMap.getUiSettings();
        mUiSettings.setZoomControlsEnabled(true);
        mUiSettings.setScrollGesturesEnabled(true);
        mUiSettings.setZoomGesturesEnabled(true);
        //mUiSettings.isMapToolbarEnabled();
//        mUiSettings.isTiltGesturesEnabled();

        mMap.setOnMyLocationButtonClickListener(onMyLocationButtonClickListener);
        enableMyLocationIfPermitted();
//        mMap.setMinZoomPreference(11);

        locationManager = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);
        boolean gps_enabled = false;
        boolean network_enabled = false;

        try {
            gps_enabled = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
        } catch (Exception ignored) {
        }

        try {
            network_enabled = locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
        } catch (Exception ignored) {
        }

        if (MyLocation.isLocationEnable(context, 33)) {

            if (gps_enabled && network_enabled) {

                if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                        && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    // TODO: Consider calling
                    //    ActivityCompat#requestPermissions
                    // here to request the missing permissions, and then overriding
                    //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                    //                                          int[] grantResults)
                    // to handle the case where the user grants the permission. See the documentation
                    // for ActivityCompat#requestPermissions for more details.
                    return;
                }
                Location locationGPS = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                Location locationNet = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);

                if (locationGPS != null) {
                    mLat = locationGPS.getLatitude();
                    mLong = locationGPS.getLongitude();
                    CameraPosition newCamPos = new CameraPosition(new LatLng(mLat, mLong),
                            15,
                            mMap.getCameraPosition().tilt, //use old tilt
                            mMap.getCameraPosition().bearing); //use old bearing
//                    marker2 = mMap.addMarker(new MarkerOptions().position(new LatLng(mLat, mLong)));
                    mMap.animateCamera(CameraUpdateFactory.newCameraPosition(newCamPos), 1000, null);
                }
            }
        }

        if (!gps_enabled || !network_enabled) {
            mMap.animateCamera(CameraUpdateFactory.newCameraPosition(new CameraPosition(new LatLng(mLat, mLong),
                    4.96f,
                    mMap.getCameraPosition().tilt, //use old tilt
                    mMap.getCameraPosition().bearing)), 300, null);
        }

        mLat = null;
        mLong = null;

        mMap.isMyLocationEnabled();

        mMap.setOnMapClickListener(point -> {

            if (ActivityCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                    && ActivityCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                return;
            }
            try {
                if (selectLocation != null)
                    selectLocation.remove();
                mMap.setMyLocationEnabled(true);

                float mZoom = mMap.getCameraPosition().zoom;
                if (mZoom < 16)
                    mZoom = 15;
                mLat = point.latitude;
                mLong = point.longitude;

                mLat = point.latitude;
                mLong = point.longitude;
                counter = counter + 1;

                if (mLat != null && mLong != null && mLat != 0 && mLong != 0) {

                    if (counter == 1) {
                        originLatLon = point;
                        originLat = (float) point.latitude;
                        originLon = (float) point.longitude;
//                            mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(originLatLon, 4f));
                        originSelectLocation = googleMap.addMarker(new MarkerOptions().position(point)
                                .snippet("مبدا").title("مبدا").icon(Converter.
                                        drawableToBitmap(context.getResources().getDrawable(R.drawable.new_ic_map3))));
                        originSelectLocation.showInfoWindow();
                    } else if (counter == 2) {
                        destinationLatLon = point;
                        destinationLat = (float) point.latitude;
                        destinationLon = (float) point.longitude;
//                            mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(destinationLatLon, 4f));
                        destintionSelectLocation = googleMap.addMarker(new MarkerOptions().position(point)
                                .snippet("مقصد").title("مقصد").icon(Converter.
                                        drawableToBitmap(context.getResources().getDrawable(R.drawable.new_dic_map3))));
                        destintionSelectLocation.showInfoWindow();
                    }
                    CameraPosition newCamPos = new CameraPosition(new LatLng(mLat, mLong),
                            mZoom,
                            mMap.getCameraPosition().tilt, //use old tilt
                            mMap.getCameraPosition().bearing); //use old bearing
                    mMap.animateCamera(CameraUpdateFactory.newCameraPosition(newCamPos), 1500, null);
                }

                Marker markers[] = {originSelectLocation, destintionSelectLocation};
                LatLngBounds.Builder builder = new LatLngBounds.Builder();
                for (Marker marker : markers) {
                    builder.include(marker.getPosition());
                }
                LatLngBounds bounds = builder.build();
                int width = context.getResources().getDisplayMetrics().widthPixels;
                int height = context.getResources().getDisplayMetrics().heightPixels;
                int padding = 150; // offset from edges of the map in pixels
                CameraUpdate cu = CameraUpdateFactory.newLatLngBounds(bounds, width, height, padding);
                googleMap.animateCamera(cu);
            } catch (Exception ignored) {
            }

        });

        mMap.setOnMyLocationButtonClickListener(new GoogleMap.OnMyLocationButtonClickListener() {
            @Override
            public boolean onMyLocationButtonClick() {
                setLocation();
                return false;
            }
        });

        mMap.setOnMarkerClickListener(new GoogleMap.OnMarkerClickListener() {
            @Override
            public boolean onMarkerClick(Marker marker) {
                try {
                    if (marker.getTitle().equals("-1")) {
                        return true;
                    } else
                        actionMarker(marker);

                } catch (Exception e) {
                }
                return true;
            }
        });
    }

    private void actionMarker(Marker marker) {

        AlertDialog.Builder dialog = new AlertDialog.Builder(context);
        dialog.setTitle(getResources().getString(R.string.app_name))
                .setIcon(getResources().getDrawable(R.mipmap.ic_launcher))
                .setMessage("نوع اقدام روی نقطه ؟");

        dialog.setPositiveButton("حرکت دادن", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                Toaster.shorter("موقعیت جدید را روی نقشه انتخاب نمایید");
                if (marker.getSnippet().equals("مبدا") || marker.getTitle().equals("مبدا")) {
                    originSelectLocation.remove();
                    originSelectLocation = null;
                    originLatLon = null;
                    counter = 0;
                } else if (marker.getSnippet().equals("مقصد") || marker.getTitle().equals("مقصد")) {
                    destinationLatLon = null;
                    destintionSelectLocation.remove();
                    destintionSelectLocation = null;
                    counter = 1;
                }
            }
        });


        dialog.setNeutralButton("انصراف", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        dialog.show();

    }

    @Override
    public void onBackPressed() {
        finish();
        super.onBackPressed();
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
    }

    public void setLocation() {
        try {
            if (selectLocation != null) {
                selectLocation.remove();
            }
            Location location = mMap.getMyLocation();
            mLat = location.getLatitude();
            mLong = location.getLongitude();

            float mZoom = mMap.getCameraPosition().zoom;
            if (mZoom < 16) mZoom = 19;

            CameraPosition newCamPos = new CameraPosition(new LatLng(mLat, mLong),
                    mZoom,
                    mMap.getCameraPosition().tilt, //use old tilt
                    mMap.getCameraPosition().bearing); //use old bearing
            mMap.animateCamera(CameraUpdateFactory.newCameraPosition(newCamPos), 1500, null);


        } catch (Exception ignored) {
        }
    }

    @Override
    public void onLocationChanged(Location location) {

    }

    @Override
    public void onStatusChanged(String s, int i, Bundle bundle) {

    }

    @Override
    public void onProviderEnabled(String provider) {
//        setLocation();
    }

    @Override
    public void onProviderDisabled(String s) {

    }

//    @Override
//    public void onConnected(@Nullable Bundle bundle) {
//        setLocation();
//    }
//
//    @Override
//    public void onConnectionSuspended(int i) {
//        setLocation();
//    }
//
//    @Override
//    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {
//
//    }

    private void enableMyLocationIfPermitted() {
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION,
                            Manifest.permission.ACCESS_FINE_LOCATION},
                    LOCATION_PERMISSION_REQUEST_CODE);
        } else if (mMap != null) {
            mMap.setMyLocationEnabled(true);
        }
    }

//    private void showDefaultLocation() {
////        LatLng redmond = new LatLng(mLat, mLong);
////        mMap.moveCamera(CameraUpdateFactory.newLatLng(redmond));
//        mMap.animateCamera(CameraUpdateFactory.newCameraPosition(new CameraPosition(new LatLng(mLat, mLong),
//                15,
//                mMap.getCameraPosition().tilt, //use old tilt
//                mMap.getCameraPosition().bearing)), 300, null);
//    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        switch (requestCode) {
            case LOCATION_PERMISSION_REQUEST_CODE: {
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    enableMyLocationIfPermitted();
                } else {
//                    showDefaultLocation();
                }
                return;
            }

        }
    }

    private GoogleMap.OnMyLocationButtonClickListener onMyLocationButtonClickListener =
            new GoogleMap.OnMyLocationButtonClickListener() {
                @Override
                public boolean onMyLocationButtonClick() {
                    mMap.setMinZoomPreference(20);
                    return false;
                }
            };

    @SuppressLint("StaticFieldLeak")
    private class DataLongOperationAsynchTask extends AsyncTask<String, Void, String[]> {

        ProgressDialog dialog = new ProgressDialog(context);

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            dialog.setMessage("لطفا صبر کنید ...");
            dialog.setCanceledOnTouchOutside(false);
            dialog.show();
        }

        @Override
        protected String[] doInBackground(String... strings) {
            String response;
            try {
                response = getLatLongByURL("https://maps.google.com/maps/api/geocode/json?address="
                        + encodedUrl + "&sensor=false&key= " + App.userInfo.getStrGoogleAPIKey() + "&language=fa&region=ir");
                return new String[]{response};
            } catch (Exception e) {
                return new String[]{"error"};
            }
        }

        @Override
        protected void onPostExecute(String... result) {
            try {
                JSONObject jsonObject = new JSONObject(result[0]);

                searchLng = ((JSONArray) jsonObject.get("results")).getJSONObject(0)
                        .getJSONObject("geometry").getJSONObject("location")
                        .getDouble("lng");

                searchLat = ((JSONArray) jsonObject.get("results")).getJSONObject(0)
                        .getJSONObject("geometry").getJSONObject("location")
                        .getDouble("lat");

                LatLng point = new LatLng(searchLat, searchLng);

                if (counter == 1) {
                    String origin = address;
                    originLatLon = point;
                    originLat = (float) point.latitude;
                    originLon = (float) point.longitude;
//                            mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(originLatLon, 4f));
                    originSelectLocation = mMap.addMarker(new MarkerOptions().position(point).title(origin).snippet("مبدا").icon(Converter.
                            drawableToBitmap(context.getResources().getDrawable(R.drawable.new_ic_map3))));
                    originSelectLocation.showInfoWindow();
                } else if (counter == 2) {
                    String destination = address;
                    destinationLatLon = point;
                    destinationLat = (float) point.latitude;
                    destinationLon = (float) point.longitude;
//                            mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(destinationLatLon, 4f));
                    destintionSelectLocation = mMap.addMarker(new MarkerOptions().position(point).title(destination).snippet("مقصد").icon(Converter.
                            drawableToBitmap(context.getResources().getDrawable(R.drawable.new_dic_map3))));
                    destintionSelectLocation.showInfoWindow();
                }

                CameraPosition newCamPos = new CameraPosition(point,
                        16,
                        mMap.getCameraPosition().tilt, //use old tilt
                        mMap.getCameraPosition().bearing); //use old bearing
                mMap.animateCamera(CameraUpdateFactory.newCameraPosition(newCamPos), 1500, null);

                if (originSelectLocation != null && destintionSelectLocation != null) {
                    Marker markers[] = {originSelectLocation, destintionSelectLocation};
                    LatLngBounds.Builder builder = new LatLngBounds.Builder();
                    for (Marker marker : markers) {
                        builder.include(marker.getPosition());
                    }
                    LatLngBounds bounds = builder.build();
                    int width = context.getResources().getDisplayMetrics().widthPixels;
                    int height = context.getResources().getDisplayMetrics().heightPixels;
                    int padding = 150; // offset from edges of the map in pixels
                    CameraUpdate cu = CameraUpdateFactory.newLatLngBounds(bounds, width, height, padding);
                    mMap.animateCamera(cu);
                }
                Log.d("latitude", "" + searchLat);
                Log.d("longitude", "" + searchLng);
            } catch (JSONException e) {
                e.printStackTrace();
            }
            if (dialog.isShowing()) {
                dialog.dismiss();
            }
        }
    }


    public String getLatLongByURL(String requestURL) {
        URL url;
        String response = "";
        try {
            url = new URL(requestURL);

            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setReadTimeout(15000);
            conn.setConnectTimeout(15000);
            conn.setRequestMethod("POST");
            conn.setDoInput(true);
            conn.setRequestProperty("Content-Type",
                    "application/x-www-form-urlencoded");
            conn.setDoOutput(true);
            int responseCode = conn.getResponseCode();

            if (responseCode == HttpsURLConnection.HTTP_OK) {
                String line;
                BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                while ((line = br.readLine()) != null) {
                    response += line;
                }
            } else {
                response = "";
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return response;
    }

}

//https://developers.google.com/places/web-service/search
//https://developers.google.com/places/android-sdk/autocomplete
//https://medium.com/rubicon-stories/creating-custom-views-in-android-a5589899df87

//https://maps.googleapis.com/maps/api/place/search/json?location=40.7463956,-73.9852992&radius=100&sensor=true&key={key}
//https://www.journaldev.com/13911/google-places-api
//https://www.viralandroid.com/2016/04/google-maps-android-api-adding-search-bar-part-3.html
//https://maps.googleapis.com/maps/api/distancematrix/json?origins=Washington,DC&destinations=New+York+City,NY&key=YOUR_API_KEY


//https://docs.mapbox.com/help/tutorials/first-steps-android-sdk/
//Base transceiver station(BTS)

//https://stackoverflow.com/questions/9836434/google-places-api-how-to-get

//https://developers.google.com/places/web-service/autocomplete  لینک اندروید دولوپر

//این جواب داده
//https://maps.googleapis.com/maps/api/place/autocomplete/json?input=تهران&language=pt_BR&key=AIzaSyD4Lt0Jg_fEDcqmM-Fr_M8woUICXf3wfgo&language=fa&region=ir
//https://maps.googleapis.com/maps/api/place/autocomplete/json?input=مش&key=AIzaSyD4Lt0Jg_fEDcqmM-Fr_M8woUICXf3wfgo&language=fa&region=ir
//https://developers.google.com/places/web-service/search

//https://stackoverflow.com/questions/49878393/how-to-get-result-of-google-place-autocomplete-api-returned-in-a-variable-instea/49879199

//https://maps.googleapis.com/maps/api/geocode/json?address=1600+Amphitheatre+Parkway,+Mountain+View,+CA&key=YOUR_API_KEY
//https://stackoverflow.com/questions/15711499/get-latitude-and-longitude-with-geocoder-and-android-google-maps-api-v2

//https://www.journaldev.com/15676/android-geocoder-reverse-geocoding