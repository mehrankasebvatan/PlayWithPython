package com.rayanandisheh.peysepar.passenger.helpers;

import android.util.Log;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;

public class DataParser {

    private static final String TAG = "DataParser";

    public HashMap<String, String> parseAddress(String jsonData) {
        JSONObject jsonArray = null;
        JSONObject jsonObject;
        try {
            jsonObject = new JSONObject(jsonData);
            jsonArray = jsonObject.getJSONArray("routes").getJSONObject(0).getJSONArray("legs")
                    .getJSONObject(0);//.getJSONArray("steps");// legs array
        } catch (JSONException e) {
            Log.e(TAG, "parseDistance: JSONException ->" + e.getMessage());
        }
        return getAddress(jsonArray);
    }

    public HashMap<String, Double> parseSearch(String jsonAddress) {
        JSONObject jsonArray = null;
        JSONObject jsonObject;
        try {
            jsonObject = new JSONObject(jsonAddress);
            jsonArray = ((JSONArray)jsonObject.get("results")).getJSONObject(0)
                    .getJSONObject("geometry").getJSONObject("location");
        } catch (JSONException e) {
            Log.e(TAG, "parseLocation: JSONException ->" + e.getMessage());
        }
        return getsearchedAddress(jsonArray);
    }

    private HashMap<String, String> getAddress(JSONObject googleAddressJson) {
        HashMap<String, String> googleAddressMap = new HashMap<>();
        try {
            Log.i(TAG, "Json response: " + googleAddressJson.toString());
            googleAddressMap.put("start_address", googleAddressJson.getString("start_address"));
            googleAddressMap.put("end_address", googleAddressJson.getString("end_address"));
        } catch (JSONException e) {
            Log.e(TAG, "getOrigin: JSONException " + e.getMessage());
        } catch (Exception e) {
            Log.e(TAG, "getDestination: " + e.toString());
        }
        return googleAddressMap;
    }

    private HashMap<String, Double> getsearchedAddress(JSONObject googlesearchedJson) {
        HashMap<String, Double> googleAddressMap = new HashMap<>();
        try {
            Log.i(TAG, "Json response: " + googlesearchedJson.toString());
            googleAddressMap.put("lat", googlesearchedJson.getDouble("lat"));
            googleAddressMap.put("lon", googlesearchedJson.getDouble("lng"));
        } catch (JSONException e) {
            Log.e(TAG, "getOrigin: JSONException " + e.getMessage());
        } catch (Exception e) {
            Log.e(TAG, "getDestination: " + e.toString());
        }
        return googleAddressMap;
    }

}
//https://stackoverflow.com/questions/15711499/get-latitude-and-longitude-with-geocoder-and-android-google-maps-api-v2