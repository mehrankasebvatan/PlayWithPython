package com.rayanandisheh.peysepar.passenger.helpers;

import android.content.Context;
import android.os.Bundle;
import android.view.WindowManager;

import androidx.appcompat.app.AppCompatActivity;

import com.rayanandisheh.peysepar.passenger.R;

public class PersianAppcompatActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
//            ViewPump.init(ViewPump.builder()
//                    .addInterceptor(new CalligraphyInterceptor(
//                            new CalligraphyConfig.Builder()
//                                    .setDefaultFontPath("IRANSansMobile.ttf")
//                                    .setFontAttrId(R.attr.fontPath)
//                                    .build()))
//                    .build());

//        CalligraphyConfig.initDefault(new CalligraphyConfig.Builder()
//                .setDefaultFontPath("iran_sans.ttf")
//                .setFontAttrId(R.attr.fontPath)
//                .build()
//        );

        super.onCreate(savedInstanceState);
       //getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE)

    }

    // for font
//    @Override
//    protected void attachBaseContext(Context newBase) {
//        super.attachBaseContext(ViewPumpContextWrapper.wrap(newBase));
//    }
}