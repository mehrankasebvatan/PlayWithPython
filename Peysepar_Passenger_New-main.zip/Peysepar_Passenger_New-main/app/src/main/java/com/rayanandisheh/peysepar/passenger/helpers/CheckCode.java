package com.rayanandisheh.peysepar.passenger.helpers;

public class CheckCode {

    public static boolean isNationalCode(String code) {
        if (code.isEmpty()) {
            return true;
        } else {
            if (code.length() < 10 || code.length() > 10) {
                return false;
            } else if ((code == "1111111111") || (code == "2222222222") || (code == "3333333333") || (code == "4444444444")
                    || (code == "5555555555") || (code == "6666666666") || (code == "7777777777") || (code == "8888888888") || (code == "9999999999") || (code == "0000000000")) {
                return false;
            } else {
                int c = 0;
                int r = 0;
                try {
                    c = Integer.parseInt(String.valueOf(code.charAt(9)));
                    int n = Integer.parseInt(String.valueOf(code.charAt(0))) * 10
                            + Integer.parseInt(String.valueOf(code.charAt(1))) * 9
                            + Integer.parseInt(String.valueOf(code.charAt(2))) * 8
                            + Integer.parseInt(String.valueOf(code.charAt(3))) * 7
                            + Integer.parseInt(String.valueOf(code.charAt(4))) * 6
                            + Integer.parseInt(String.valueOf(code.charAt(5))) * 5
                            + Integer.parseInt(String.valueOf(code.charAt(6))) * 4
                            + Integer.parseInt(String.valueOf(code.charAt(7))) * 3
                            + Integer.parseInt(String.valueOf(code.charAt(8))) * 2;
                    r = n - Integer.parseInt(String.valueOf(n / 11)) * 11;
                } catch (NumberFormatException e) {
                    return false;
                }

                return (r == 0 && r == c) || (r == 1 && c == 1) || (r > 1 && c == 11 - r);
            }
        }
    }
}
