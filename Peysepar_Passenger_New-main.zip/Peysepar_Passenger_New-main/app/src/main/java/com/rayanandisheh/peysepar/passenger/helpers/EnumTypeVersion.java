package com.rayanandisheh.peysepar.passenger.helpers;

public enum EnumTypeVersion {
    LAST_VERSION, MIN_VALID_VERSION
}
