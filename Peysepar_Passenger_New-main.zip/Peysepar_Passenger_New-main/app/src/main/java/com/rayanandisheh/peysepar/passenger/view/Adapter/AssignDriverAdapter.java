package com.rayanandisheh.peysepar.passenger.view.Adapter;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.rayanandisheh.peysepar.passenger.R;
import com.rayanandisheh.peysepar.passenger.models.DriverInfo;

import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class AssignDriverAdapter extends RecyclerView.Adapter<AssignDriverAdapter.ViewHolder> {
    public List<DriverInfo> driverInfoModel;
    Context context;
    String MaxTime , MinTime;
    onClick onClick;
    public interface onClick {
        void confirmAlertSelectedDriver(String Strunitid, int Iofficialtrip);
    }

    public AssignDriverAdapter(List<DriverInfo> driverInfoModel, Context context, onClick onClick) {
        this.driverInfoModel = driverInfoModel;
        this.context = context;
        this.onClick = onClick;
    }

    @NonNull
    @Override
    public AssignDriverAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View viewNewFragment = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_assign_driver, parent, false);
        return new ViewHolder(viewNewFragment);
    }

    @SuppressLint("ResourceAsColor")
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        DriverInfo model = driverInfoModel.get(position);
        holder.txt_driverName.setText(model.getDrivername());
        holder.txt_carName.setText(model.getMobileName());
        holder.txt_carType.setText(model.getMobiletype());
        holder.txt_status.setText(model.getDriverStatus());
        holder.txt_todayServiceCount.setText(String.valueOf(model.getTripcount()));

        if (model.getImageDriver() != null && !model.getImageDriver().equals("")) {
            byte[] decodedString = Base64.decode(model.getImageDriver(), Base64.DEFAULT);
            Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
            Glide.with(context).load(decodedByte).into(holder.driverImagge);
        }

//        Glide.with(context).load(model.getImageDriver()).into(holder.driverImagge);

        if (model.getStrTime() != null) {
            MaxTime = driverInfoModel.get(0).getStrTime();
            for (int i = 1; i < driverInfoModel.size(); i++) {
                    if (driverInfoModel.get(i).getStrTime().length()<=4) {
                        if (Integer.valueOf(driverInfoModel.get(i).getStrTime())> Integer.valueOf( MaxTime)){
                            MaxTime = driverInfoModel.get(i).getStrTime();
                        }
                    }
            }
            MinTime = driverInfoModel.get(0).getStrTime();
            for (int i = 1; i < driverInfoModel.size(); i++) {
                if (driverInfoModel.get(i).getStrTime().length()<=4) {
                    if (Integer.valueOf(driverInfoModel.get(i).getStrTime())< Integer.valueOf( MinTime)){
                        MinTime = driverInfoModel.get(i).getStrTime();
                    }
                }
            }

            if (model.getStrTime().equals(MinTime)) {
                holder.tv_arriveTimeToOrigin.setTextColor(Color.parseColor("#008000"));
                holder.txtmin.setTextColor(Color.parseColor("#008000"));
                holder.txtArriveTime.setTextColor(Color.parseColor("#008000"));
            } else if (model.getStrTime().equals(MaxTime)) {
                holder.tv_arriveTimeToOrigin.setTextColor(Color.parseColor("#cc0000"));
                holder.txtmin.setTextColor(Color.parseColor("#cc0000"));
                holder.txtArriveTime.setTextColor(Color.parseColor("#cc0000"));
            } else {
                holder.tv_arriveTimeToOrigin.setTextColor(Color.parseColor("#0047b3"));
                holder.txtmin.setTextColor(Color.parseColor("#0047b3"));
                holder.txtArriveTime.setTextColor(Color.parseColor("#0047b3"));
            }

            if (model.getStrTime().equals("موقعیتی ثبت نشده است")) {
                holder.txtmin.setVisibility(View.GONE);
//                holder.tv_arriveTimeToOrigin.setTextColor(Color.parseColor("#0047b3"));
//                holder.txtmin.setTextColor(Color.parseColor("#0047b3"));
//                holder.txtArriveTime.setTextColor(Color.parseColor("#0047b3"));
            } else
                holder.txtmin.setVisibility(View.VISIBLE);

            holder.timeLayout.setVisibility(View.VISIBLE);
            holder.tv_arriveTimeToOrigin.setText(model.getStrTime());

//            Base64.encodeToString(model.getImageDriver(), Base64.DEFAULT);


        } else
            holder.timeLayout.setVisibility(View.GONE);
        //todo driver_image must be put via picasso


        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

//               presenter.checkStatusOfDriver(model.getDrivername());

                AlertDialog.Builder dialog = new AlertDialog.Builder(context);
                dialog.setMessage("راننده انتخابی شما : " + model.getDrivername() + "\n" + "\n" + "نوع خودرو : " + model.getMobiletype() + "\n");
                dialog.setPositiveButton("تایید", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        //request to server
//                        Toaster.shorter("تایید");
                        onClick.confirmAlertSelectedDriver(model.getStrunitid(), model.getIofficialtrip());
                    }
                });
                dialog.setNegativeButton("لغو", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
//                        Toaster.shorter("لغو");
                    }
                });
                dialog.create().show();
            }
        });
    }

    @Override
    public int getItemCount() {
        return driverInfoModel.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        TextView txt_driverName, txt_carType, txt_carName, txt_status, txt_todayServiceCount,
                tv_arriveTimeToOrigin, txtmin, txtArriveTime;
        CircleImageView driverImagge;
        LinearLayout timeLayout;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            txt_driverName = itemView.findViewById(R.id.row_driverNameAssignDriver);
            txt_carName = itemView.findViewById(R.id.row_carNameAssignDriver);
            txt_carType = itemView.findViewById(R.id.row_carTypeAssignDriver);
            txt_status = itemView.findViewById(R.id.row_statusAssignDriver);
            txt_todayServiceCount = itemView.findViewById(R.id.row_todayServiceCountAssignDriver);
            driverImagge = itemView.findViewById(R.id.row_assignDriver_img);
            tv_arriveTimeToOrigin = itemView.findViewById(R.id.tv_arriveTimeToOrigin);
            timeLayout = itemView.findViewById(R.id.timeLayout);
            txtmin = itemView.findViewById(R.id.txtmin);
            txtArriveTime = itemView.findViewById(R.id.txtArriveTime);
        }
    }
}
