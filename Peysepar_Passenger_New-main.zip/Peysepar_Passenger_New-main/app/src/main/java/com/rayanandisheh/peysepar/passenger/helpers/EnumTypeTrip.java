package com.rayanandisheh.peysepar.passenger.helpers;

public enum EnumTypeTrip {
    ONE_WAY //یک طرفه
    ,ROUND_AND_ROUND // رفت و برگشت
    ,AVAILABLE // در اختیار
}
