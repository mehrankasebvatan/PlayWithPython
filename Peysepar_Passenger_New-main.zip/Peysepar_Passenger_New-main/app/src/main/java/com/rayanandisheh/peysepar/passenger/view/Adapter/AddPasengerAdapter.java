package com.rayanandisheh.peysepar.passenger.view.Adapter;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.rayanandisheh.peysepar.passenger.R;

import java.util.ArrayList;
import java.util.List;

import static android.content.ContentValues.TAG;

public class AddPasengerAdapter extends RecyclerView.Adapter<AddPasengerAdapter.ItemHolder> {

    private List<String> itemsName;
    private OnItemClickListener onItemClickListener;
    private LayoutInflater layoutInflater;

    public AddPasengerAdapter(Context context) {
        layoutInflater = LayoutInflater.from(context);
        itemsName = new ArrayList<String>();
    }

    @Override

    public AddPasengerAdapter.ItemHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = layoutInflater.inflate(R.layout.row_add_passengers, parent, false);
        return new ItemHolder(itemView, this);

    }

    @Override

    public void onBindViewHolder(AddPasengerAdapter.ItemHolder holder, int position) {
        holder.setItemName(itemsName.get(position));
//        holder.img_remove.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Log.d(TAG, "onClick: " + position);
//        remove(position);
//            }
//        });
    }

    @Override

    public int getItemCount() {
        return itemsName.size();

    }

    //for sending to server
    public String getList() {
        StringBuilder list = new StringBuilder();
        if (itemsName.size() > 0)
            for (String s : itemsName) {
                list.append(s).append(",");
            }
        if (list.length() > 0)
            list.deleteCharAt(list.length() - 1);
        return list.toString();
    }


    public void setOnItemClickListener(OnItemClickListener listener) {
        onItemClickListener = listener;

    }

    public OnItemClickListener getOnItemClickListener() {
        return onItemClickListener;
    }


    public interface OnItemClickListener {
        public void onItemClick(ItemHolder item, int position);

    }

    public void add(int location, String iName) {

        itemsName.add(location, iName);
        notifyItemInserted(location);

    }

    public void remove(int location) {
        if (location >= itemsName.size())
            return;
        itemsName.remove(location);
        notifyItemRemoved(location);

    }

    public static class ItemHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        ImageButton img_remove;
        private AddPasengerAdapter parent;
        TextView textItemName;

        public ItemHolder(View itemView, AddPasengerAdapter parent) {

            super(itemView);
            itemView.setOnClickListener(this);
            this.parent = parent;
            textItemName = itemView.findViewById(R.id.txtPassengerName);
            img_remove = itemView.findViewById(R.id.img_remove);
        }

        public void setItemName(CharSequence name) {

            textItemName.setText(name);

        }

        public CharSequence getItemName() {

            return textItemName.getText();

        }

        @Override
        public void onClick(View v) {
            final OnItemClickListener listener = parent.getOnItemClickListener();
            if (listener != null) {

                listener.onItemClick(this, getPosition());

            }
        }
    }
}
