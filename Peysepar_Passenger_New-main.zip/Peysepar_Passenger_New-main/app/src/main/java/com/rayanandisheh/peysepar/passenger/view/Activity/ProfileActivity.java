package com.rayanandisheh.peysepar.passenger.view.Activity;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.location.LocationManager;
import android.os.Bundle;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;
import com.rayanandisheh.peysepar.passenger.R;
import com.rayanandisheh.peysepar.passenger.helpers.App;
import com.rayanandisheh.peysepar.passenger.helpers.Cache;
import com.rayanandisheh.peysepar.passenger.helpers.CheckCode;
import com.rayanandisheh.peysepar.passenger.helpers.Converter;
import com.rayanandisheh.peysepar.passenger.helpers.PersianAppcompatActivity;
import com.rayanandisheh.peysepar.passenger.helpers.Toaster;
import com.rayanandisheh.peysepar.passenger.helpers.Validate;
import com.rayanandisheh.peysepar.passenger.models.Register;
import com.rayanandisheh.peysepar.passenger.models.UserInfo;
import com.rayanandisheh.peysepar.passenger.services.APIClient;
import com.rayanandisheh.peysepar.passenger.services.APIService;
import com.squareup.picasso.MemoryPolicy;
import com.squareup.picasso.NetworkPolicy;
import com.squareup.picasso.Picasso;
import com.vansuita.pickimage.bean.PickResult;
import com.vansuita.pickimage.bundle.PickSetup;
import com.vansuita.pickimage.dialog.PickImageDialog;
import com.vansuita.pickimage.listeners.IPickResult;

import java.util.regex.Pattern;

import de.hdodenhof.circleimageview.CircleImageView;
import ir.hamsaa.persiandatepicker.Listener;
import ir.hamsaa.persiandatepicker.PersianDatePickerDialog;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ProfileActivity extends PersianAppcompatActivity implements IPickResult {
    Context context;
    private static final String TAG = "ProfileActivity";

    //    Toolbar toolbar;
    TextView txtMobileProfile, tvProfilePic, txtSelectedPositionName, txtOrgPosition;
    CircleImageView ivProfilePic;
    Bitmap bmProfile;
    EditText edtNameProfile, edtFamilyProfile, edtNationalIDProfile, edtOptionalOrigin;
    //    RadioGroup radioGroup;
    RadioButton rbMan;
    Button btn;
    ProgressBar pb;
    ImageView ivWarningProfileName, ivWarningProfileFamily, ivWarningProfileNcode;
    RelativeLayout rlChoosePermanentOrigin;
    String date;
    private PersianDatePickerDialog picker;
    CheckBox chkProfile;
    Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        context = this;

        bindView();
        //getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        edtNameProfile.setText(App.userInfo.getStrName());
        edtFamilyProfile.setText(App.userInfo.getStrFamily());
        edtNationalIDProfile.setText(App.userInfo.getNationalCode());

        viewLoaded(edtNameProfile, edtFamilyProfile, edtNationalIDProfile);

        if (App.userInfo.getStrChart() != null && !App.userInfo.getStrChart().equals(""))
            txtOrgPosition.setText(App.userInfo.getStrChart());
        else
            txtOrgPosition.setText("اختصاص نیافته");

        if (App.marker_existance) {
            chkProfile.setChecked(true);
            edtOptionalOrigin.setText(Cache.getString("selectedPositionName"));
        } else {
            chkProfile.setChecked(false);
            edtOptionalOrigin.setText("");
        }

        try {

            Picasso.get()
                    .load(App.userInfo.getImgLink())
                    .placeholder(R.drawable.ic_account3)// Place holder image from drawable folder
                    .error(R.drawable.ic_account3)
                    .memoryPolicy(MemoryPolicy.NO_CACHE, MemoryPolicy.NO_STORE)
                    .networkPolicy(NetworkPolicy.NO_CACHE)
                    .resize(110, 110)
                    .centerCrop()
                    .into(ivProfilePic);
        } catch (Exception ignored) {
        }

        tvProfilePic.setOnClickListener(v -> ChoosePicture());
        ivProfilePic.setOnClickListener(v -> ChoosePicture());
        txtMobileProfile.setText(Cache.getString("mobileNumber"));

        btn.setOnClickListener(v -> btnClicked());

        rlChoosePermanentOrigin.setOnClickListener(v -> rlChoosePermanentOriginPressed());
        txtSelectedPositionName.setOnClickListener(v -> rlChoosePermanentOriginPressed());


//        if(Cache.getLat("LAT" ,0)!=0 && Cache.getLat("LNG" ,0)!=0 ){
//            chkProfile.setChecked(true);
//        }else{
//            chkProfile.setChecked(false);
//        }

//        chkProfile.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
//            @Override
//            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
//                if(!isChecked){
//                    Cache.setLng("LNG",0);
//                    Cache.setLat("LAT",0);
//                }
//            }
//        });
    }

    private void btnClicked() {
        if (isValidNationalCode(edtNationalIDProfile.getText().toString()) && edtNationalIDProfile.getText().toString().length() == 10) {
            btnPressed(edtNameProfile.getText().toString(), edtFamilyProfile.getText().toString(),
                    edtNationalIDProfile.getText().toString(), edtOptionalOrigin.getText().toString()
                    , rbMan.isChecked(), bmProfile);
        } else {
            Toast.makeText(context, "کد ملی را صحیح وارد نمایید", Toast.LENGTH_SHORT).show();
        }
    }

    public boolean isValidNationalCode(String target) {
        Log.d(TAG, "isValidNationalCode: ");
        return Pattern.compile("(?=.*[0-9]).{4,12}").matcher(target).matches();

    }

    private void bindView() {
        toolbar = findViewById(R.id.toolbar_profile);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        setTitle("پروفایل");


        btn = findViewById(R.id.btnProfile);
        pb = findViewById(R.id.pbProfile);
        edtNameProfile = findViewById(R.id.edtNameProfile);
        edtFamilyProfile = findViewById(R.id.edtFamilyProfile);
        edtNationalIDProfile = findViewById(R.id.edtNationalIDProfile);
        rbMan = findViewById(R.id.rbMan);
        txtMobileProfile = findViewById(R.id.txtMobileProfile);
        ivProfilePic = findViewById(R.id.imgprofilename);
        tvProfilePic = findViewById(R.id.txtprofilepicture);
        ivWarningProfileName = findViewById(R.id.ivWarningProfileName);
        ivWarningProfileFamily = findViewById(R.id.ivWarningProfileFamily);
        ivWarningProfileNcode = findViewById(R.id.ivWarningProfileNcode);
        rlChoosePermanentOrigin = findViewById(R.id.rlChoosePermanentOrigin);
        txtSelectedPositionName = findViewById(R.id.txtSelectedPositionName);
        edtOptionalOrigin = findViewById(R.id.edtOptionalOrigin);
        chkProfile = findViewById(R.id.chkProfile);

        txtOrgPosition = findViewById(R.id.txtOrgPosition);
    }

    @Override
    public void onPickResult(PickResult r) {
        if (r.getError() == null) {
            Log.i(TAG, "onPickResult: " + r.getBitmap().toString());
            ivProfilePic.setImageBitmap(r.getBitmap());
            bmProfile = r.getBitmap();
        } else
            Toaster.shorter(r.getError().getMessage());
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_profile, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;

            case R.id.menuOption:
                openDialogDeleteCache();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void openDialogDeleteCache() {

        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setMessage("مطمین هستید که از برنامه می خواهید خارج شوید؟");
        builder.setPositiveButton("بله", (dialog, which) -> {
            Cache.setString("mobileNumber", "");

            exitApp();
        });
        builder.setNegativeButton("خیر", (dialog, which) -> {

        });
        builder.create().show();
    }

    public void hideProgressBar() {
        pb.setVisibility(View.GONE);
        btn.setVisibility(View.VISIBLE);
    }

    public void showProggressBar() {
        pb.setVisibility(View.VISIBLE);
        btn.setVisibility(View.GONE);
    }

    public void showNameError() {
        ivWarningProfileName.setVisibility(View.VISIBLE);
        Toaster.shorter("نام وارد شده صحیح نمی باشد");
    }

    public void showFamilyError() {
        ivWarningProfileFamily.setVisibility(View.VISIBLE);

//        if(Validate.lastName(edtFamilyProfile.getText().toString()))
//            ivWarningProfileFamily.setVisibility(View.GONE);
//        new Handler().postDelayed(new Runnable(){
//            public void run() {
//                ivWarningProfileFamily.setVisibility(View.GONE);
//            }
//        }, 5000);
        Toaster.shorter("نام خانوادگی وارد شده صحیح نمی باشد");
    }


    public void showNcodeError() {
        ivWarningProfileNcode.setVisibility(View.VISIBLE);
        Toaster.shorter("کد ملی وارد شده صحیح نمی باشد");
    }

    public void showImageErrorName() {
        ivWarningProfileName.setVisibility(View.VISIBLE);
    }

    public void hideImageErrorName() {
        ivWarningProfileName.setVisibility(View.GONE);
    }

    public void showImageErrorFamily() {
        ivWarningProfileFamily.setVisibility(View.VISIBLE);
    }

    public void hideImageErrorFamily() {
        ivWarningProfileFamily.setVisibility(View.GONE);
    }

    public void showImageErrorNcode() {
        ivWarningProfileNcode.setVisibility(View.VISIBLE);
    }

    public void hideImageErrorNcode() {
        ivWarningProfileNcode.setVisibility(View.GONE);
    }

    public void showDialogeToTurnOnGPS() {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
//        builder.setTitle("Turn On GPS");
        builder.setMessage("لطفا GPS را فعال نمایید");

        // add the buttons
        builder.setPositiveButton("فعالسازی", (dialog, which) -> {
            startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS));
            showGPSsetting();
        });
        builder.setNegativeButton("انصراف", (dialog, which) -> {
        });

        // create and show the alert dialog
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    public void showErrorEmpetyEdtPermanentAddress() {
        edtOptionalOrigin.setError("لطفا مبدا را تایپ کنید");
    }

    public void requestProfile(String name, String family, String nationalID, String permanentOriginAddress, boolean rbManchecked, Bitmap bmProfile) {

        App.register.setStrName(name);
        App.register.setStrFamily(family);
        App.register.setStrNationalCode(nationalID);
        App.register.setStrMobile(Cache.getString("mobileNumber"));

        if (App.marker_existance) {
            @SuppressLint("DefaultLocale")
            double lat = Double.parseDouble(String.format("%.5f", App.selectedPosition.latitude));
            @SuppressLint("DefaultLocale")
            double lon = Double.parseDouble(String.format("%.5f", App.selectedPosition.longitude));
            App.register.setLat(lat);
            App.register.setLon(lon);

//            Cache.setString("market_existence" , "marker_existenceValue");

        } else {
            App.register.setLat(0);
            App.register.setLon(0);
        }

        App.register.setImg(Converter.bitmapToString(bmProfile));
        App.register.setStrToken(Cache.getString("FirebaseToken"));


        if (rbManchecked) {
            App.register.setTiSex(1);
        } else {
            App.register.setTiSex(2);
        }

        Log.i("TAG", "requestProfile: " + Cache.getString("IP"));
        APIService apiService = APIClient.getClient().create(APIService.class);
        Call<Register> call = apiService.UpdateProfile(App.register, App.Session);
        call.enqueue(new Callback<Register>() {
            @Override
            public void onResponse(Call<Register> call, Response<Register> response) {
                Log.i("TAG", "onResponse: " + response.code());
                if (response.code() == 200) {
                    App.register = response.body();

                    updateProfileResulr(response.body().getResult());
                } else {
                    updateProfileResulr(-4);
                }
            }

            @Override
            public void onFailure(Call<Register> call, Throwable t) {
                updateProfileResulr(-5);
            }
        });

    }

    public boolean checkPermission() {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) !=
                PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions((Activity) context, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1234);
        } else {
//            Toast.makeText(context, "permission has granted", Toast.LENGTH_SHORT).show();
            return true;
        }
        return false;
    }

    public boolean checkGPSturnOn() {
        final LocationManager manager = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);
//        Location.displayLocationSettingsRequest(context, 121);
        if (!manager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
//           context.startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS));
        } else {
            return true;
        }
        return false;
    }

    public void saveLATLNG_AddreesName() {

//        // we should read data from server , dont need to use shareprefrence
//        //to show former marker on Map when user back to the map again
//        Cache.setLat("LAT" , (float) App.selectedPosition.latitude);
//        Cache.setLng("LNG" , (float) App.selectedPosition.longitude);

        // to show selected address on Map when user back to the map again
        Cache.setString("selectedPositionName", App.selectedPositionName);


    }

    //to refresh profile
    public void requestRefresh() {

        App.userInfo.setStrMobile(Cache.getString("mobileNumber"));
        APIService apiService = APIClient.getClient().create(APIService.class);
        Call<UserInfo> call = apiService.refresh(App.userInfo);
        call.enqueue(new Callback<UserInfo>() {
            @Override
            public void onResponse(Call<UserInfo> call, Response<UserInfo> response) {

                if (response.code() == 200 && response.body() != null) {
                    App.userInfo = response.body();
                    refreshResult(1);
                } else {
                    refreshResult(-4);
                }
            }

            @Override
            public void onFailure(Call<UserInfo> call, Throwable t) {
                refreshResult(-5);
            }
        });
    }

    //choose profile Pic
    public void ChoosePicture() {
        PickSetup setup = new PickSetup()
                .setTitle("تصوير جديد")
                .setProgressText("درحال ارسال...")
                .setSystemDialog(true);
        PickImageDialog.build(setup).show((FragmentActivity) context);
    }

    public void cvCalandarPressed(EditText edtDate) {
        final InputMethodManager imm = (InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.showSoftInput(edtDate, InputMethodManager.SHOW_IMPLICIT);


        picker = new PersianDatePickerDialog(context
        )
                .setPositiveButtonString("تایید")
                .setNegativeButton("انصراف")
                .setTodayButton("امروز")
                .setTodayButtonVisible(true)
                .setMinYear(1300)
                .setMaxYear(1450)
//                .setMaxYear(PersianDatePickerDialog.THIS_YEAR)
//                .setInitDate(initDate)
                .setActionTextColor(Color.GRAY)
//                .setTypeFace(typeface)
                .setListener(new Listener() {
                    @Override
                    public void onDateSelected(ir.hamsaa.persiandatepicker.util.PersianCalendar persianCalendar) {

//                             Toast.makeText(context
//                                , persianCalendar.getPersianYear() + "/"
//                                             + persianCalendar.getPersianMonth() + "/"
//                                             + persianCalendar.getPersianDay(), Toast.LENGTH_SHORT).show();
//
                        date = persianCalendar.getPersianYear() + "/"
                                + persianCalendar.getPersianMonth() + "/"
                                + persianCalendar.getPersianDay();
//                             Toast.makeText(context, date, Toast.LENGTH_SHORT).show();
                        edtDate.setText(date);
                    }

                    @Override
                    public void onDismissed() {
                    }
                });
        picker.show();
    }

    public void btnPressed(String name, String family, String nationalID
            , String PermanentOriginAddress, boolean rbManchecked, Bitmap bmProfile) {

        Log.i(TAG, "btnPressed: bmProfile " + bmProfile.toString());

        if (!Validate.firstName(name))
            showNameError();

        else if (!Validate.lastName(family))
            showFamilyError();
        else if (!CheckCode.isNationalCode(nationalID))
            showNcodeError();

            /*national Id is optional*/
//        else if (!Validate.nationalCode(nationalID))
//            view.showNcodeError();

//        else if(bmProfile == null)
//            Toaster.shorter("عکس پروفایل را انتخاب کنید");

        else if ((App.selectedPosition.latitude > 20 && App.selectedPosition.longitude > 20) && PermanentOriginAddress.length() == 0) {
            showErrorEmpetyEdtPermanentAddress();
        } else if ((App.selectedPosition.latitude < 20 && App.selectedPosition.longitude < 20) && !(PermanentOriginAddress.length() == 0)) {
            Toaster.shorter("لطفا مبدا را از روی نقشه مشخص کنید");
        } else {
            showProggressBar();
//            requestProfile(name, family, nationalID, PermanentOriginAddress, rbManchecked, bmProfile);
        }
    }

    public void updateProfileResulr(int result) {
        hideProgressBar();
        if (result == -4) {
            Toaster.shorter(context.getString(R.string.serverFaield));
        } else if (result == -5) {
            Toaster.shorter(context.getString(R.string.connectionFaield));
        } else if (result == 1) {
            requestRefresh();
            saveLATLNG_AddreesName();
        } else if (result == -1) {
            Toaster.shorter(context.getString(R.string.serverFaield));
        } else if (result == 100) {
            Intent intent = new Intent(ProfileActivity.this, LoginActivity.class);
            startActivity(intent);
        }
    }

    public void viewLoaded(EditText name, EditText family, EditText nCode) {

        name.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.toString().length() < 2)
                    showImageErrorName();
                else
                    hideImageErrorName();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        family.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.toString().length() < 2)
                    showImageErrorFamily();
                else
                    hideImageErrorFamily();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }

    public void rlChoosePermanentOriginPressed() {
        if (checkPermission()) {
//            if (model.checkGPSturnOn()) {
            context.startActivity(new Intent(context, MapsChooseOriginActivity.class));
//            } else {
////                view.showDialogeToTurnOnGPS();
        }
//        }
    }

    public void requestResult(int requestCode, String[] permissions, int[] grantResults) {
        switch (requestCode) {
            case 1234:
                if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {


                    context.startActivity(new Intent(context, MapsChooseOriginActivity.class));


//                    view.showDialogeToTurnOnGPS();
                }
            default:
//                super.onRequestPermissionsResult(requestCode,permissions,grantResults);
        }
    }

    public void refreshResult(int refreshResult) {
        if (refreshResult == -5) {
            Toaster.shorter(context.getString(R.string.connectionFaield));
        } else if (refreshResult == -4) {
            Toaster.shorter(context.getString(R.string.serverFaield));
        } else if (refreshResult == 1) {
            Toaster.shorter("پروفایل با موفقیت آپدیت شد");
            ((Activity) context).finish();
        }
    }

    public void showGPSsetting() {
        context.startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS));
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        requestResult(requestCode, permissions, grantResults);
    }

    @Override
    protected void onResume() {
        super.onResume();

        // permanentAddress must be saved is server then back to app to use here
        if (App.marker_existance) {

            if (App.selectedPositionName.length() != 0)
                edtOptionalOrigin.setText(App.selectedPositionName);
            else if (Cache.getString("selectedPositionName") != "")
                edtOptionalOrigin.setText(Cache.getString("selectedPositionName"));
            else
                edtOptionalOrigin.setText("");

        } else if (!App.marker_existance && Cache.getString("selectedPositionName").equals("")) {
            edtOptionalOrigin.setText("");
        } else if (!Cache.getString("selectedPositionName").equals("") && App.userInfo.getfLat() != 0 && App.userInfo.getfLon() != 0) {
            edtOptionalOrigin.setText(Cache.getString("selectedPositionName"));
        } else if (App.userInfo.getfLat() == 0 && App.userInfo.getfLon() == 0) {
            edtOptionalOrigin.setText("");
        }
//        if((App.userInfo.getfLat()!=0 && App.userInfo.getfLon()!=0) && App.marker_existance){
//            chkProfile.setChecked(true);
//        }else if((App.userInfo.getfLat() ==0 && App.userInfo.getfLon()==0) || !App.marker_existance){
//            chkProfile.setChecked(false);
//        }
//

        if (edtOptionalOrigin.length() > 0) {
            chkProfile.setChecked(true);
        } else {
            chkProfile.setChecked(false);
        }

    }

    private void exitApp() {
        MainActivity.exit = true;

        finish();

    }
}

