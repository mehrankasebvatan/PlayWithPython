package com.rayanandisheh.peysepar.passenger.view.Activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.ProgressBar;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.JointType;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polygon;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;
import com.rayanandisheh.peysepar.passenger.R;
import com.rayanandisheh.peysepar.passenger.helpers.App;
import com.rayanandisheh.peysepar.passenger.models.Car;
import com.rayanandisheh.peysepar.passenger.services.APIClient;
import com.rayanandisheh.peysepar.passenger.services.APIService;
import com.rayanandisheh.peysepar.passenger.utils.MyClass;

import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ActivityMap extends AppCompatActivity implements OnMapReadyCallback,
        GoogleMap.OnPolylineClickListener, GoogleMap.OnPolygonClickListener {

    private static final String TAG = "ActivityMap";
    MyClass MYC = new MyClass();
    Context context;
    GoogleMap mMap;
    Timer timer = new Timer();
    private ProgressBar progressBar;
    private SupportMapFragment mapFragmen;
    private int iOfficialTrip;
    private List<Car> listCar = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Retrieve the content view that renders the map.
        setContentView(R.layout.activity_map);
        this.context = ActivityMap.this;

        progressBar = findViewById(R.id.progressBar);
        //getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        Bundle bundle = getIntent().getExtras();
        iOfficialTrip = bundle.getInt("iOfficialTrip");

        // Get the SupportMapFragment and request notification when the map is ready to be used.
        mapFragmen = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
//        if (App.listCar == null || App.listCar.size() < 2) {
//            MYC.ToastM(context, "اشکال در اطلاعات دریافتی");
//            return;
//        }

//        mMap.animateCamera(CameraUpdateFactory.newCameraPosition(
//                new CameraPosition(new LatLng(32.7827964, 52.9383403), 12,
//                        mMap.getCameraPosition().tilt, //use old tilt
//                        mMap.getCameraPosition().bearing)), 1500, null);

        googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(32.4207423, 53.6830157), 5));

        getRoutingCar();

        googleMap.setOnPolylineClickListener(this);
        googleMap.setOnPolygonClickListener(this);
    }

    private void getRoutingCar() {
        APIService apiService = APIClient.getClient().create(APIService.class);
        Call<List<Car>> call = apiService.GetTripPath(iOfficialTrip);
        call.enqueue(new Callback<List<Car>>() {
            @Override
            public void onResponse(@NonNull Call<List<Car>> call, @NonNull Response<List<Car>> response) {
                progressBar.setVisibility(View.GONE);
                if (response.code() == 200) {
                    if (response.body() != null && !response.body().isEmpty()) {
                        listCar = response.body();
                        drawRouting(mMap, listCar);
                        timer.schedule(new secondTask(), 500, 500);
                    } else {
                        MyClass.ToastM(context, "موردی یافت نشد");
                    }
                } else {
                    MyClass.ToastM(context, "خطا در برقراری ارتباط");
                }
            }

            @Override
            public void onFailure(@NonNull Call<List<Car>> call, @NonNull Throwable t) {
                MyClass.ToastM(context, "خطا در برقراری ارتباط");
                progressBar.setVisibility(View.GONE);
            }
        });
    }

    private void drawRouting(GoogleMap googleMap, List<Car> listCar) {
        PolylineOptions polylineOptions = new PolylineOptions();
        polylineOptions.clickable(true);
        double flat = 0d;
        double flon = 0d;

        for (int i = 0; i < listCar.size(); i++) {
            if (flat != listCar.get(i).getfLat() && flon != listCar.get(i).getfLon()) {
                flat = listCar.get(i).getfLat();
                flon = listCar.get(i).getfLon();
                polylineOptions.add(new LatLng(flat, flon));
            }
        }

        Polyline polyline = googleMap.addPolyline(polylineOptions);
        stylePolyline(polyline);
    }

    @Override
    protected void onResume() {
        super.onResume();
        mapFragmen.getMapAsync(this);
    }

    class secondTask extends TimerTask {
        @Override
        public void run() {
            runOnUiThread(() -> {
                fitZoomAllMarker(listCar);
                timer.cancel();
            });
        }
    }

    private void stylePolyline(Polyline polyline) {
//        Bitmap icon = BitmapFactory.decodeResource(context.getResources(), R.drawable.ic_origin);
//        Bitmap icon1 = BitmapFactory.decodeResource(context.getResources(), R.drawable.destination);

        if (polyline.getPoints().size() != 0) {
            int last = polyline.getPoints().size() - 1;

            mMap.addMarker(new MarkerOptions()
                    .position(new LatLng(polyline.getPoints().get(0).latitude, polyline.getPoints().get(0).longitude))
                    .icon(BitmapDescriptorFactory.fromBitmap(MyClass.getResizedBitmap(
                            MyClass.getBitmapFromVectorDrawable(context, R.drawable.ic_origin)
                            , 144, 114))).rotation(0));
//                    .icon(BitmapDescriptorFactory.fromBitmap(getBitmap(context, R.drawable.origin))).rotation(0));

            mMap.addMarker(new MarkerOptions()
                    .position(new LatLng(polyline.getPoints().get(last).latitude, polyline.getPoints().get(last).longitude))
                    .icon(BitmapDescriptorFactory.fromBitmap(MyClass.getResizedBitmap(
                            MyClass.getBitmapFromVectorDrawable(context, R.drawable.ic_destination)
                            , 144, 114))).rotation(0));
//                    .icon(BitmapDescriptorFactory.fromBitmap(getBitmap(context, R.drawable.destination))).rotation(0));
        }

//        polyline.setStartCap(new CustomCap(bitmapDescriptorFromVector(context, R.drawable.ic_origin), 45));
//        polyline.setEndCap(new CustomCap(bitmapDescriptorFromVector(context, R.drawable.ic_destination), 45));

        polyline.setWidth(12);
        polyline.setGeodesic(true);
        polyline.setColor(context.getResources().getColor(R.color.color_polyline));
        polyline.setJointType(JointType.DEFAULT);
    }

    @Override
    public void onPolylineClick(Polyline polyline) {
      /*  // Flip from solid stroke to dotted stroke pattern.
        if ((polyline.getPattern() == null) || (!polyline.getPattern().contains(DOT))) {
            polyline.setPattern(PATTERN_POLYLINE_DOTTED);
        } else {
            // The default pattern is a solid stroke.
            polyline.setPattern(null);
        }

        Toast.makeText(this, "Route type " + polyline.getTag().toString(),
                Toast.LENGTH_SHORT).show();*/
    }

    @Override
    public void onPolygonClick(Polygon polygon) {
       /* // Flip the values of the red, green, and blue components of the polygon's color.
        int color = polygon.getStrokeColor() ^ 0x00ffffff;
        polygon.setStrokeColor(color);
        color = polygon.getFillColor() ^ 0x00ffffff;
        polygon.setFillColor(color);

        Toast.makeText(this, "Area type " + polygon.getTag().toString(), Toast.LENGTH_SHORT).show();*/
    }

    private void fitZoomAllMarker(List<Car> markers) {
        try {
            LatLngBounds.Builder builder = new LatLngBounds.Builder();
            for (int i = 0; i < markers.size(); i++) {
                builder.include(new LatLng(markers.get(i).getfLat(), markers.get(i).getfLon()));
            }

            LatLngBounds latLngBounds = builder.build();
            CameraUpdate cu = CameraUpdateFactory.newLatLngBounds(latLngBounds, 150);
            mMap.animateCamera(cu);
        } catch (Exception ignored) {
        }
    }

    @Override
    public void onBackPressed() {
        finish();
    }

}