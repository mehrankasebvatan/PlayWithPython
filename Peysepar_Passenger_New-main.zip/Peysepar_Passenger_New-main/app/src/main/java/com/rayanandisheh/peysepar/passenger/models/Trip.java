package com.rayanandisheh.peysepar.passenger.models;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;

public class Trip implements Parcelable {

    @SerializedName("strTripName")
    private String strTripName;
    @SerializedName("strTripDate")
    private String strTripDate;
    @SerializedName("strTripTime")
    private String strTripTime;
    @SerializedName("strDriverName")
    private String strDriverName;
    @SerializedName("iSatisfication")
    private float iSatisfication;
    @SerializedName("strMobileType")
    private String strMobileType;
    @SerializedName("strDestinationAddress")
    private String strDestinationAddress;
    @SerializedName("strDestinationName")
    private String strDestinationName;
    @SerializedName("strOriginAddress")
    private String strOriginAddress;
    @SerializedName("strOriginName")
    private String strOriginName;
    @SerializedName("strFileAddress")
    private String strFileAddress;
    @SerializedName("strPassengers")
    private String strPassengers;
    @SerializedName("iOfficialTrip")
    private int iOfficialTrip;
    @SerializedName("strOfficialStatus_strComment")
    private String strOfficialStatus_strComment;
    @SerializedName("tiTripStatus")
    private int tiTripStatus;
    @SerializedName("strFinishDate")
    private String strFinishDate;
    @SerializedName("strComment")
    private String strComment;
    @SerializedName("strEstRedy4TrimpTime")
    private String strEstRedy4TrimpTime;
    @SerializedName("strRedy4TrimpTime")
    private String strRedy4TrimpTime;
    @SerializedName("strTrimpFinishTime")
    private String strTrimpFinishTime;
    @SerializedName("strTrimTimeEstimate")
    private String strTrimTimeEstimate;
    @SerializedName("strVehicleNo")
    private String strVehicleNo;
    @SerializedName("bExclusive")
    private boolean bExclusive;
    @SerializedName("bHaveReturn")
    private boolean bHaveReturn;
    @SerializedName("bMission")
    private boolean bMission ;
    @SerializedName("Result")
    private int Result ;
    @SerializedName("message")
    private String message ;

    @SerializedName("strColor")
    private String strColor ;
    @SerializedName("PassengerSig")
    private String PassengerSig;
    @SerializedName("strTripReason_strComment")
    private String strTripReason_strComment;
    @SerializedName("strTripImportance_strComment")
    private String strTripImportance_strComment;
    @SerializedName("strRequestTime")
    private String strRequestTime;
    @SerializedName("strRequestDate")
    private String strRequestDate;
    @SerializedName("strApplicantName")
    private String strApplicantName;
    @SerializedName("strApplicantFamily")
    private String strApplicantFamily;
    @SerializedName("strApplicantMobile")
    private String strApplicantMobile;
    @SerializedName("strUnitID")
    private String strUnitID;
    @SerializedName("DriverMobile")
    private String DriverMobile;
    @SerializedName("fLonSource")
    public String fLonSource;
    @SerializedName("fLatSource")
    public String fLatSource;
    @SerializedName("fLonDestination")
    public String fLonDestination;
    @SerializedName("fLatDestination")
    public String fLatDestination;
    @SerializedName("strChartName")
    public String strChartName;
    @SerializedName("strGPSType_strComment")
    public String strGPSType_strComment;
    @SerializedName("ImageDriver")
    private String ImageDriver;

    @SerializedName("fTripKm")
    private float fTripKm;

    public String getImageDriver() {
        return ImageDriver;
    }

    public void setImageDriver(String imageDriver) {
        ImageDriver = imageDriver;
    }

    public static Creator<Trip> getCREATOR() {
        return CREATOR;
    }

    public String getStrGPSType_strComment() {
        return strGPSType_strComment;
    }

    public void setStrGPSType_strComment(String strGPSType_strComment) {
        this.strGPSType_strComment = strGPSType_strComment;
    }

    public String getStrChartName() {
        return strChartName;
    }

    public void setStrChartName(String strChartName) {
        this.strChartName = strChartName;
    }

    public boolean isbMission() {
        return bMission;
    }

    public void setbMission(boolean bMission) {
        this.bMission = bMission;
    }

    public int getResult() {
        return Result;
    }

    public void setResult(int result) {
        Result = result;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public boolean isbExclusive() {
        return bExclusive;
    }

    public void setbExclusive(boolean bExclusive) {
        this.bExclusive = bExclusive;
    }

    public boolean isbHaveReturn() {
        return bHaveReturn;
    }

    public void setbHaveReturn(boolean bHaveReturn) {
        this.bHaveReturn = bHaveReturn;
    }

    public String getStrUnitIdDriver() {
        return strUnitID;
    }

    public void setStrUnitIdDriver(String strUnitId) {
        this.strUnitID = strUnitId;
    }

    public String getStrEstRedy4TrimpTime() {
        return strEstRedy4TrimpTime;
    }

    public void setStrEstRedy4TrimpTime(String strEstRedy4TrimpTime) {
        this.strEstRedy4TrimpTime = strEstRedy4TrimpTime;
    }

    public String getStrRedy4TrimpTime() {
        return strRedy4TrimpTime;
    }

    public void setStrRedy4TrimpTime(String strRedy4TrimpTime) {
        this.strRedy4TrimpTime = strRedy4TrimpTime;
    }

    public String getStrTrimpFinishTime() {
        return strTrimpFinishTime;
    }

    public void setStrTrimpFinishTime(String strTrimpFinishTime) {
        this.strTrimpFinishTime = strTrimpFinishTime;
    }

    public String getStrTrimTimeEstimate() {
        return strTrimTimeEstimate;
    }

    public void setStrTrimTimeEstimate(String strTrimTimeEstimate) {
        this.strTrimTimeEstimate = strTrimTimeEstimate;
    }

    public String getStrVehicleNo() {
        return strVehicleNo;
    }

    public void setStrVehicleNo(String strVehicleNo) {
        this.strVehicleNo = strVehicleNo;
    }

    public String getStrComment() {
        return strComment;
    }

    public void setStrComment(String strComment) {
        this.strComment = strComment;
    }

    public String getStrFinishDate() {
        return strFinishDate;
    }

    public void setStrFinishDate(String strFinishDate) {
        this.strFinishDate = strFinishDate;
    }


    public String getfLonSource() {
        return fLonSource;
    }

    public void setfLonSource(String fLonSource) {
        this.fLonSource = fLonSource;
    }

    public String getfLatSource() {
        return fLatSource;
    }

    public void setfLatSource(String fLatSource) {
        this.fLatSource = fLatSource;
    }

    public String getfLonDestination() {
        return fLonDestination;
    }

    public void setfLonDestination(String fLonDestination) {
        this.fLonDestination = fLonDestination;
    }

    public String getfLatDestination() {
        return fLatDestination;
    }

    public void setfLatDestination(String fLatDestination) {
        this.fLatDestination = fLatDestination;
    }

    public String getPassengerSig() {
        return PassengerSig;
    }

    public void setPassengerSig(String passengerSig) {
        PassengerSig = passengerSig;
    }

    public String getStrTripReason_strComment() {
        return strTripReason_strComment;
    }

    public void setStrTripReason_strComment(String strTripReason_strComment) {
        this.strTripReason_strComment = strTripReason_strComment;
    }

    public String getStrTripImportance_strComment() {
        return strTripImportance_strComment;
    }

    public void setStrTripImportance_strComment(String strTripImportance_strComment) {
        this.strTripImportance_strComment = strTripImportance_strComment;
    }
    public String getStrColor() {
        return strColor;
    }

    public void setStrColor(String strColor) {
        this.strColor = strColor;
    }
    public String getStrRequestTime() {
        return strRequestTime;
    }

    public void setStrRequestTime(String strRequestTime) {
        this.strRequestTime = strRequestTime;
    }

    public String getStrRequestDate() {
        return strRequestDate;
    }

    public void setStrRequestDate(String strRequestDate) {
        this.strRequestDate = strRequestDate;
    }

    public String getStrApplicantName() {
        return strApplicantName;
    }

    public void setStrApplicantName(String strApplicantName) {
        this.strApplicantName = strApplicantName;
    }

    public String getStrApplicantFamily() {
        return strApplicantFamily;
    }

    public void setStrApplicantFamily(String strApplicantFamily) {
        this.strApplicantFamily = strApplicantFamily;
    }

    public String getStrApplicantMobile() {
        return strApplicantMobile;
    }

    public void setStrApplicantMobile(String strApplicantMobile) {
        this.strApplicantMobile = strApplicantMobile;
    }

    public String getDriverMobile() {
        return DriverMobile;
    }

    public void setDriverMobile(String driverMobile) {
        DriverMobile = driverMobile;
    }

    public int getTiTripStatus() {
        return tiTripStatus;
    }

    public void setTiTripStatus(int tiTripStatus) {
        this.tiTripStatus = tiTripStatus;
    }

    public String getStrOfficialStatus_strComment() {
        return strOfficialStatus_strComment;
    }

    public void setStrOfficialStatus_strComment(String strOfficialStatus_strComment) {
        this.strOfficialStatus_strComment = strOfficialStatus_strComment;
    }

    public int getiOfficialTrip() {
        return iOfficialTrip;
    }

    public void setiOfficialTrip(int iOfficialTrip) {
        this.iOfficialTrip = iOfficialTrip;
    }

    public String getStrTripName() {
        return strTripName;
    }

    public void setStrTripName(String strTripName) {
        this.strTripName = strTripName;
    }

    public String getStrTripDate() {
        return strTripDate;
    }

    public void setStrTripDate(String strTripDate) {
        this.strTripDate = strTripDate;
    }

    public String getStrTripTime() {
        return strTripTime;
    }

    public void setStrTripTime(String strTripTime) {
        this.strTripTime = strTripTime;
    }

    public String getStrDriverName() {
        return strDriverName;
    }

    public void setStrDriverName(String strDriverName) {
        this.strDriverName = strDriverName;
    }

    public float getiSatisfication() {
        return iSatisfication;
    }

    public void setiSatisfication(float iSatisfication) {
        this.iSatisfication = iSatisfication;
    }

    public String getStrMobileType() {
        return strMobileType;
    }

    public void setStrMobileType(String strMobileType) {
        this.strMobileType = strMobileType;
    }

    public String getStrDestinationAddress() {
        return strDestinationAddress;
    }

    public void setStrDestinationAddress(String strDestinationAddress) {
        this.strDestinationAddress = strDestinationAddress;
    }

    public String getStrDestinationName() {
        return strDestinationName;
    }

    public void setStrDestinationName(String strDestinationName) {
        this.strDestinationName = strDestinationName;
    }

    public String getStrOriginAddress() {
        return strOriginAddress;
    }

    public void setStrOriginAddress(String strOriginAddress) {
        this.strOriginAddress = strOriginAddress;
    }

    public String getStrOriginName() {
        return strOriginName;
    }

    public void setStrOriginName(String strOriginName) {
        this.strOriginName = strOriginName;
    }

    public String getStrFileAddress() {
        return strFileAddress;
    }

    public void setStrFileAddress(String strFileAddress) {
        this.strFileAddress = strFileAddress;
    }

    public String getStrPassengers() {
        return strPassengers;
    }

    public void setStrPassengers(String strPassengers) {
        this.strPassengers = strPassengers;
    }

    public String getStrUnitID() {
        return strUnitID;
    }

    public void setStrUnitID(String strUnitID) {
        this.strUnitID = strUnitID;
    }

    public float getfTripKm() {
        return fTripKm;
    }

    public void setfTripKm(float fTripKm) {
        this.fTripKm = fTripKm;
    }

    public Trip() {
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.strTripName);
        dest.writeString(this.strTripDate);
        dest.writeString(this.strTripTime);
        dest.writeString(this.strDriverName);
        dest.writeFloat(this.iSatisfication);
        dest.writeString(this.strMobileType);
        dest.writeString(this.strDestinationAddress);
        dest.writeString(this.strDestinationName);
        dest.writeString(this.strOriginAddress);
        dest.writeString(this.strOriginName);
        dest.writeString(this.strFileAddress);
        dest.writeString(this.strPassengers);
        dest.writeInt(this.iOfficialTrip);
        dest.writeString(this.strOfficialStatus_strComment);
        dest.writeInt(this.tiTripStatus);
        dest.writeString(this.strFinishDate);
        dest.writeString(this.strComment);
        dest.writeString(this.strEstRedy4TrimpTime);
        dest.writeString(this.strRedy4TrimpTime);
        dest.writeString(this.strTrimpFinishTime);
        dest.writeString(this.strTrimTimeEstimate);
        dest.writeString(this.strVehicleNo);
        dest.writeByte(this.bExclusive ? (byte) 1 : (byte) 0);
        dest.writeByte(this.bHaveReturn ? (byte) 1 : (byte) 0);
        dest.writeByte(this.bMission ? (byte) 1 : (byte) 0);
        dest.writeInt(this.Result);
        dest.writeString(this.message);
        dest.writeString(this.PassengerSig);
        dest.writeString(this.strTripReason_strComment);
        dest.writeString(this.strTripImportance_strComment);
        dest.writeString(this.strRequestTime);
        dest.writeString(this.strRequestDate);
        dest.writeString(this.strApplicantName);
        dest.writeString(this.strApplicantFamily);
        dest.writeString(this.strApplicantMobile);
        dest.writeString(this.strUnitID);
        dest.writeString(this.DriverMobile);
        dest.writeString(this.fLonSource);
        dest.writeString(this.fLatSource);
        dest.writeString(this.fLonDestination);
        dest.writeString(this.fLatDestination);
        dest.writeString(this.strChartName);
        dest.writeString(this.strGPSType_strComment);
    }

    protected Trip(Parcel in) {
        this.strTripName = in.readString();
        this.strTripDate = in.readString();
        this.strTripTime = in.readString();
        this.strDriverName = in.readString();
        this.iSatisfication = in.readFloat();
        this.strMobileType = in.readString();
        this.strDestinationAddress = in.readString();
        this.strDestinationName = in.readString();
        this.strOriginAddress = in.readString();
        this.strOriginName = in.readString();
        this.strFileAddress = in.readString();
        this.strPassengers = in.readString();
        this.iOfficialTrip = in.readInt();
        this.strOfficialStatus_strComment = in.readString();
        this.tiTripStatus = in.readInt();
        this.strFinishDate = in.readString();
        this.strComment = in.readString();
        this.strEstRedy4TrimpTime = in.readString();
        this.strRedy4TrimpTime = in.readString();
        this.strTrimpFinishTime = in.readString();
        this.strTrimTimeEstimate = in.readString();
        this.strVehicleNo = in.readString();
        this.bExclusive = in.readByte() != 0;
        this.bHaveReturn = in.readByte() != 0;
        this.bMission = in.readByte() != 0;
        this.Result = in.readInt();
        this.message = in.readString();
        this.PassengerSig = in.readString();
        this.strTripReason_strComment = in.readString();
        this.strTripImportance_strComment = in.readString();
        this.strRequestTime = in.readString();
        this.strRequestDate = in.readString();
        this.strApplicantName = in.readString();
        this.strApplicantFamily = in.readString();
        this.strApplicantMobile = in.readString();
        this.strUnitID = in.readString();
        this.DriverMobile = in.readString();
        this.fLonSource = in.readString();
        this.fLatSource = in.readString();
        this.fLonDestination = in.readString();
        this.fLatDestination = in.readString();
        this.strChartName = in.readString();
        this.strGPSType_strComment = in.readString();
    }

    public static final Creator<Trip> CREATOR = new Creator<Trip>() {
        @Override
        public Trip createFromParcel(Parcel source) {
            return new Trip(source);
        }

        @Override
        public Trip[] newArray(int size) {
            return new Trip[size];
        }
    };
}
