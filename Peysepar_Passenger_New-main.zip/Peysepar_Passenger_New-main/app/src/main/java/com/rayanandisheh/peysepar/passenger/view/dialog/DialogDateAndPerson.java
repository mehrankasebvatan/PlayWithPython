package com.rayanandisheh.peysepar.passenger.view.dialog;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

import com.mohamadamin.persianmaterialdatetimepicker.date.DatePickerDialog;
import com.rayanandisheh.peysepar.passenger.R;
import com.rayanandisheh.peysepar.passenger.helpers.Time;

import ir.hamsaa.persiandatepicker.util.PersianCalendar;
import saman.zamani.persiandate.PersianDate;
import saman.zamani.persiandate.PersianDateFormat;

public class DialogDateAndPerson extends DialogFragment implements View.OnClickListener {
    private static final String TAG = "DialogDateAndPerson";
    private View view;
    private final String title;
    private EditText et_PersonName, et_DateFrom_history, et_DateTo_history;
    private final OnClickDialogFinalOrderRegister onClickDialogFinalOrderRegister;
    private String date = "";

    public interface OnClickDialogFinalOrderRegister {
        void onClick(String dateFrom, String dateTo, String personName);
    }

    public DialogDateAndPerson(String title, OnClickDialogFinalOrderRegister onClickDialogFinalOrderRegister) {
        this.title = title;
        this.onClickDialogFinalOrderRegister = onClickDialogFinalOrderRegister;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container
            , @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.dialog_date_person, container, false);
        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        setCancelable(true);
        getViews();
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
    }

    public void onResume() {
        // Store access variables for window and blank point
        getDialog().getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        getDialog().getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        getDialog().getWindow().getAttributes().windowAnimations = R.style.DialogAnimation;

        Window window = getDialog().getWindow();
        WindowManager.LayoutParams wlp = window.getAttributes();
        wlp.gravity = Gravity.BOTTOM;
        wlp.flags = WindowManager.LayoutParams.FLAG_DIM_BEHIND;
        window.setAttributes(wlp);
        super.onResume();
    }

    @SuppressLint("ClickableViewAccessibility")
    private void getViews() {
        Button btn_dialog_sumbit = view.findViewById(R.id.btn_dialog_sumbit);
        Button btn_dialog_cancel = view.findViewById(R.id.btn_dialog_cancel);
        TextView tv_dialog = view.findViewById(R.id.tv_dialog);
        et_DateFrom_history = view.findViewById(R.id.et_DateFrom_history);
        et_DateTo_history = view.findViewById(R.id.et_DateTo_history);
        et_PersonName = view.findViewById(R.id.et_PersonName);

        tv_dialog.setText(title);
        et_DateFrom_history.setText(getNowPersianDate());
        et_DateTo_history.setText(getNowPersianDate());

        et_DateFrom_history.setOnClickListener(this);
        et_DateTo_history.setOnClickListener(this);
        btn_dialog_sumbit.setOnClickListener(this);
        btn_dialog_cancel.setOnClickListener(this);
    }

    public static String getNowPersianDate() {
        PersianDate pDate = new PersianDate();
        new PersianDateFormat("yyyy/mm/dd").format(pDate);
        return (String.valueOf(pDate.getShYear()).length() < 2 ? "0" + pDate.getShYear() : String.valueOf(pDate.getShYear())) + "/" +
                (String.valueOf(pDate.getShMonth()).length() < 2 ? "0" + pDate.getShMonth() : String.valueOf(pDate.getShMonth())) + "/" +
                (String.valueOf(pDate.getShDay()).length() < 2 ? "0" + pDate.getShDay() : String.valueOf(pDate.getShDay()));

    }

    private void calendar(boolean isFrom) {
        PersianCalendar persianCalendar = new PersianCalendar();
        @SuppressLint("SetTextI18n") DatePickerDialog datePickerDialog = DatePickerDialog.newInstance(
                (view, year, monthOfYear, dayOfMonth) -> {

                    if ((monthOfYear + 1) < 10 && dayOfMonth < 10) {
                        date = year + "/0" + (monthOfYear + 1) + "/0" + dayOfMonth;
                    } else if ((monthOfYear + 1) < 10) {
                        date = year + "/0" + (monthOfYear + 1) + "/" + dayOfMonth;
                    } else if (dayOfMonth < 10) {
                        date = year + "/" + (monthOfYear + 1) + "/0" + dayOfMonth;
                    } else {
                        date = year + "/" + (monthOfYear + 1) + "/" + dayOfMonth;
                    }

                    if (isFrom)
                        et_DateFrom_history.setText(date);
                    else
                        et_DateTo_history.setText(date);

                },
                persianCalendar.getPersianYear(),
                persianCalendar.getPersianMonth() - 1,
                persianCalendar.getPersianDay()
        );
        datePickerDialog.show(requireActivity().getFragmentManager(), "Datepickerdialog");
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.et_DateFrom_history) {
            calendar(true);
        }
        if (v.getId() == R.id.et_DateTo_history) {
            calendar(false);
        }
        if (v.getId() == R.id.btn_dialog_sumbit) {
            String dateFrom = et_DateFrom_history.getText().toString().trim();
            String dateTo = et_DateTo_history.getText().toString().trim();
            String person = et_PersonName.getText().toString().trim();
            if (dateFrom.isEmpty()) {
                et_DateFrom_history.setError("بازه شروع تاریخ مد نظر را مشخص کنید");
                et_DateFrom_history.requestFocus();
            } else if (dateTo.isEmpty()) {
                et_DateTo_history.setError("بازه پایانی تاریخ مورد نظر را مشخص کنید");
                et_DateTo_history.requestFocus();
            } else {
                onClickDialogFinalOrderRegister.onClick(dateFrom, dateTo, person);
                dismiss();
            }
        }
        if (v.getId() == R.id.btn_dialog_cancel) {
            dismiss();
        }
    }
}

