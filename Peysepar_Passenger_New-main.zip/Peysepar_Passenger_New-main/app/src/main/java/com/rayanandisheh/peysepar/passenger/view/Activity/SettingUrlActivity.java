package com.rayanandisheh.peysepar.passenger.view.Activity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.text.Html;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.ContextCompat;

import com.rayanandisheh.peysepar.passenger.R;
import com.rayanandisheh.peysepar.passenger.helpers.App;
import com.rayanandisheh.peysepar.passenger.helpers.Cache;
import com.rayanandisheh.peysepar.passenger.helpers.PersianAppcompatActivity;
import com.rayanandisheh.peysepar.passenger.helpers.Toaster;
import com.rayanandisheh.peysepar.passenger.helpers.Validate;
import com.rayanandisheh.peysepar.passenger.services.APIClient;
import com.rayanandisheh.peysepar.passenger.services.APIService;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SettingUrlActivity extends PersianAppcompatActivity {
    Context context;
    private static final String TAG = "SettingActivity";
    EditText etIP;
    TextView tv_ChecklIpValidate;
    Button btRegisterIP, btn_checkAddress;
    ProgressBar pbCheckAddress;
    boolean doubleBackToExitPressedOnce = false;

    @SuppressLint("NewApi")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);
        context = this;
        bindViews();
        String text = "<font color='" + ContextCompat.getColor(App.context, R.color.colorPrimaryText) +
                "'>" + getResources().getString(R.string.checkIp) + "</font>" +
                "<font color='" + ContextCompat.getColor(App.context, R.color.colorAccent) +
                "'>" + " ' " + getResources().getString(R.string.checkIp3) + " ' " + "</font>" +
                "<font color='" + ContextCompat.getColor(App.context, R.color.colorPrimaryText) +
                "'>" + getResources().getString(R.string.checkIp2) + "</font>";

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            tv_ChecklIpValidate.setText(Html.fromHtml(text, Html.FROM_HTML_MODE_LEGACY), TextView.BufferType.SPANNABLE);
        } else {
            tv_ChecklIpValidate.setText(Html.fromHtml(text), TextView.BufferType.SPANNABLE);
        }

        /*btn_checkAddress.setOnClickListener(v -> {
            APIClient.retrofit = null;
            App.ServerURL = etIP.getText().toString();

            btnCheckaddressPressed(etIP.getText().toString());
            //            http://passenger.peysepar.com
        });*/

//        etIP.setText("http://192.168.1.109:1000");

//        etIP.setText(R.string.IPaddress);

        btRegisterIP.setOnClickListener(v -> {

            APIClient.retrofit = null;
            App.ServerURL = etIP.getText().toString();

            if (Validate.url(App.ServerURL)) {
                Cache.setString("IP", App.ServerURL);
                //clause to solve problem of jumping in splash
                if (App.ServerURL != null) {
                    btnCheckaddressPressed(etIP.getText().toString());
                } else {
                    Toaster.shorter("ServerUrl null");
                    finish();
                }
            } else {
                etIP.setError("آدرس را با توجه به مثال زده شده وارد نمایید");
//                    etIP.setError("آدرس خود را وارد نمایید");
            }
        });
    }

    private void bindViews() {
        etIP = findViewById(R.id.etIP);
        btRegisterIP = findViewById(R.id.btRegisterIP);
        pbCheckAddress = findViewById(R.id.pbCheckAddress);
        // btn_checkAddress = findViewById(R.id.btnCheckAddress);
        tv_ChecklIpValidate = findViewById(R.id.tv_txtAttention);
    }

    @Override
    public void onBackPressed() {
        if (doubleBackToExitPressedOnce) {
            super.onBackPressed();
            exitApp();
            return;
        }

        this.doubleBackToExitPressedOnce = true;
        Toast.makeText(this, "برای خروج مجددا دکمه ی بازگشت را بزنید", Toast.LENGTH_SHORT).show();
        new Handler().postDelayed(() -> doubleBackToExitPressedOnce = false, 3000);
    }

    private void exitApp() {
        finish();
        startActivity(new Intent(Intent.ACTION_MAIN).
                addCategory(Intent.CATEGORY_HOME).
                setFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        android.os.Process.killProcess(android.os.Process.myPid());
        super.finish();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (Cache.getString("IP").equals(""))
//        etIP.setText(R.string.IPaddress);
            etIP.setText(R.string.IPaddress);
        else
            etIP.setText(Cache.getString("IP"));
    }

    public void showProgressBar() {
        pbCheckAddress.setVisibility(View.VISIBLE);
        btRegisterIP.setVisibility(View.GONE);
    }

    public void hideProgressBar() {
        pbCheckAddress.setVisibility(View.GONE);
        btRegisterIP.setVisibility(View.VISIBLE);
    }

    public void btnCheckaddressPressed(String etIP) {

        showProgressBar();
        checkAddressRequest(etIP);
    }

    public void checkAddressResult(Integer checkAddresessResult) {
        hideProgressBar();
        if (checkAddresessResult == 1) {
            Toaster.shorter("آدرس اینترنتی وارد شده صحیح می باشد");
            startActivity(new Intent(SettingUrlActivity.this, SplashActivity.class));
        }else if (checkAddresessResult == 0) {
            Toaster.shorter("آدرس اینترنتی وارد شده صحیح نمی باشد");
        } else if (checkAddresessResult == -5) {
            Toaster.shorter(context.getString(R.string.connectionFaield));
        } else if (checkAddresessResult == -4) {
            Toaster.shorter(context.getString(R.string.serverFaield));
        }
    }

    public void checkAddressRequest(String etIP) {
        App.userInfo.setUrl(etIP);
        Cache.setString("IP", etIP);
        APIService apiService = APIClient.getClient().create(APIService.class);
        Call<Integer> call = apiService.checkWebServiceAddress();
        call.enqueue(new Callback<Integer>() {
            @Override
            public void onResponse(Call<Integer> call, Response<Integer> response) {
                if (response.code() == 200) {
                    Log.d(TAG, "onResponse: " + response.body());
                    checkAddressResult(response.body());
                } else {
                    checkAddressResult(-4);
                }
            }

            @Override
            public void onFailure(Call<Integer> call, Throwable t) {
                checkAddressResult(-5);
            }
        });
    }
}
