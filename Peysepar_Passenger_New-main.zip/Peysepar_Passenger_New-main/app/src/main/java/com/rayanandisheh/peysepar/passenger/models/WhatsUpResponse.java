package com.rayanandisheh.peysepar.passenger.models;

import com.google.gson.annotations.SerializedName;

public class WhatsUpResponse {

    @SerializedName("strCaption")
    String strCaption;

    @SerializedName("strComment")
    String strComment;

    @SerializedName("strURL")
    String strURL;

    @SerializedName("iResult")
    int iResult;

    @SerializedName("strGooglePlayURL")
    String strGooglePlayURL;

    @SerializedName("strCafebazarURL")
    String strCafebazarURL;

    public String getStrCaption() {
        return strCaption;
    }

    public void setStrCaption(String strCaption) {
        this.strCaption = strCaption;
    }

    public String getStrComment() {
        return strComment;
    }

    public void setStrComment(String strComment) {
        this.strComment = strComment;
    }

    public String getStrURL() {
        return strURL;
    }

    public void setStrURL(String strURL) {
        this.strURL = strURL;
    }

    public int getiResult() {
        return iResult;
    }

    public void setiResult(int iResult) {
        this.iResult = iResult;
    }

    public String getStrGooglePlayURL() {
        return strGooglePlayURL;
    }

    public void setStrGooglePlayURL(String strGooglePlayURL) {
        this.strGooglePlayURL = strGooglePlayURL;
    }

    public String getStrCafebazarURL() {
        return strCafebazarURL;
    }

    public void setStrCafebazarURL(String strCafebazarURL) {
        this.strCafebazarURL = strCafebazarURL;
    }
}
