package com.rayanandisheh.peysepar.passenger.models;

import android.graphics.Bitmap;


/**
 * Created by MGOLPA on 9/13/2017.
 */

public class DataMarker {
    public int id;
    public Double lat;
    public Double lon;
    public String title;
    public String description;
    public int rotation;
    public int speed;
    public Bitmap iconBitmap;
    public Boolean bOnline;

    public DataMarker(){}

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Double getLat() {
        return lat;
    }

    public void setLat(Double lat) {
        this.lat = lat;
    }

    public Double getLon() {
        return lon;
    }

    public void setLon(Double lon) {
        this.lon = lon;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getRotation() {
        return rotation;
    }

    public void setRotation(int rotation) {
        this.rotation = rotation;
    }

    public int getSpeed() {
        return speed;
    }

    public void setSpeed(int speed) {
        this.speed = speed;
    }

    public Bitmap getIconBitmap() {
        return iconBitmap;
    }

    public void setIconBitmap(Bitmap iconBitmap) {
        this.iconBitmap = iconBitmap;
    }

    public Boolean getbOnline() {
        return bOnline;
    }

    public void setbOnline(Boolean bOnline) {
        this.bOnline = bOnline;
    }
}