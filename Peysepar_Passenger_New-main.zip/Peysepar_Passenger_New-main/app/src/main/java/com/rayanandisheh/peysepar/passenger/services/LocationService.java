package com.rayanandisheh.peysepar.passenger.services;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.IBinder;
import androidx.core.app.ActivityCompat;
import android.util.Log;
import com.rayanandisheh.peysepar.passenger.helpers.App;

@SuppressLint("Registered")
public class LocationService extends Service {

    private static final String TAG = "LocationService";
    private Context context;
    public LocationManager locationManager;
    public MyLocationListener listener;

    @Override
    public void onCreate() {
        super.onCreate();
        context = this;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        super.onStartCommand(intent, flags, startId);

        try {
            locationManager = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);
            listener = new MyLocationListener();

            int minDistance = 10;
            int time = 8000;
            if (ActivityCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                    ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED)
                return START_NOT_STICKY;
            else
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, time, minDistance, listener);

        } catch (Exception ignored) {
            Log.i(TAG, "onStartCommand: !!!!!!!!!!!!!!!!!!!!!!!!!!");
        }
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    public class MyLocationListener implements LocationListener {

        @SuppressLint("SimpleDateFormat")
        public void onLocationChanged(final Location locations) {
            if (locations.getLatitude() > 20 && locations.getLongitude() > 20) {

                App.lastLat = locations.getLatitude();
                App.lastLng = locations.getLongitude();

            }

        }

        @Override
        public void onStatusChanged(String provider, int status, Bundle extras) {
//            Criteria criteria = new Criteria();
//            criteria.setAccuracy(Criteria.ACCURACY_FINE);
//            criteria.setAltitudeRequired(false);
//            criteria.setBearingRequired(false);
//            criteria.setCostAllowed(true);
//            criteria.setPowerRequirement(Criteria.POWER_MEDIUM);
//            provider = locationManager.getBestProvider(criteria, true);
        }

        @Override
        public void onProviderEnabled(String provider) {
        }

        @Override
        public void onProviderDisabled(String provider) {

        }
    }

        @Override
        public void onDestroy() {
            super.onDestroy();
        }

}
