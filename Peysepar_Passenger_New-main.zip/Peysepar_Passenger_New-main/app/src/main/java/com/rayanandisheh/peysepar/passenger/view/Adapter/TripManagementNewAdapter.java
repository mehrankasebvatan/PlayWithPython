package com.rayanandisheh.peysepar.passenger.view.Adapter;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.RecyclerView;

import com.rayanandisheh.peysepar.passenger.R;
import com.rayanandisheh.peysepar.passenger.helpers.Time;
import com.rayanandisheh.peysepar.passenger.models.Trip;
import com.rayanandisheh.peysepar.passenger.view.Activity.MapsActivityTabLayout;

import java.util.List;

public class TripManagementNewAdapter extends RecyclerView.Adapter<TripManagementNewAdapter.ViewHolder> {

    public List<Trip> modelTripNewTabLayout;
    Context context;
    String todayDate;

    public interface onClick {
        void cancelNewAlertTripManagement(int iOfficialTrip, int status);

        void confirmNewAlertTripManagement(int iOfficialTrip);

        void tripsArchive(int iOfficialTrip);
    }

    onClick onClick;

    public TripManagementNewAdapter(List<Trip> modelTripNewTabLayout, Context context, onClick onClick) {
        this.modelTripNewTabLayout = modelTripNewTabLayout;
        this.context = context;
        this.onClick = onClick;
    }

    public void clear() {
        modelTripNewTabLayout.clear();
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public TripManagementNewAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View viewNewFragment = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_trip_new_fragment1, parent, false);
        return new ViewHolder(viewNewFragment);
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull TripManagementNewAdapter.ViewHolder holder, int position) {
        todayDate = Time.getNowPersianDate();
        Trip model = modelTripNewTabLayout.get(position);
        holder.txt_persuadeCode.setText(String.valueOf(model.getiOfficialTrip()));
        holder.txt_applicantName.setText(model.getStrApplicantName() + " " + model.getStrApplicantFamily());
        holder.txt_tripReason.setText("سفر " + model.getStrTripReason_strComment());
        holder.txt_requestDate.setText(model.getStrTripDate() + " _ " + model.getStrRequestTime());
        holder.txt_supposeDate.setText(model.getStrTripDate() + " _ " + model.getStrTripTime());
        holder.txt_originAddress.setText(model.getStrOriginAddress());
        holder.txt_desAddress.setText(model.getStrDestinationAddress());
//        holder.txt_originAddress.setText(model.getStrOriginName()+" , "+model.getStrOriginAddress());
//        holder.txt_desAddress.setText(model.getStrDestinationName()+" , "+model.getStrDestinationAddress());
//        holder.txt_applicantPhone.setText(model.getStrApplicantMobile());

        try {
            holder.tv_TripImportanceNewFragment.setText(model.getStrTripImportance_strComment());
            if (model.getStrTripImportance_strComment() != null) {
                switch (model.getStrTripImportance_strComment()) {
                    case "عادی":
                        holder.tv_TripImportanceNewFragment.setBackground(ContextCompat.getDrawable(context, R.drawable.shape_circle_normal));
                        holder.tv_TripImportanceNewFragment.setTextColor(context.getResources().getColor(R.color.colorText));
                        break;
                    case "فوری":
                        holder.tv_TripImportanceNewFragment.setBackground(ContextCompat.getDrawable(context, R.drawable.shape_circle_urgent));
                        holder.tv_TripImportanceNewFragment.setTextColor(context.getResources().getColor(R.color.colorOrenge));
                        break;
                    case "خیلی فوری":
                        holder.tv_TripImportanceNewFragment.setBackground(ContextCompat.getDrawable(context, R.drawable.shape_circle_very_urgent));
                        holder.tv_TripImportanceNewFragment.setTextColor(context.getResources().getColor(R.color.colorPink));
                        break;
                }
            }
        } catch (Exception ignored) {
        }

        holder.itemView.setOnClickListener(v -> {

            final Dialog dialog = new Dialog(context, android.R.style.Theme_DeviceDefault_Light_Dialog_NoActionBar_MinWidth);
            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
            dialog.setContentView(R.layout.inflate_alertdialog_newtablayout);
            dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));

            RelativeLayout rl_Confirm_Trip_New = dialog.findViewById(R.id.rl_Confirm_Trip_New);
            RelativeLayout rl_Cancle_Trip_new = dialog.findViewById(R.id.rl_Cancle_Trip_new);

            if (model.getStrTripDate().compareTo(todayDate) >= 0) {
                rl_Confirm_Trip_New.setVisibility(View.VISIBLE);
                rl_Cancle_Trip_new.setVisibility(View.GONE);
            } else {
                rl_Confirm_Trip_New.setVisibility(View.GONE);
                rl_Cancle_Trip_new.setVisibility(View.VISIBLE);
            }
//            dialog.setTitle("");

            TextView txtTripReasonInflateAlertDialogTabLayout = dialog.findViewById(R.id.txtTripReasonInflateAlertDialogTabLayout);
            txtTripReasonInflateAlertDialogTabLayout.setText(model.getStrTripReason_strComment());

            TextView txPersuateCodeInflateAlertDialogTabLayout = dialog.findViewById(R.id.txPersuateCodeInflateAlertDialogTabLayout);
            txPersuateCodeInflateAlertDialogTabLayout.setText(String.valueOf(model.getiOfficialTrip()));

            TextView txt_alertdialogNameFamilyNewFragment = dialog.findViewById(R.id.txt_alertdialogNameFamilyNewFragment);
            txt_alertdialogNameFamilyNewFragment.setText(model.getStrApplicantName() + " " + model.getStrApplicantFamily());

            TextView txt_kindOfCar = dialog.findViewById(R.id.txt_NewkindOfCar);
            txt_kindOfCar.setText(model.getStrMobileType());

            RelativeLayout rlDelete = dialog.findViewById(R.id.rlDeleteInflateAlertDialogNewTabLayout);
            rlDelete.setOnClickListener(v1 -> dialog.dismiss());

            TextView txt_ApplicatntPhone = dialog.findViewById(R.id.txt_ApplicantPhoneAlertDialogNewTabLayout);
            txt_ApplicatntPhone.setText(model.getStrApplicantMobile());

            TextView txt_origin = dialog.findViewById(R.id.txt_originAlertDialogNewTabLayout);
            txt_origin.setText(model.getStrOriginName());

            TextView txt_des = dialog.findViewById(R.id.txt_desAlertDialogNewTabLayout);
            txt_des.setText(model.getStrDestinationName());

            TextView txt_Comment = dialog.findViewById(R.id.txt_Comment);
            txt_Comment.setText(model.getStrComment());

            TextView txt_Situation = dialog.findViewById(R.id.txt_Situation);
            txt_Situation.setText(model.getStrChartName());

            TextView txt_DateAndTime = dialog.findViewById(R.id.txt_DateAndTime);
            txt_DateAndTime.setText(model.getStrTripDate() + " _ " + model.getStrTripTime());

            TextView txt_passengers = dialog.findViewById(R.id.txt_passenggersAlertDialogNewTabLayout);
            txt_passengers.setText(model.getStrPassengers());

            TextView txt_Archives_TimePass_CancleTrip_New = dialog.findViewById(R.id.txt_Archives_TimePass_CancleTrip_New);

            ImageView img = dialog.findViewById(R.id.imgStarAlertNewTabLayout);
            switch (model.getStrTripImportance_strComment()) {
                case "عادی":
                    img.setBackground(ContextCompat.getDrawable(context, R.drawable.star1));
                    break;
                case "فوری":
                    img.setBackground(ContextCompat.getDrawable(context, R.drawable.star2));
                    break;
                case "خیلی فوری":
                    img.setBackground(ContextCompat.getDrawable(context, R.drawable.star3));
                    break;
            }

            TextView txt_tripImportance = dialog.findViewById(R.id.txtTripImportanceAlertNewTabLayout);
            txt_tripImportance.setText(model.getStrTripImportance_strComment());

            TextView txt_confirm = dialog.findViewById(R.id.txt_ConfirmationNewFragmentDialog);
            TextView txt_cancel = dialog.findViewById(R.id.txt_cancelNewFragmentDialog);
            TextView txt_location = dialog.findViewById(R.id.txt_locationNewFragmentDialog);
            txt_confirm.setOnClickListener(v14 -> {

                //todo unComment
                onClick.confirmNewAlertTripManagement(model.getiOfficialTrip());

                dialog.dismiss();
            });

            txt_cancel.setOnClickListener(v12 -> {
                dialog.dismiss();
                onClick.cancelNewAlertTripManagement(model.getiOfficialTrip(), model.getTiTripStatus());

//                AlertDialog.Builder dialog2 = new AlertDialog.Builder(context);
//                dialog2.setMessage("آیا از لغو سفر با کد:" + model.getiOfficialTrip() + " مطمئن هستید؟");
//
//                dialog2.setPositiveButton("بله", (dialog1, which) -> onClick.cancelNewAlertTripManagement(model.getiOfficialTrip(), model.getTiTripStatus()));
//
//                dialog2.setNegativeButton("خیر", (dialog12, which) -> dialog12.dismiss());
//                dialog2.create().show();
//                dialog.dismiss();
            });

//            txt_cancel.setOnClickListener(v12 -> {
//                AlertDialog.Builder dialog2 = new AlertDialog.Builder(context);
//                dialog2.setMessage("آیا از لغو سفر با کد:" + model.getiOfficialTrip() + " مطمئن هستید؟");
//
//                dialog2.setPositiveButton("بله", (dialog1, which) -> onClick.cancelNewAlertTripManagement(model.getiOfficialTrip(), model.getTiTripStatus()));
//
//                dialog2.setNegativeButton("خیر", (dialog12, which) -> dialog12.dismiss());
//                dialog2.create().show();
//                dialog.dismiss();
//            });

            txt_Archives_TimePass_CancleTrip_New.setOnClickListener(v15 -> {
                dialog.dismiss();
                onClick.tripsArchive(model.getiOfficialTrip());
            });

            txt_location.setOnClickListener(v13 -> {
                Intent intent = new Intent(context, MapsActivityTabLayout.class);
                intent.putExtra("flatSourceTabLayout", model.getfLatSource());
                intent.putExtra("flngSourceTabLayout", model.getfLonSource());
                intent.putExtra("flatDesTabLayout", model.getfLatDestination());
                intent.putExtra("flngDesTabLayout", model.getfLonDestination());
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);
                dialog.dismiss();
            });
            dialog.show();
        });
    }

    @Override
    public int getItemCount() {
        return modelTripNewTabLayout.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        TextView txt_persuadeCode, txt_applicantName, txt_tripReason, tv_TripImportanceNewFragment,
                txt_requestDate, txt_supposeDate, txt_originAddress, txt_desAddress;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            txt_persuadeCode = itemView.findViewById(R.id.txt_row_txtPersuadeCodeNewFragment);
            txt_applicantName = itemView.findViewById(R.id.txt_row_txtApplicantNameNewFragment);
            txt_tripReason = itemView.findViewById(R.id.txt_row_TripReasonNewFragment);
            txt_requestDate = itemView.findViewById(R.id.txt_row_RequestDateNewFragment);
            txt_supposeDate = itemView.findViewById(R.id.txt_row_supposeDateNewFragment);
            txt_originAddress = itemView.findViewById(R.id.txt_row_originAddressNewFragment);
            txt_desAddress = itemView.findViewById(R.id.txt_row_DesAddressNewFragment);
            tv_TripImportanceNewFragment = itemView.findViewById(R.id.tv_TripImportanceNewFragment);
        }
    }
}
