package com.rayanandisheh.peysepar.passenger.view.Adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.rayanandisheh.peysepar.passenger.R;
import com.rayanandisheh.peysepar.passenger.models.Trip;
import com.rayanandisheh.peysepar.passenger.view.Activity.HistoryDetailsActivity;
import com.rayanandisheh.peysepar.passenger.view.Activity.ZoomImageActivity;

import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

import static com.rayanandisheh.peysepar.passenger.view.Activity.ZoomImageActivity.STR_BITMAP;


public class HistoryAdapter extends RecyclerView.Adapter<HistoryAdapter.ViewHolder> {
    //    private List<Trip> modelHistory;
    private List<Trip> modelFrHistorytTrip;
    private Context context;
    private Bitmap decodedByte;

    public HistoryAdapter(List<Trip> modelFrHistorytTrip, Context context) {
        this.modelFrHistorytTrip = modelFrHistorytTrip;
        this.context = context;
    }

//    public void setModelHistory(List<Trip> modelHistory) {
//        this.modelHistory = modelHistory;
//        notifyDataSetChanged();
//    }

    public void setModelFrHistorytTrip(List<Trip> modelFrHistorytTrip) {
        this.modelFrHistorytTrip = modelFrHistorytTrip;
        notifyDataSetChanged();
    }

    public void clear() {
        modelFrHistorytTrip.clear();
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public HistoryAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int i) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_history, parent, false);
        return new ViewHolder(view);
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull HistoryAdapter.ViewHolder holder, int position) {
        Trip model = modelFrHistorytTrip.get(position);
        holder.txtDriverName.setText(model.getStrDriverName());
        holder.txtOrigin.setText(model.getStrOriginName());
        holder.txtDestination.setText(model.getStrDestinationName());
//        holder.txtDateTime.setText(String.format("%s-%s", model.getStrTripDate(), model.getStrTripTime()));
        holder.txtDateTime.setText(model.getStrTripDate() + " - " + model.getStrTripTime());

        holder.txtIOfficialCode.setText(String.valueOf(model.getiOfficialTrip()));

        // url driverImage
        if (model.getImageDriver() != null && !model.getImageDriver().equals("")) {
            byte[] decodedString = Base64.decode(model.getImageDriver(), Base64.DEFAULT);
            decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
            Glide.with(context).load(decodedByte).into(holder.img);
        }
//        Picasso.with(context)
////                .load(App.ServerURL + "/file/ImageProfile/" + Constants.car.getStrMobile() + ".jpg")
//                .load(App.ServerURL + "/file/ImageProfile/" + " " + ".jpg")
//                .error(R.drawable.ic_account3)
//                .placeholder(R.drawable.ic_account3)
//                .into(holder.img);
        try {
            holder.row_tripImportance.setText(model.getStrTripImportance_strComment());
            if (model.getStrTripImportance_strComment() != null) {
                switch (model.getStrTripImportance_strComment()) {
                    case "عادی":
                        holder.row_tripImportance.setBackground(ContextCompat.getDrawable(context, R.drawable.shape_circle_normal));
                        holder.row_tripImportance.setTextColor(context.getResources().getColor(R.color.colorText));
                        break;
                    case "فوری":
                        holder.row_tripImportance.setBackground(ContextCompat.getDrawable(context, R.drawable.shape_circle_urgent));
                        holder.row_tripImportance.setTextColor(context.getResources().getColor(R.color.colorOrenge));
                        break;
                    case "خیلی فوری":
                        holder.row_tripImportance.setBackground(ContextCompat.getDrawable(context, R.drawable.shape_circle_very_urgent));
                        holder.row_tripImportance.setTextColor(context.getResources().getColor(R.color.colorPink));
                        break;
                }
            }
        } catch (Exception ignored) {
        }

        holder.itemView.setOnClickListener(v -> {
            HistoryDetailsActivity.model = model;
            Intent intent = new Intent(context, HistoryDetailsActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
        });

        holder.img.setOnClickListener(v -> {
            Intent intent = new Intent(context, ZoomImageActivity.class);
            intent.putExtra("image", model.getImageDriver());
            intent.putExtra("typeImage", STR_BITMAP);
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        if (modelFrHistorytTrip != null) {
            return modelFrHistorytTrip.size();
        }
        return 0;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        TextView txtDriverName, txtOrigin, txtDestination, txtDateTime,  row_tripImportance, txtIOfficialCode;
        CircleImageView img;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            txtDriverName = itemView.findViewById(R.id.txt_row_historyName);
            row_tripImportance = itemView.findViewById(R.id.row_tripImportance);
            txtOrigin = itemView.findViewById(R.id.txt_row_historyOrigin);
            txtDestination = itemView.findViewById(R.id.txt_row_historyDestination);
            txtDateTime = itemView.findViewById(R.id.txt_row_historyDateTime);
            img = itemView.findViewById(R.id.img_row_history);
            txtIOfficialCode = itemView.findViewById(R.id.txtIOfficialCode);

        }
    }
}
