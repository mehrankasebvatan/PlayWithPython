package com.rayanandisheh.peysepar.passenger.view.Activity;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.net.Uri;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import com.rayanandisheh.peysepar.passenger.R;
import com.rayanandisheh.peysepar.passenger.helpers.Caller;
import com.rayanandisheh.peysepar.passenger.helpers.Toaster;

public class AboutUsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about_us);
        bindView();
        //getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        setActivitySetting();
    }

    private void setActivitySetting() {
        getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        setTitle("درباره شرکت");
        setSupportActionBar(findViewById(R.id.TOOLBAR));
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void bindView() {
        String sCompanyTelephoneNumber = getResources().getString(R.string.app_telephone1);
        String sCompanyWebsiteAddress = getResources().getString(R.string.app_website1);
        String sCompanyEmailAddress = getResources().getString(R.string.app_email);

        ImageView imageViewCompanyTelephone = findViewById(R.id.IMAGE_VIEW_COMPANY_TELEPHONE);
        ImageView imageViewCompanyWebsite = findViewById(R.id.IMAGE_VIEW_COMPANY_WEBSITE);
        ImageView imageViewCompanyEmail = findViewById(R.id.IMAGE_VIEW_COMPANY_EMAIL);

        imageViewCompanyTelephone.setOnClickListener(v -> callTelephone(sCompanyTelephoneNumber));
        imageViewCompanyTelephone.setOnLongClickListener(v -> copyToClipboard(sCompanyTelephoneNumber));

        imageViewCompanyWebsite.setOnClickListener(v -> openWebsite(sCompanyWebsiteAddress));
        imageViewCompanyWebsite.setOnLongClickListener(v -> copyToClipboard(sCompanyWebsiteAddress));

        imageViewCompanyEmail.setOnClickListener(v -> emailTo(sCompanyEmailAddress));
        imageViewCompanyEmail.setOnLongClickListener(v -> copyToClipboard(sCompanyEmailAddress));
    }

    private void emailTo(String emailAddress) {
        try {
            startActivity(Intent.createChooser(new Intent(Intent.ACTION_SENDTO).
                    setData(Uri.parse("mailto:" + emailAddress +
                            "?subject=" + Uri.encode("Peysepar Driver Support") +
                            "&body=" + Uri.encode(""))), "Send email by:"));
        } catch (Exception ignored) {
        }
    }

    private boolean copyToClipboard(String selectedText) {
        ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        ClipData clip = ClipData.newPlainText("label", selectedText);
        clipboard.setPrimaryClip(clip);
        Toaster.shorter("کپی شد");
        return true;
    }

    private void openWebsite(String url) {
        startActivity(new Intent(Intent.ACTION_VIEW).setData(Uri.parse(url)));
    }

    private void callTelephone(String telephoneNumber) {
        Caller.callTo(this, getResources().getString(R.string.brand), telephoneNumber);
    }
}
