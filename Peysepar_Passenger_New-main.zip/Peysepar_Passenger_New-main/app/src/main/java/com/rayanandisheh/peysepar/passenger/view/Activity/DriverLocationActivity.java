package com.rayanandisheh.peysepar.passenger.view.Activity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.location.Location;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.content.res.AppCompatResources;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;
import androidx.core.widget.ImageViewCompat;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.JointType;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.rayanandisheh.peysepar.passenger.R;
import com.rayanandisheh.peysepar.passenger.helpers.App;
import com.rayanandisheh.peysepar.passenger.helpers.MySnackBar;
import com.rayanandisheh.peysepar.passenger.helpers.PersianAppcompatActivity;
import com.rayanandisheh.peysepar.passenger.helpers.Toaster;
import com.rayanandisheh.peysepar.passenger.models.Car;
import com.rayanandisheh.peysepar.passenger.models.DataMarker;
import com.rayanandisheh.peysepar.passenger.services.APIClient;
import com.rayanandisheh.peysepar.passenger.services.APIService;
import com.rayanandisheh.peysepar.passenger.utils.MyClass;

import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DriverLocationActivity extends PersianAppcompatActivity implements OnMapReadyCallback {
    private static final String TAG = "DriverLocationActivity";
    private GoogleMap mMap;
    Context context = this;
    //    Marker marker;
    Timer timer = new Timer();
    //    Timer timer;
    private String unitIdDriver;
    private boolean bRouting = false;
    List<LatLng> ListLatLngs = new ArrayList<>();
    //    LatLng latLng;
    private ProgressBar progressBar;
    private FloatingActionButton fb_mapRoting;
    private ConstraintLayout layout;

    @SuppressLint("ResourceAsColor")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_driver_location);

        Bundle bundle = getIntent().getExtras();
        unitIdDriver = bundle.getString("unitId");

        ListLatLngs.clear();
        //getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        layout = findViewById(R.id.layout);
        progressBar = findViewById(R.id.progressBar);
        fb_mapRoting = findViewById(R.id.fb_mapRoting);

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.driverLocation);
        assert mapFragment != null;
        mapFragment.getMapAsync(this);

        getDriverLocation();

        fb_mapRoting.setOnClickListener(view -> {
            if (bRouting) {
                bRouting = false;
                timer.cancel();
                ColorStateList colorStateList = AppCompatResources.getColorStateList(context, R.color.colorWhite);
                ImageViewCompat.setImageTintList(fb_mapRoting, colorStateList);
                fb_mapRoting.setBackgroundTintList(ColorStateList.valueOf(ContextCompat.getColor(this, R.color.colorText)));
                MySnackBar.ShowCustomDisable(view, "رهگیری غیرفعال شد");
            } else {
                bRouting = true;
                timer = new Timer();
                timer.schedule(new secondTask(), 0, 3000);
                ColorStateList colorStateList = AppCompatResources.getColorStateList(context, R.color.colorWhite);
                ImageViewCompat.setImageTintList(fb_mapRoting, colorStateList);
                fb_mapRoting.setBackgroundTintList(ColorStateList.valueOf(ContextCompat.getColor(this, R.color.colorAccent)));
                MySnackBar.ShowCustomEnable(view, "رهگیری فعال شد");
            }
        });
    }

    private void getDriverLocation() {
        APIService apiService = APIClient.getClient().create(APIService.class);
        Call<Car> call = apiService.GetCarLive(unitIdDriver);
        call.enqueue(new Callback<Car>() {
            @Override
            public void onResponse(@NonNull Call<Car> call, @NonNull Response<Car> response) {
                progressBar.setVisibility(View.GONE);
                if (response.code() == 200 && response.body() != null) {
                    App.driverLocation = new LatLng(response.body().getfLat(), response.body().getfLon());
                    locatioDriver(response.body().getSiAngle());
                } else {
                    MyClass.ToastM(context, "مشکلی پیش آمده است، لطفا دقایق دیگر امتحان کنید");
                }
            }

            @Override
            public void onFailure(@NonNull Call<Car> call, @NonNull Throwable t) {
                progressBar.setVisibility(View.GONE);
                MyClass.ToastM(context, "خطا در برقراری ارتباط");
            }
        });
    }

//    public void getDriverLocation() {
//        Trip trip = new Trip();
//        trip.setiOfficialTrip(App.iOfficialTrip);
//        APIService apiService = APIClient.getClient().create(APIService.class);
//        Call<UserInfo> call = apiService.GetLastPosition(trip);
//        call.enqueue(new Callback<UserInfo>() {
//            @Override
//            public void onResponse(@NotNull Call<UserInfo> call, @NotNull Response<UserInfo> response) {
//                progressBar.setVisibility(View.GONE);
//                if (response.code() == 200 && response.body() != null) {
//                    resultOfDriverLocation(response.body());
//                } else {
//                    assert response.body() != null;
//                    resultOfDriverLocation(response.body());
//                }
//            }
//
//            @Override
//            public void onFailure(@NotNull Call<UserInfo> call, @NotNull Throwable t) {
//                progressBar.setVisibility(View.GONE);
//                Toaster.shorter("خطا در اتصال اینترنت");
//            }
//        });
//    }

//    public void resultOfDriverLocation(Car body) {
//        mMap.clear();
//        switch (body.getResult()) {
//            case 1:
//                App.driverLocation = new LatLng(body.getfLat(), body.getfLon());
//                locatioDriver();
////                Toaster.shorter(body.getStrComment());
//                break;
//            case 0:
////                Toaster.shorter(body.getStrComment());
//                break;
//            default:
////                Toaster.shorter(body.getStrComment());
//                break;
//        }
//    }

    @SuppressLint({"SetTextI18n", "UseCompatLoadingForDrawables"})
    public void locatioDriver(int SiAngle) {
        Bitmap icon = BitmapFactory.decodeResource(context.getResources(), R.drawable.car6);
        mMap.addMarker(new MarkerOptions()
                .position(App.driverLocation)
                .icon(BitmapDescriptorFactory.fromBitmap(MyClass.getResizedBitmap(icon
                        , 128, 128)))
                .title("موقعیت فعلی راننده")
                .flat(true)
                .rotation(SiAngle));

        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(App.driverLocation, 15));
    }

    class secondTask extends TimerTask {
        @Override
        public void run() {
            getCarLive();
        }
    }

    private void getCarLive() {
        APIService apiService = APIClient.getClient().create(APIService.class);
        Call<Car> call = apiService.GetCarLive(unitIdDriver);
        call.enqueue(new Callback<Car>() {
            @Override
            public void onResponse(@NonNull Call<Car> call, @NonNull Response<Car> response) {
                if (response.code() == 200 && response.body() != null) {
                    car(response.body());
                } else {
                    MyClass.ToastM(context, "مشکلی پیش آمده است، لطفا دقایق دیگر امتحان کنید");
                }
            }

            @Override
            public void onFailure(@NonNull Call<Car> call, @NonNull Throwable t) {
                MyClass.ToastM(context, "خطا در برقراری ارتباط");
            }
        });
    }

    public void car(Car car) {
        List<DataMarker> getMarker = new ArrayList<>();
        if (car != null) {
            DataMarker dataMarker = new DataMarker();
            dataMarker.setLat(car.getfLat());
            dataMarker.setLon(car.getfLon());
            dataMarker.setDescription("");
            dataMarker.setRotation(car.getSiAngle());
            dataMarker.setSpeed(car.getiSpeed());
            getMarker.add(dataMarker);

            AddMarker(getMarker, mMap);
            setCamera(car);
        }
    }

    @SuppressLint("SetTextI18n")
    public void AddMarker(List<DataMarker> markerList, GoogleMap map) {
        map.clear();
        mMap = map;
        Bitmap icon = BitmapFactory.decodeResource(context.getResources(), R.drawable.car6);
        List<LatLng> directionPoint = new ArrayList<>();
        for (int i = 0; i < markerList.size(); i++) {
            mMap.addMarker(new MarkerOptions()
                    .position(new LatLng(markerList.get(i).lat, markerList.get(i).lon))
                    .icon(BitmapDescriptorFactory.fromBitmap(MyClass.getResizedBitmap(icon
                            , 128, 128)))
//                    .icon(BitmapDescriptorFactory.fromBitmap(MyClass
//                            .getMarkerBitmapFromView(context,markerList.get(i).iconBitmap, markerList.get(i).title)))
                    .title(markerList.get(i).getTitle())
                    .flat(true)
                    .rotation(markerList.get(i).rotation)
                    .snippet(markerList.get(i).description));

            directionPoint.add(new LatLng(markerList.get(i).lat, markerList.get(i).lon));
        }

        ListLatLngs.add(new LatLng(directionPoint.get(0).latitude, directionPoint.get(0).longitude));
        DrawLineRoute(ListLatLngs);
    }

    private void DrawLineRoute(List<LatLng> latLngs) {
        PolylineOptions polylineOptions = new PolylineOptions();
        for (int i = 0; i < latLngs.size(); i++) {
            LatLng point = latLngs.get(i);
            polylineOptions.add(point);
        }

        Polyline polyline = mMap.addPolyline(polylineOptions);
        polyline.setClickable(true);
        stylePolyline(polyline);
    }

    private void stylePolyline(Polyline polyline) {
//        polyline.setStartCap(new CustomCap(BitmapDescriptorFactory.fromResource(R.drawable.ic_startcap), 25));
//        polyline.setEndCap(new CustomCap(BitmapDescriptorFactory.fromResource(R.drawable.ic_endcap), 25));

        polyline.setWidth(20);
        polyline.setColor(context.getResources().getColor(R.color.color_polyline));
        polyline.setJointType(JointType.DEFAULT);
    }

    public void setCamera(Car car) {
        CameraPosition cameraPosition = new CameraPosition.Builder()
                .target(new LatLng(car.getfLat(), car.getfLon()))             // Sets the center of the map to current location
                .zoom(17)                   // Sets the zoom
                .bearing(0)                // Sets the orientation of the camera to east
                .tilt(0)                   // Sets the tilt of the camera to 30 degrees
                .build();                   // Creates a CameraPosition from the builder
        mMap.moveCamera(CameraUpdateFactory.newCameraPosition(cameraPosition));

//        LatLng[] latLngs = {new LatLng(car.getfLat(), car.getfLon())};
//        LatLngBounds.Builder builder = new LatLngBounds.Builder();
//        for (LatLng latLng : latLngs)
//            builder.include(latLng);
//
//        LatLngBounds bounds = builder.build();
//        int width = context.getResources().getDisplayMetrics().widthPixels;
//        int height = context.getResources().getDisplayMetrics().heightPixels;
//        int padding = 300;
//        CameraUpdate cu = CameraUpdateFactory.newLatLngBounds(bounds, width, height, padding);
//        mMap.moveCamera(cu);
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(32.7827964, 52.9383403), 4));
    }

    @Override
    protected void onStart() {
        super.onStart();
//        timer.schedule(new secondTask(), 0, 30000);
    }

    @Override
    protected void onResume() {
        super.onResume();
//        timer.schedule(new secondTask(), 0, 30000);
    }

    @Override
    protected void onRestart() {
        super.onRestart();
    }

    @Override
    protected void onStop() {
        super.onStop();
        timer.cancel();
    }

    @Override
    protected void onPause() {
        super.onPause();
        timer.cancel();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        timer.cancel();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        timer.cancel();
    }
}
