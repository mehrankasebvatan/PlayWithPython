package com.rayanandisheh.peysepar.passenger.view.Activity;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Base64;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.bumptech.glide.Glide;
import com.rayanandisheh.peysepar.passenger.R;
import com.rayanandisheh.peysepar.passenger.helpers.App;
import com.rayanandisheh.peysepar.passenger.helpers.Cache;
import com.rayanandisheh.peysepar.passenger.helpers.CheckCode;
import com.rayanandisheh.peysepar.passenger.helpers.Converter;
import com.rayanandisheh.peysepar.passenger.helpers.PersianAppcompatActivity;
import com.rayanandisheh.peysepar.passenger.helpers.Toaster;
import com.rayanandisheh.peysepar.passenger.helpers.Validate;
import com.rayanandisheh.peysepar.passenger.models.MobileDomain;
import com.rayanandisheh.peysepar.passenger.models.Register;
import com.rayanandisheh.peysepar.passenger.models.UserInfo;
import com.rayanandisheh.peysepar.passenger.services.APIClient;
import com.rayanandisheh.peysepar.passenger.services.APIService;
import com.toptoche.searchablespinnerlibrary.SearchableSpinner;
import com.vansuita.pickimage.bean.PickResult;
import com.vansuita.pickimage.listeners.IPickResult;

import org.jetbrains.annotations.NotNull;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class NewProfileActivity extends PersianAppcompatActivity implements IPickResult {
    public static final int PICK_IMAGE = 1;
    public static final int MY_REQUEST_CODE = 3;
    private static final String TAG = "NewProfileActivity";
    Context context;
    TextView txtMobileProfile, tvProfilePic, txtSelectedPositionName, txtOrgPosition, txtpersonalID;
    CircleImageView ivProfilePic;
    Bitmap bmProfile, photo;
    EditText edtNameProfile, edtFamilyProfile, edtNationalIDProfile, edtOptionalOrigin;
    //    RadioGroup radioGroup;
    RadioButton rbMan, rbWoman1;
    Button btn;
    ProgressBar pb;
    ImageView ivWarningProfileName, ivWarningProfileFamily, ivWarningProfileNcode;
    RelativeLayout rlChoosePermanentOrigin;
    CheckBox chkProfile;
    Toolbar toolbar;
    BroadcastReceiver mBroadcastReceiverProfile = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            receivedBroadcast(intent);
        }
    };

    SearchableSpinner spnDomain;
    List<MobileDomain> domains = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_profile);

        context = this;
        bindView();
        //getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        edtNameProfile.setText(App.userInfo.getStrName());
        edtFamilyProfile.setText(App.userInfo.getStrFamily());
        edtNationalIDProfile.setText(App.userInfo.getNationalCode());
        String address = Cache.getString("userAddress");

        //edtOptionalOrigin.setText(App.userInfo.getStrAddress());

        if (App.userInfo.getStrAddress() != null && !App.userInfo.getStrAddress().equals("")) {
            edtOptionalOrigin.setText(App.userInfo.getStrAddress());
        } else if (Cache.getString("userAddress") != null)
            edtOptionalOrigin.setText(Cache.getString("userAddress"));
        else
            edtOptionalOrigin.setText("");

        edtNameProfile.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                if (s.toString().length() < 2)
                    showImageErrorName();
                else
                    hideImageErrorName();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        edtFamilyProfile.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                if (s.toString().length() < 2)
                    showImageErrorFamily();
                else
                    hideImageErrorFamily();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        if (App.userInfo.getStrChart() != null && !App.userInfo.getStrChart().equals(""))
            txtOrgPosition.setText(App.userInfo.getStrChart());
        else
            txtOrgPosition.setText("اختصاص نیافته");


        if (App.marker_existance) {
            chkProfile.setChecked(true);
//            edtOptionalOrigin.setText(Cache.getString("userAddress"));
        } else {
            chkProfile.setChecked(false);
//            edtOptionalOrigin.setText("");
        }
        try {
//            if (App.userInfo.getImgLink() != null && !App.userInfo.getImgLink().equals("")) {
//                byte[] decodedString = Base64.decode(App.userInfo.getImgLink(), Base64.DEFAULT);
//                Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
//                Glide.with(context).load(decodedByte).into(ivProfilePic);
//            }
            if (!Cache.getString("photo").equals("")) {
                String pic = Cache.getString("photo");
                if (!pic.equals("")) {
                    byte[] decodedString = Base64.decode(pic, Base64.DEFAULT);
                    Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
                    Glide.with(context).load(decodedByte).into(ivProfilePic);
                    Log.i(TAG, "onCreate: ivProfilePic decodedByte  " + decodedByte.toString());
                }
            } else
                ivProfilePic.setImageResource(R.drawable.ic_account3);


        } catch (Exception ignored) {
        }

//        try {
//            Picasso.get()
//                    .load(App.userInfo.getImgLink())
//                    .placeholder(R.drawable.ic_account3)// Place holder image from drawable folder
//                    .error(R.drawable.ic_account3)
//                    .memoryPolicy(MemoryPolicy.NO_CACHE, MemoryPolicy.NO_STORE)
//                    .networkPolicy(NetworkPolicy.NO_CACHE)
//                    .resize(110, 110)
//                    .centerCrop()
//                    .into(ivProfilePic);
//        } catch (Exception ignored) {
//
//        }


//        tvProfilePic.setOnClickListener(v -> ChoosePicture());
//        tvProfilePic.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//
//            }
//        });

        if (App.userInfo.getTiSex() == 1)
            rbMan.setChecked(true);
        else if (App.userInfo.getTiSex() == 2)
            rbWoman1.setChecked(true);

        if (!App.userInfo.getNationalCode().equals(""))
            edtNationalIDProfile.setText(App.userInfo.getNationalCode());

        ivProfilePic.setOnClickListener(v -> showDialog());
        txtMobileProfile.setText(Cache.getString("mobileNumber"));

        btn.setOnClickListener(v ->
                btnClicked());


        rlChoosePermanentOrigin.setOnClickListener(v -> rlChoosePermanentOriginPressed());
        txtSelectedPositionName.setOnClickListener(v -> rlChoosePermanentOriginPressed());

        GetDomains();
    }

    private void GetDomains() {
        APIClient.getClient().create(APIService.class).MobileDomain().enqueue(new Callback<List<MobileDomain>>() {
            @Override
            public void onResponse(@NonNull Call<List<MobileDomain>> call, @NonNull Response<List<MobileDomain>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    domains.addAll(response.body());
                    setDomainSpinner(response.body());
                }
            }

            @Override
            public void onFailure(@NonNull Call<List<MobileDomain>> call, @NonNull Throwable t) {
                Log.d("mobileDomain", "onFailure: " + t.getLocalizedMessage());
            }
        });
    }

    private void setDomainSpinner(List<MobileDomain> data) {
        List<String> domains = new ArrayList<>();
        for (MobileDomain domain :
                data) {
            domains.add(domain.getStrComment());
        }
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, R.layout.item_spinner, domains);
        spnDomain.setAdapter(adapter);
        spnDomain.setTitle("");
        spnDomain.setPositiveButton("تایید");
    }

    private void receivedBroadcast(Intent intent) {
        if (intent.getAction().matches("android.intent.action.map_result_ok") ||
                intent.getAction().matches("android.intent.action.map_result_fail")) {
            getExtras(intent.getStringExtra("start_address"),
                    intent.getStringExtra("end_address"));
        }
    }

    private void getExtras(String start_address, String end_address) {
        try {
            if (start_address != null)
                Cache.setString("userAddress", start_address);
        } catch (Exception ignored) {
        }

        try {

            if (!start_address.isEmpty()) {
                edtOptionalOrigin.setText(start_address);
            }
        } catch (Exception ignored) {
        }

    }

    @SuppressLint("IntentReset")
    public void ChoosePicture() {

        Intent getIntent = new Intent(Intent.ACTION_GET_CONTENT);
        getIntent.setType("image/*");

        @SuppressLint("IntentReset")
        Intent pickIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        pickIntent.setType("image/*");

        Intent chooserIntent = Intent.createChooser(getIntent, "Select Image");
        chooserIntent.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{pickIntent});
        pickIntent.putExtra("crop", "true");
        pickIntent.putExtra("scale", true);
        pickIntent.putExtra("outputX", 256);
        pickIntent.putExtra("outputY", 256);
        pickIntent.putExtra("aspectX", 1);
        pickIntent.putExtra("aspectY", 1);
        pickIntent.putExtra("return-data", true);
        startActivityForResult(pickIntent, 1);
    }

    private void btnClicked() {
        if (!Validate.firstName(edtNameProfile.getText().toString()))
            showNameError();

        else if (!Validate.lastName(edtFamilyProfile.getText().toString()))
            showFamilyError();

        else if (!Validate.lastName(edtFamilyProfile.getText().toString()))
            showFamilyError();

        else if (!CheckCode.isNationalCode(edtNationalIDProfile.getText().toString()))
            showNcodeError();

        else if (((Cache.getLat("selectedPositionLat", 0) > 20
                && Cache.getLng("selectedPositionLon", 0) > 20)
                || (App.userInfo.getfLat() > 0 && App.userInfo.getfLon() > 0))
                && edtOptionalOrigin.getText().toString().trim().isEmpty()) {
            showErrorEmpetyEdtPermanentAddress();
        } else if (((Cache.getLat("selectedPositionLat", 0) < 20 && App.userInfo.getfLat() == 0 && App.userInfo.getfLon() == 0
        ) && Cache.getLng("selectedPositionLon", 0) < 20) && !(edtOptionalOrigin.getText().toString().length() == 0)) {
            Toaster.shorter("لطفا مبدا را از روی نقشه مشخص کنید");
        } else {
            showProggressBar();
            requestProfile();
        }
    }

    //TODO showDialog
    public void showDialog() {
        final Dialog dialog = new Dialog(context);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.gallerydialog);

        LinearLayout linearcamera = dialog.findViewById(R.id.linearcamera);
        linearcamera.setOnClickListener(v -> {
            if (ContextCompat.checkSelfPermission(NewProfileActivity.this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    requestPermissions(new String[]{Manifest.permission.CAMERA},
                            5);
                }
            } else {
                Intent takePicture = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(takePicture, 0);
            }

            dialog.dismiss();
        });

        TextView txt_choose_from_gallery = dialog.findViewById(R.id.txt_choose_from_gallery);
        LinearLayout linearGallery = dialog.findViewById(R.id.linearGallery);
        linearGallery.setOnClickListener(v -> {
            Intent pickPhoto = new Intent(Intent.ACTION_PICK,
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            startActivityForResult(pickPhoto, 1);
            dialog.dismiss();
        });
        dialog.show();

    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case 0:
                if (resultCode == RESULT_OK) {
                    photo = (Bitmap) data.getExtras().get("data");
                    assert photo != null;
                    photo = Bitmap.createScaledBitmap(photo, 200, 200, true);
                    ivProfilePic.setImageBitmap(photo);

                    Log.i(TAG, "onActivityResult: ivProfilePic photo " + photo.toString());

                    ByteArrayOutputStream baos = new ByteArrayOutputStream();
                    if (photo != null) {
                        photo.compress(Bitmap.CompressFormat.PNG, 100, baos);
                        String strPhoto = Base64.encodeToString(baos.toByteArray(), Base64.DEFAULT);
                        Cache.setString("photo", strPhoto);
                    }
                }

                break;
            case 1:
                if (resultCode == RESULT_OK) {
                    Uri selectedImage = data.getData();
                    try {
                        bmProfile = MediaStore.Images.Media.getBitmap(this.getContentResolver(), selectedImage);
                        ivProfilePic.setImageBitmap(bmProfile);

                        Log.i(TAG, "onActivityResult: ivProfilePic bmProfile " + bmProfile.toString());
                        ByteArrayOutputStream baos = new ByteArrayOutputStream();
                        if (photo != null) {
                            photo.compress(Bitmap.CompressFormat.PNG, 100, baos);
                            String strPhoto = Base64.encodeToString(baos.toByteArray(), Base64.DEFAULT);
                            Cache.setString("photo", strPhoto);
                        }

                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                break;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 5) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Intent takePicture = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(takePicture, 0);
            } else {
                Toast.makeText(context, "درصورت عدم دسترسی به دوربین مجاز به استفاده از آن نمی باشید", Toast.LENGTH_SHORT).show();
                // Your app will not have this permission. Turn off all functions
                // that require this permission or it will force close like your
                // original question
            }
        }
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_profile, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;

            case R.id.menuOption:
                openDialogDeleteCache();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void openDialogDeleteCache() {

        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setMessage("مطمین هستید که از برنامه می خواهید خارج شوید؟");
        builder.setPositiveButton("بله", (dialog, which) -> {
            Cache.setString("mobileNumber", "");

            exitApp();
        });
        builder.setNegativeButton("خیر", (dialog, which) -> {

        });
        builder.create().show();
    }

    public void showImageErrorName() {
        ivWarningProfileName.setVisibility(View.VISIBLE);
    }

    public void hideImageErrorName() {
        ivWarningProfileName.setVisibility(View.GONE);
    }

    public void showImageErrorFamily() {
        ivWarningProfileFamily.setVisibility(View.VISIBLE);
    }

    public void hideImageErrorFamily() {
        ivWarningProfileFamily.setVisibility(View.GONE);
    }

    public void showImageErrorNcode() {
        ivWarningProfileNcode.setVisibility(View.VISIBLE);
    }

    public void hideImageErrorNcode() {
        ivWarningProfileNcode.setVisibility(View.GONE);
    }

    public void showErrorEmpetyEdtPermanentAddress() {
        edtOptionalOrigin.setError("لطفا مبدا را تایپ کنید");
    }

    public void rlChoosePermanentOriginPressed() {
        if (checkPermission()) {
            context.startActivity(new Intent(context, MapsChooseOriginActivity.class));
        }
    }

    public boolean checkPermission() {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) !=
                PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions((Activity) context, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1234);
        } else {
//            Toast.makeText(context, "permission has granted", Toast.LENGTH_SHORT).show();
            return true;
        }
        return false;
    }

    public void hideProgressBar() {
        pb.setVisibility(View.GONE);
        btn.setVisibility(View.VISIBLE);
    }

    public void showProggressBar() {
        pb.setVisibility(View.VISIBLE);
        btn.setVisibility(View.GONE);
    }

    public void showNameError() {
        ivWarningProfileName.setVisibility(View.VISIBLE);
        Toaster.shorter("نام وارد شده صحیح نمی باشد");
    }

    public void showFamilyError() {
        ivWarningProfileFamily.setVisibility(View.VISIBLE);
        Toaster.shorter("نام خانوادگی وارد شده صحیح نمی باشد");
    }

    public void showNcodeError() {
        ivWarningProfileNcode.setVisibility(View.VISIBLE);
        Toaster.shorter("کد ملی وارد شده صحیح نمی باشد");
    }

    public void onPickResult(PickResult r) {
        if (r.getError() == null) {
            Log.i(TAG, "onPickResult: ivProfilePic " + r.getBitmap());
            ivProfilePic.setImageBitmap(r.getBitmap());
            bmProfile = r.getBitmap();
        } else
            Toaster.shorter(r.getError().getMessage());
    }

    @Override
    protected void onResume() {
        super.onResume();
        IntentFilter iff = new IntentFilter();
        iff.addAction("android.intent.action.map_result_ok");
        iff.addAction("android.intent.action.map_result_fail");
        try {
            context.registerReceiver(mBroadcastReceiverProfile, iff);
        } catch (IllegalArgumentException ignore) {
        }
    }

    private void bindView() {

        toolbar = findViewById(R.id.toolbar_profile1);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        setTitle("پروفایل");

        btn = findViewById(R.id.btnProfile1);
        pb = findViewById(R.id.pbProfile1);
        edtNameProfile = findViewById(R.id.edtNameProfile1);
        edtFamilyProfile = findViewById(R.id.edtFamilyProfile1);
        edtNationalIDProfile = findViewById(R.id.edtNationalIDProfile1);
        rbMan = findViewById(R.id.rbMan1);
        rbWoman1 = findViewById(R.id.rbWoman1);
        txtMobileProfile = findViewById(R.id.txtMobileProfile1);
        txtpersonalID = findViewById(R.id.txtpersonalID);
        ivProfilePic = findViewById(R.id.imgprofilename1);
        tvProfilePic = findViewById(R.id.txtprofilepicture1);
        ivWarningProfileName = findViewById(R.id.ivWarningProfileName1);
        ivWarningProfileFamily = findViewById(R.id.ivWarningProfileFamily1);
        ivWarningProfileNcode = findViewById(R.id.ivWarningProfileNcode1);
        rlChoosePermanentOrigin = findViewById(R.id.rlChoosePermanentOrigin1);
        txtSelectedPositionName = findViewById(R.id.txtSelectedPositionName1);
        edtOptionalOrigin = findViewById(R.id.edtOptionalOrigin1);
        chkProfile = findViewById(R.id.chkProfile1);
        txtOrgPosition = findViewById(R.id.txtOrgPosition1);
        spnDomain = findViewById(R.id.spinnerDomain);

    }

    public void requestProfile() {
//        Register register = new Register();
//        register.setStrName(edtNameProfile.getText().toString().trim());
//        register.setStrFamily(edtFamilyProfile.getText().toString().trim());
//        register.setStrNationalCode(edtNationalIDProfile.getText().toString().trim());
//        register.setStrMobile(Cache.getString("mobileNumber"));
//        register.setStrAddress(Cache.getString("userAddress"));

        App.register.setStrName(edtNameProfile.getText().toString().trim());
        App.register.setStrFamily(edtFamilyProfile.getText().toString().trim());
        App.register.setStrNationalCode(edtNationalIDProfile.getText().toString().trim());
        App.register.setStrMobile(Cache.getString("mobileNumber"));
        App.register.setStrAddress(Cache.getString("userAddress"));

        if (App.marker_existance) {
            @SuppressLint("DefaultLocale")
            double lat = Double.parseDouble(String.format("%.5f", App.selectedPosition.latitude));
            @SuppressLint("DefaultLocale")
            double lon = Double.parseDouble(String.format("%.5f", App.selectedPosition.longitude));
            if (lat == 0 && lon == 0) {
                App.register.setLat(App.userInfo.getfLat());
                App.register.setLon(App.userInfo.getfLon());
            } else {
                App.register.setLat(lat);
                App.register.setLon(lon);
            }
        } else {
            App.register.setLat(App.userInfo.getfLat());
            App.register.setLon(App.userInfo.getfLon());
        }

        if (!Cache.getString("photo").equals(""))
            App.register.setImg(Cache.getString("photo"));
//            App.register.setImg("");
        else if (bmProfile != null)
            App.register.setImg(Converter.bitmapToString(bmProfile));

        App.register.setStrToken(Cache.getString("FirebaseToken"));

        if (rbMan.isChecked()) {
            App.register.setTiSex(1);
        } else {
            App.register.setTiSex(2);
        }

        App.register.setStrAddress(edtOptionalOrigin.getText().toString());

        App.register.setiMobileDomain(domains.get(spnDomain.getSelectedItemPosition()).getiMobileDomain());

        APIService apiService = APIClient.getClient().create(APIService.class);
        Call<Register> call = apiService.UpdateProfile(App.register, App.Session);
        call.enqueue(new Callback<Register>() {
            @Override
            public void onResponse(@NotNull Call<Register> call, @NotNull Response<Register> response) {
                if (response.code() == 200) {
                    App.register = response.body();
                    assert response.body() != null;
                    updateProfileResulr(response.body().getResult());
                } else {
                    updateProfileResulr(-4);
                }
            }

            @Override
            public void onFailure(@NotNull Call<Register> call, @NotNull Throwable t) {
                updateProfileResulr(-5);
            }
        });
    }

    public void saveLATLNG_AddreesName() {
        Cache.setString("selectedPositionName", App.selectedPositionName);
    }

    public void updateProfileResulr(int result) {
        hideProgressBar();
        if (result == -4) {
            Toaster.shorter(context.getString(R.string.serverFaield));
        } else if (result == -5) {
            Toaster.shorter(context.getString(R.string.connectionFaield));
        } else if (result == 1) {
            //requestRefresh();
            //saveLATLNG_AddreesName();
            finish();
            startActivity(new Intent(NewProfileActivity.this, SplashActivity.class));

        } else if (result == -1) {
            Toaster.shorter(context.getString(R.string.serverFaield));
        } else if (result == 100) {
            Intent intent = new Intent(NewProfileActivity.this, LoginActivity.class);
            startActivity(intent);
        }
    }

    public void requestRefresh() {
        App.userInfo.setStrMobile(Cache.getString("mobileNumber"));
        APIService apiService = APIClient.getClient().create(APIService.class);
        Call<UserInfo> call = apiService.refresh(App.userInfo);
        call.enqueue(new Callback<UserInfo>() {
            @Override
            public void onResponse(@NotNull Call<UserInfo> call, @NotNull Response<UserInfo> response) {
                if (response.code() == 200 && response.body() != null) {
                    App.userInfo = response.body();
                    refreshResult(1);
                } else {
                    refreshResult(-4);
                }
            }

            @Override
            public void onFailure(@NotNull Call<UserInfo> call, @NotNull Throwable t) {
                refreshResult(-5);
            }
        });
    }

    public void refreshResult(int refreshResult) {
        if (refreshResult == -5) {
            Toaster.shorter(context.getString(R.string.connectionFaield));
        } else if (refreshResult == -4) {
            Toaster.shorter(context.getString(R.string.serverFaield));
        } else if (refreshResult == 1) {
            Toaster.shorter("پروفایل با موفقیت آپدیت شد");
            ((Activity) context).finish();
        }
    }

    private void exitApp() {
        MainActivity.exit = true;
        finish();
    }

}

//Dialog to pick image from gallery or from camera