JkSFile ::
name : peysepar_customer.jks
aliasName : mosayeb


key Storre password : 123698745
Alias Password : 123698745



JKs Release SHA-1 fingerPrint : 
9F:83:5B:5F:1F:03:DE:5A:B1:63:1B:41:4B:CF:69:E7:EE:24:87:F6

 package="com.rayanandisheh.peysepar.passenger"
 
 googleMap APi : AIzaSyD7KpoM54O6x3Tzvy3WIgS27SMRzrjTiSU
